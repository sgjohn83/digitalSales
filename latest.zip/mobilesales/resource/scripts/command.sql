mysql -u root -p mobileshop < D:\sql\mobileshop.sql
