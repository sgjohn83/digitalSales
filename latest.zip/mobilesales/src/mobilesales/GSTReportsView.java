package mobilesales;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;
import model.ReportEntry;

public class GSTReportsView extends JPanel {
    private List<ReportEntry> currentData;

    private final JDateChooser startChooser = new JDateChooser();
    private final JDateChooser endChooser   = new JDateChooser();
    private final JComboBox<String> brandCombo = new JComboBox<>();
    private final JComboBox<String> typeCombo  = new JComboBox<>(new String[]{"All","Purchase","Sales"});
    private final JButton generateBtn         = new JButton("Generate");
    private final JButton exportBtn           = new JButton("Export PDF");
    private final JButton exportCsvBtn = new JButton("Export CSV");

    private DefaultTableModel tableModel;
    private JTable table;

    // Summary labels
    private final JLabel unitPriceLbl   = new JLabel("Unit Price Total: 0.00");
    private final JLabel cgstTotalLbl   = new JLabel("CGST Total: 0.00");
    private final JLabel sgstTotalLbl   = new JLabel("SGST Total: 0.00");
    private final JLabel grandTotalLbl  = new JLabel("Final Amount Total: 0.00");

    public GSTReportsView() {
        setLayout(new BorderLayout(5,5));
        add(createFilterPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        add(createSummaryPanel(), BorderLayout.SOUTH);
    }

    private JPanel createFilterPanel() {
        JPanel panel = new JPanel();
        panel.add(new JLabel("Start:"));  panel.add(startChooser);
        panel.add(new JLabel("End:"));    panel.add(endChooser);
        panel.add(new JLabel("Brand:"));  panel.add(brandCombo);
        panel.add(new JLabel("Type:"));   panel.add(typeCombo);
        panel.add(generateBtn);
        panel.add(exportBtn);
        panel.add(exportCsvBtn);
        return panel;
    }

    private JScrollPane createTablePanel() {
        String[] cols = {"S.NO","Type", "Invoice No", "Date", "IMEI", "Model", "Brand", "Taxable Value", "CGST", "SGST", "Total Amount"};
        tableModel = new DefaultTableModel(cols, 0);
        table      = new JTable(tableModel);
        return new JScrollPane(table);
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.add(unitPriceLbl);
        panel.add(cgstTotalLbl);
        panel.add(sgstTotalLbl);
        panel.add(grandTotalLbl);
        return panel;
    }

    public Date getStartDate()               { return startChooser.getDate(); }
    public Date getEndDate()                 { return endChooser.getDate(); }
    public String getSelectedBrand()         { return (String) brandCombo.getSelectedItem(); }
    public String getSelectedType()          { return (String) typeCombo.getSelectedItem(); }

    public void setBrandOptions(List<String> brands) {
        brandCombo.removeAllItems();
        brandCombo.addItem("All");
        for (String b : brands) brandCombo.addItem(b);
    }

    public void addGenerateListener(ActionListener listener) {
        generateBtn.addActionListener(listener);
    }
    public void addExportListener(ActionListener listener) {
        exportBtn.addActionListener(listener);
    }

    public void updateTable(List<ReportEntry> data) {
        this.currentData = data;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        tableModel.setRowCount(0);
        int i=1;
        for (ReportEntry e : data) {
            double unitPrice = e.getTaxableValue();
            double cgst = e.getCgst();
            double sgst = e.getSgst();
            double finalAmount = unitPrice + cgst + sgst;
            tableModel.addRow(new Object[] {
                i,
                e.getType(), e.getInvoiceNo(), df.format(e.getDate()),
                e.getImei(), e.getModel(), e.getBrand(),
                String.format("%.2f", unitPrice),
                String.format("%.2f", cgst),
                String.format("%.2f", sgst),
                String.format("%.2f", finalAmount)
            
            });
            i++;
        }
    }

    public void updateSummary(List<ReportEntry> data) {
        double unitPriceTotal = 0, cgstTotal = 0, sgstTotal = 0;
        for (ReportEntry e : data) {
            unitPriceTotal += e.getTaxableValue();
            cgstTotal      += e.getCgst();
            sgstTotal      += e.getSgst();
        }
        double grandTotal = unitPriceTotal + cgstTotal + sgstTotal;

        unitPriceLbl.setText(String.format("Taxable Value Total: %.2f", unitPriceTotal));
        cgstTotalLbl.setText(String.format("CGST Total: %.2f", cgstTotal));
        sgstTotalLbl.setText(String.format("SGST Total: %.2f", sgstTotal));
        grandTotalLbl.setText(String.format("Total Amount Total: %.2f", grandTotal));
    }

    public List<ReportEntry> getTableData() {
        return currentData;
    }

    public String getSummaryText() {
        if (currentData == null) return "";
        double unitPriceTotal = 0, cgstTotal = 0, sgstTotal = 0;
        for (ReportEntry e : currentData) {
            unitPriceTotal += e.getTaxableValue();
            cgstTotal      += e.getCgst();
            sgstTotal      += e.getSgst();
        }
        double grandTotal = unitPriceTotal + cgstTotal + sgstTotal;

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Taxable Value Total: %.2f\n", unitPriceTotal));
        sb.append(String.format("CGST Total: %.2f\n", cgstTotal));
        sb.append(String.format("SGST Total: %.2f\n", sgstTotal));
        sb.append(String.format("Total Amount Total: %.2f", grandTotal));
        return sb.toString();
    }
    
    public String getSummaryText_1() {
        if (currentData == null) return "";
        double unitPriceTotal = 0, cgstTotal = 0, sgstTotal = 0;
        for (ReportEntry e : currentData) {
       
            cgstTotal      += e.getCgst();
            sgstTotal      += e.getSgst();
        }
        double grandTotal = unitPriceTotal + cgstTotal + sgstTotal;

        StringBuilder sb = new StringBuilder();
    
        sb.append(String.format("CGST Total: %.2f\n", cgstTotal));
        sb.append(String.format("SGST Total: %.2f\n", sgstTotal));
        sb.append(String.format("Total Amount Total: %.2f", grandTotal));
        return sb.toString();
    }
    public void addExportCsvListener(ActionListener listener) {
        exportCsvBtn.addActionListener(listener);
    }
}
