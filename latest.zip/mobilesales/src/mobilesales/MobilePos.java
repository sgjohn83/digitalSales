package mobilesales;


import java.awt.Dimension;
import controller.StockReportsController;
import controller.StockReportsController2;

import java.awt.EventQueue;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import java.awt.FlowLayout;

import controller.BrandController;
import controller.DeleteProductController;
import controller.GSTReportController;
import controller.PrintCustomerBillController;
import controller.PurchaseController;
import controller.PurchaseReportController;
import controller.ResetPasswordController;
import controller.SalesController;
import controller.SalesReportController;
import controller.SupplierController;
import controller.UpdatePassword;
import controller.ProductListtController;
import controller.UserController;

import model.Brand;
import model.CurrentUser;
import model.ProductStock;

import model.SalesReportModel;
import model.StockItem;

import javax.swing.JDesktopPane;

import service.CustomerBillModel;
import service.GSTReportModel;
import service.GeneralPurpose;
import service.ProductStockService;
import service.PurchaseService;
import service.UserService;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.GridLayout;
import java.awt.CardLayout;
import javax.swing.BoxLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import java.awt.SystemColor;
import javax.swing.ImageIcon;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ChangeEvent;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.BevelBorder;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MobilePos extends JFrame implements MyListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField billNoTxt;
	private JTextField billDate;
	private JTextField cnameText;
	private JTextField cmobileText;
	private JTextField imeiFetchText;
	private JTextField salesCGST;
	private JTextField salesSGST;
	private JTextField salesTotalPrice;
	private JTextField salesUnitPrice;
	private JPanel salesPanel;
	private JTextField downPayment;
	private JTextField invoiceno;
	private JTextField smobile;
	private JTextField productCodeText;
	private JTextField imeiText;
	private JTextField unitPrice_1;
	private JComboBox brandCombo;
	private BrandController bc = new BrandController();
	private PurchaseController pc = new PurchaseController();
	private UserController uc = new UserController();
	private JTextField modelText;
	private JTextField ramText;
	private JTextField storageText;
	private JTable summaryTable;
	private JTextField sname;
	private JLabel totalAmountlbl;
	private double tamount = 0;
	private JPanel purchasePanel;
	private JComboBox saleUserCombo;
	private JTable saleTable;
	private JTextField reportsModelNameTxt;
	private JTable stockReportTable;
	private JComboBox reportsBrandComboBox;
	private JComboBox paymentCombo;
	private JCheckBox financechkBox;
	private JButton reportsViewBtn;
	private JComboBox reportsStatuscomboBox;

	private String username;
	private JLabel reportQuantity;
	private JLabel reportAmount;
	private JButton btnSettings;
	private JButton usersBtn;
	private JPanel AdminPanel;
	private JComboBox comboBox;
	private Timer idleTimer;
	private final long idleTimeout = 20 * 60 * 1000;
	private JTextField tblSearch;
	private JPopupMenu suggestionPopup;
	private GeneralPurpose gp;
	private JLabel dplbl;

	/**
	 * Launch the application.
	 */
	public void mobileAppPos(String username) {
		this.username = username;
		disable();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MobilePos frame = new MobilePos();
					Toolkit toolkit = Toolkit.getDefaultToolkit();
					Dimension screenSize = toolkit.getScreenSize();
					int x = (int) screenSize.getWidth();
					int y = (int) screenSize.getHeight();
					frame.setLocation(0, 0);
					// frame.setSize(new Dimension(x,y));
					frame.setSize(980, 720);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MobilePos() {

		setResizable(false);
		setTitle("Moille Shop POS");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 952, 770);
		contentPane = new JPanel();
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension screenSize = toolkit.getScreenSize();
		int y = (int) screenSize.getHeight();
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel leftPanel = new JPanel();

		leftPanel.setBackground(Color.GRAY);
		leftPanel.setBounds(10, 86, 207, 621);
		contentPane.add(leftPanel);
		leftPanel.setLayout(null);

		JButton stockButton = new JButton("Stock");

		stockButton.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/icons8-stock-64.png")));
		stockButton.setFont(new Font("Times New Roman", Font.BOLD, 18));

		stockButton.setBounds(23, 237, 174, 60);
		leftPanel.add(stockButton);

		JButton salesButton = new JButton("Sales");

		salesButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		salesButton.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/icons8-sales-48.png")));
		salesButton.setBounds(23, 70, 174, 50);
		leftPanel.add(salesButton);

		JButton reportsButton = new JButton("Reports");

		reportsButton.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/health-check.png")));
		reportsButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		reportsButton.setBounds(23, 401, 174, 42);
		leftPanel.add(reportsButton);

		usersBtn = new JButton("Users");

		usersBtn.setFont(new Font("Times New Roman", Font.BOLD, 18));
		usersBtn.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/icons8-customers-48.png")));
		usersBtn.setBounds(23, 321, 174, 60);
		leftPanel.add(usersBtn);

		btnSettings = new JButton("Admin");

		btnSettings.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/settings_10023923.png")));
		btnSettings.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnSettings.setBounds(23, 475, 174, 50);
		leftPanel.add(btnSettings);

		JButton purchaseButton = new JButton("Purchase");

		purchaseButton.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/icons8-purchase-48.png")));
		purchaseButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		purchaseButton.setBounds(23, 153, 174, 57);
		leftPanel.add(purchaseButton);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ChangePassword frame = new ChangePassword();
				frame.setVisible(true);
				new UpdatePassword(frame);
			}
			
		});
		btnChangePassword.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnChangePassword.setBounds(23, 542, 174, 50);
		leftPanel.add(btnChangePassword);

		JPanel centerPanel = new JPanel();
		centerPanel.setBackground(Color.GRAY);
		centerPanel.setBounds(239, 86, 687, 621);
		contentPane.add(centerPanel);
		centerPanel.setLayout(new CardLayout(0, 0));
		
				JPanel HomePanel = new JPanel();
				centerPanel.add(HomePanel, "name_4718725530788");

		JPanel stocksPanel = new JPanel();
		stocksPanel.setBackground(SystemColor.controlShadow);
		centerPanel.add(stocksPanel, "stocks");
		stocksPanel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(UIManager.getColor("Button.light"));
		panel_1.setBounds(23, 56, 641, 113);
		stocksPanel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_23 = new JLabel("Brand");
		lblNewLabel_23.setBounds(38, 35, 46, 14);
		panel_1.add(lblNewLabel_23);

		reportsBrandComboBox = new JComboBox();
		reportsBrandComboBox.setBounds(94, 31, 100, 22);
		panel_1.add(reportsBrandComboBox);

		JLabel lblNewLabel_24 = new JLabel("Model /Product Code");
		lblNewLabel_24.setBounds(387, 35, 126, 14);
		panel_1.add(lblNewLabel_24);

		reportsModelNameTxt = new JTextField();
		reportsModelNameTxt.setBounds(523, 32, 86, 20);
		panel_1.add(reportsModelNameTxt);
		reportsModelNameTxt.setColumns(10);

		JLabel lblNewLabel_40 = new JLabel("Stock Status");
		lblNewLabel_40.setBounds(204, 35, 108, 14);
		panel_1.add(lblNewLabel_40);

		reportsStatuscomboBox = new JComboBox();
		reportsStatuscomboBox.setModel(new DefaultComboBoxModel(new String[] { "ALL", "In Stock", "Sold" }));
		reportsStatuscomboBox.setBounds(291, 31, 86, 22);
		panel_1.add(reportsStatuscomboBox);

		reportsViewBtn = new JButton("View");

		reportsViewBtn.setBackground(new Color(255, 105, 180));
		reportsViewBtn.setBounds(520, 79, 89, 23);
		panel_1.add(reportsViewBtn);

		JLabel lblNewLabel_42 = new JLabel("Bill Type");
		lblNewLabel_42.setBounds(38, 83, 108, 14);
		panel_1.add(lblNewLabel_42);

		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "ALL", "GST", "NON_GST" }));
		comboBox.setBounds(95, 79, 162, 22);
		panel_1.add(comboBox);
		
		JLabel lblNewLabel_43 = new JLabel("Search");
		lblNewLabel_43.setBounds(291, 83, 46, 14);
		panel_1.add(lblNewLabel_43);
		
		tblSearch = new JTextField();
		tblSearch.setBounds(336, 80, 123, 20);
		panel_1.add(tblSearch);
		tblSearch.setColumns(10);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(23, 191, 641, 309);
		stocksPanel.add(scrollPane_2);
		stockReportTable = new JTable();

		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(
				new String[] { "IMEI", "Model", "Product Code","Brand", "RAM", "Storage", "Status", "Price", "Purchase Date" });
		stockReportTable.setModel(model);

		// Add table to scroll pane correctly
		scrollPane_2.setViewportView(stockReportTable); // ✅ not
														// setColumnHeaderView

		// Table appearance
		stockReportTable.setFillsViewportHeight(true);
		stockReportTable.setRowHeight(25);
		stockReportTable.setShowGrid(true);
		stockReportTable.setGridColor(Color.LIGHT_GRAY);
		stockReportTable.setSelectionBackground(new Color(204, 229, 255));
		stockReportTable.setSelectionForeground(Color.BLACK);

		// Font for table content
		stockReportTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));

		// Header formatting
		JTableHeader header2 = stockReportTable.getTableHeader();
		header2.setFont(new Font("Segoe UI", Font.BOLD, 14));
		header2.setBackground(new Color(220, 220, 220)); // Light gray header
		header2.setForeground(Color.BLACK);
		header2.setPreferredSize(new Dimension(header2.getWidth(), 30));

		JLabel lblNewLabel_41 = new JLabel("Stock Reports");
		lblNewLabel_41.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel_41.setForeground(new Color(255, 255, 255));
		lblNewLabel_41.setBackground(new Color(0, 250, 154));
		lblNewLabel_41.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_41.setBounds(221, 11, 243, 34);
		stocksPanel.add(lblNewLabel_41);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(245, 245, 220));
		panel_3.setBounds(23, 511, 641, 85);
		stocksPanel.add(panel_3);
		panel_3.setLayout(null);

		JLabel lblNewLabel_37 = new JLabel("Total Quantity:");
		lblNewLabel_37.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_37.setBounds(268, 11, 164, 23);
		panel_3.add(lblNewLabel_37);

		JLabel lblNewLabel_38 = new JLabel("Total Amount:");
		lblNewLabel_38.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_38.setBounds(268, 45, 129, 29);
		panel_3.add(lblNewLabel_38);

		reportQuantity = new JLabel("0");
		reportQuantity.setFont(new Font("Tahoma", Font.BOLD, 18));
		reportQuantity.setBounds(471, 18, 46, 14);
		panel_3.add(reportQuantity);

		reportAmount = new JLabel("0.00");
		reportAmount.setFont(new Font("Tahoma", Font.BOLD, 18));
		reportAmount.setBounds(471, 48, 134, 14);
		panel_3.add(reportAmount);

		salesPanel = new JPanel();
		salesPanel.setBackground(SystemColor.controlShadow);
		centerPanel.add(salesPanel, "sales");
		salesPanel.setLayout(null);

		JPanel panel_4 = new JPanel();
		panel_4.setBackground(SystemColor.scrollbar);
		panel_4.setBounds(10, 45, 647, 83);
		salesPanel.add(panel_4);
		panel_4.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Inoice No");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setBounds(10, 45, 131, 14);
		panel_4.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Inoice Date");
		lblNewLabel_2.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		lblNewLabel_2.setBackground(Color.GRAY);
		lblNewLabel_2.setBounds(219, 50, 109, 14);
		panel_4.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Sales Person");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_3.setBounds(419, 51, 111, 14);
		panel_4.add(lblNewLabel_3);

		billNoTxt = new JTextField();
		billNoTxt.setEditable(false);
		billNoTxt.setBounds(105, 44, 104, 20);
		panel_4.add(billNoTxt);
		billNoTxt.setColumns(10);

		billDate = new JTextField();
		billDate.setEditable(false);
		billDate.setBounds(323, 50, 86, 20);
		panel_4.add(billDate);
		billDate.setColumns(10);

		saleUserCombo = new JComboBox();
		saleUserCombo.setBounds(528, 49, 109, 22);
		panel_4.add(saleUserCombo);

		JLabel lblNewLabel_10 = new JLabel("Invoice Details");
		lblNewLabel_10.setForeground(SystemColor.windowText);
		lblNewLabel_10.setBackground(SystemColor.textHighlight);
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_10.setBounds(10, 11, 199, 14);
		panel_4.add(lblNewLabel_10);

		JPanel panel_5 = new JPanel();
		panel_5.setForeground(SystemColor.windowText);
		panel_5.setBackground(SystemColor.scrollbar);
		panel_5.setBounds(10, 131, 647, 89);
		salesPanel.add(panel_5);
		panel_5.setLayout(null);

		JLabel lblNewLabel_4 = new JLabel("Customer Name");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4.setBounds(18, 52, 128, 14);
		panel_5.add(lblNewLabel_4);

		JLabel lblNewLabel_4_1 = new JLabel("Mobile no");
		lblNewLabel_4_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4_1.setBounds(328, 52, 128, 14);
		panel_5.add(lblNewLabel_4_1);

		cnameText = new JTextField();
		cnameText.setBounds(180, 51, 128, 20);
		panel_5.add(cnameText);
		cnameText.setColumns(10);

		cmobileText = new JTextField();
		cmobileText.setBounds(466, 51, 128, 20);
		panel_5.add(cmobileText);
		cmobileText.setColumns(10);

		JLabel lblNewLabel_13 = new JLabel("Customer Details");
		lblNewLabel_13.setForeground(SystemColor.windowText);
		lblNewLabel_13.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_13.setBounds(18, 11, 221, 14);
		panel_5.add(lblNewLabel_13);

		JPanel panel_6 = new JPanel();
		panel_6.setBackground(SystemColor.scrollbar);
		panel_6.setBounds(10, 224, 647, 155);
		salesPanel.add(panel_6);
		panel_6.setLayout(null);

		JLabel lblNewLabel_5 = new JLabel("IMEI NO");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_5.setBounds(124, 55, 91, 14);
		panel_6.add(lblNewLabel_5);

		imeiFetchText = new JTextField();

		imeiFetchText.setBounds(254, 52, 247, 20);
		panel_6.add(imeiFetchText);
		imeiFetchText.setColumns(10);

		JLabel lblNewLabel_14 = new JLabel("Product Search");
		lblNewLabel_14.setForeground(SystemColor.windowText);
		lblNewLabel_14.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_14.setBounds(10, 11, 204, 14);
		panel_6.add(lblNewLabel_14);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 83, 627, 48);
		panel_6.add(scrollPane_1);

		saleTable = new JTable();
		scrollPane_1.setViewportView(saleTable);

		JPanel panel_7 = new JPanel();
		panel_7.setBackground(SystemColor.scrollbar);
		panel_7.setBounds(10, 390, 647, 163);
		salesPanel.add(panel_7);
		panel_7.setLayout(null);

		JLabel lblNewLabel_6 = new JLabel("CGSt 9% ");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_6.setBounds(257, 38, 86, 14);
		panel_7.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("SGST 9%");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_7.setBounds(443, 38, 76, 14);
		panel_7.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("Total");
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_8.setBounds(443, 138, 76, 14);
		panel_7.add(lblNewLabel_8);

		salesCGST = new JTextField();
		salesCGST.setBounds(336, 37, 86, 20);
		panel_7.add(salesCGST);
		salesCGST.setColumns(10);

		salesSGST = new JTextField();
		salesSGST.setBounds(529, 35, 86, 20);
		panel_7.add(salesSGST);
		salesSGST.setColumns(10);

		salesTotalPrice = new JTextField();

		salesTotalPrice.setBounds(529, 132, 86, 20);
		panel_7.add(salesTotalPrice);
		salesTotalPrice.setColumns(10);

		JLabel lblNewLabel_11 = new JLabel("Unit Price");
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_11.setBounds(23, 42, 102, 14);
		panel_7.add(lblNewLabel_11);

		salesUnitPrice = new JTextField();
		salesUnitPrice.setBounds(153, 35, 86, 20);
		panel_7.add(salesUnitPrice);
		salesUnitPrice.setColumns(10);

		JLabel lblNewLabel_9 = new JLabel("Payment Type");
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_9.setBounds(23, 93, 120, 14);
		panel_7.add(lblNewLabel_9);

		financechkBox = new JCheckBox("Under Finance");
		financechkBox.setFont(new Font("Times New Roman", Font.BOLD, 14));
		financechkBox.setBounds(257, 89, 120, 23);
		panel_7.add(financechkBox);

		paymentCombo = new JComboBox();
		paymentCombo.setModel(new DefaultComboBoxModel(new String[] { "Cash", "Upi" }));
		paymentCombo.setBounds(153, 89, 76, 22);
		panel_7.add(paymentCombo);

		JLabel lblNewLabel_15 = new JLabel("Sub Total");
		lblNewLabel_15.setBackground(SystemColor.scrollbar);
		lblNewLabel_15.setForeground(SystemColor.windowText);
		lblNewLabel_15.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_15.setBounds(23, 0, 180, 25);
		panel_7.add(lblNewLabel_15);

		JLabel lblNewLabel_18 = new JLabel("Down Payment");
		lblNewLabel_18.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_18.setBounds(391, 95, 152, 14);
		panel_7.add(lblNewLabel_18);

		downPayment = new JTextField();
		downPayment.setText("0");
		downPayment.setBounds(529, 92, 97, 20);
		panel_7.add(downPayment);
		downPayment.setColumns(10);
		
		JLabel lblNewLabel_44 = new JLabel("DP Price");
		lblNewLabel_44.setForeground(Color.RED);
		lblNewLabel_44.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel_44.setBounds(23, 133, 86, 14);
		panel_7.add(lblNewLabel_44);
		
	    dplbl = new JLabel("0.00");
		dplbl.setFont(new Font("Times New Roman", Font.BOLD, 18));
		dplbl.setForeground(Color.RED);
		dplbl.setBounds(120, 135, 46, 14);
		panel_7.add(dplbl);

		JLabel lblNewLabel_12 = new JLabel("Sales Entry");
		lblNewLabel_12.setFont(new Font("Verdana", Font.BOLD, 28));
		lblNewLabel_12.setBounds(253, 0, 203, 47);
		salesPanel.add(lblNewLabel_12);

		JButton btnNewButton = new JButton("Reset");
		btnNewButton.setBounds(364, 564, 89, 33);
		salesPanel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Save & Print");

		btnNewButton_1.setBounds(489, 565, 119, 32);
		salesPanel.add(btnNewButton_1);

		purchasePanel = new JPanel();
		purchasePanel.setBackground(Color.LIGHT_GRAY);
		centerPanel.add(purchasePanel, "purchase");
		purchasePanel.setLayout(null);

		JLabel lblNewLabel_17 = new JLabel("Purchase Entry");
		lblNewLabel_17.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_17.setBounds(226, 11, 193, 26);
		purchasePanel.add(lblNewLabel_17);

		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.scrollbar);
		panel.setBounds(10, 71, 667, 111);
		purchasePanel.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_19 = new JLabel("Invoice Details");
		lblNewLabel_19.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_19.setBounds(22, 11, 180, 14);
		panel.add(lblNewLabel_19);

		JLabel lblNewLabel_20 = new JLabel("Invoice no");
		lblNewLabel_20.setBounds(22, 48, 84, 14);
		panel.add(lblNewLabel_20);

		invoiceno = new JTextField();
		invoiceno.setBounds(116, 45, 86, 20);
		panel.add(invoiceno);
		invoiceno.setColumns(10);

		JLabel lblNewLabel_21 = new JLabel("Invoice Date");
		lblNewLabel_21.setBounds(245, 48, 86, 14);
		panel.add(lblNewLabel_21);

		JLabel lblNewLabel_22 = new JLabel("User");
		lblNewLabel_22.setBounds(448, 48, 46, 14);
		panel.add(lblNewLabel_22);

		JComboBox userCombo = new JComboBox();
		userCombo.setBounds(504, 44, 105, 22);
		panel.add(userCombo);
		uc.loadUsernamesIntoComboBox(userCombo);

		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(323, 45, 97, 20);
		panel.add(dateChooser);

		JButton svbtn = new JButton("Save");

		svbtn.setBounds(480, 552, 133, 37);
		purchasePanel.add(svbtn);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				int selectedIndex = tabbedPane.getSelectedIndex();
				String selectedTitle = tabbedPane.getTitleAt(selectedIndex);

				// Show Save button only in "Summary" tab
				if (selectedTitle.equalsIgnoreCase("Summary")) {
					svbtn.setVisible(true);
				} else {
					svbtn.setVisible(false);
				}
			}
		});

		stockReportTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				String status = table.getValueAt(row, 6).toString(); // 5th
																		// column
					System.out.println(status);													// =
																		// Status
																		// (after
																		// adding
																		// RAM,
																		// Storage)

				if (!isSelected) {
					if (status.equalsIgnoreCase("In Stock")) {
						c.setBackground(new Color(200, 255, 200)); // light
																	// green
					} else if (status.equalsIgnoreCase("Sold")) {
						c.setBackground(new Color(255, 102, 102)); // light red
					} else {
						c.setBackground(Color.WHITE); // default color
					}
				} else {
					c.setBackground(table.getSelectionBackground()); // selection
																		// background
				}

				return c;
			}
		});

		tabbedPane.setBounds(20, 193, 655, 310);
		purchasePanel.add(tabbedPane);

		JPanel supplierPanel = new JPanel();
		supplierPanel.setBackground(SystemColor.scrollbar);
		tabbedPane.addTab("Supplier", null, supplierPanel, null);
		supplierPanel.setLayout(null);

		JLabel lblNewLabel_25 = new JLabel("Supplier Name");
		lblNewLabel_25.setBounds(146, 47, 110, 14);
		supplierPanel.add(lblNewLabel_25);

		JLabel lblNewLabel_26 = new JLabel("Mobile No");
		lblNewLabel_26.setBounds(146, 82, 66, 14);
		supplierPanel.add(lblNewLabel_26);

		JLabel lblNewLabel_27 = new JLabel("Address");
		lblNewLabel_27.setBounds(146, 120, 46, 14);
		supplierPanel.add(lblNewLabel_27);

		smobile = new JTextField();
		smobile.setBounds(245, 79, 86, 20);
		supplierPanel.add(smobile);
		smobile.setColumns(10);

		JTextArea saddr = new JTextArea();
		saddr.setBounds(245, 115, 150, 71);
		supplierPanel.add(saddr);

		JComboBox supplierCombo = new JComboBox();

		supplierCombo.setBounds(371, 43, 91, 22);
		supplierPanel.add(supplierCombo);
		pc.loadSupplierComboBox(supplierCombo);

		sname = new JTextField();
		sname.setBounds(245, 44, 102, 20);
		supplierPanel.add(sname);
		sname.setColumns(10);

		JPanel productPanel = new JPanel();
		productPanel.setBackground(SystemColor.scrollbar);
		tabbedPane.addTab("Product Details", null, productPanel, null);
		productPanel.setLayout(null);

		JLabel lblNewLabel_28 = new JLabel("Brand");
		lblNewLabel_28.setBounds(20, 21, 46, 14);
		productPanel.add(lblNewLabel_28);

		brandCombo = new JComboBox();
		brandCombo.setBounds(107, 17, 115, 22);
		productPanel.add(brandCombo);
		bc.loadBrandsIntoComboBox(brandCombo);

		JLabel lblNewLabel_29 = new JLabel("Product Code");
		lblNewLabel_29.setBounds(20, 86, 117, 14);
		productPanel.add(lblNewLabel_29);

		productCodeText = new JTextField();
		productCodeText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		productCodeText.setBounds(107, 83, 117, 20);
		productPanel.add(productCodeText);
		productCodeText.setColumns(10);

		JLabel lblNewLabel_30 = new JLabel("Model");
		lblNewLabel_30.setBounds(20, 58, 137, 14);
		productPanel.add(lblNewLabel_30);

		JLabel lblNewLabel_31 = new JLabel("Imei no");
		lblNewLabel_31.setBounds(20, 119, 46, 14);
		productPanel.add(lblNewLabel_31);

		imeiText = new JTextField();
		imeiText.setBounds(107, 116, 137, 20);
		productPanel.add(imeiText);
		imeiText.setColumns(10);

		JLabel lblNewLabel_32 = new JLabel("Ram");
		lblNewLabel_32.setBounds(20, 159, 46, 14);
		productPanel.add(lblNewLabel_32);

		JComboBox ramCombo = new JComboBox();
		ramCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedRam = (String) ramCombo.getSelectedItem();

				ramText.setText(selectedRam);
			}
		});
		ramCombo.setModel(new DefaultComboBoxModel(
				new String[] { "2GB", "3GB", "4GB", "6GB", "8GB", "10GB", "12GB", "16GB", "18GB", "20GB", "24GB" }));
		ramCombo.setBounds(212, 155, 58, 22);
		productPanel.add(ramCombo);

		JLabel lblNewLabel_33 = new JLabel("Storage");
		lblNewLabel_33.setBounds(20, 194, 73, 14);
		productPanel.add(lblNewLabel_33);

		JComboBox storageCombo = new JComboBox();
		storageCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedStroage = (String) storageCombo.getSelectedItem();

				storageText.setText(selectedStroage);

			}
		});
		storageCombo
				.setModel(new DefaultComboBoxModel(new String[] { "32GB", "64GB", "128GB", "256GB", "512GB", "1TB" }));
		storageCombo.setBounds(212, 190, 58, 22);
		productPanel.add(storageCombo);

		JLabel lblNewLabel_34 = new JLabel("Net Price");
		lblNewLabel_34.setBounds(348, 21, 87, 14);
		productPanel.add(lblNewLabel_34);

		unitPrice_1 = new JTextField();
		unitPrice_1.setBounds(455, 18, 86, 20);
		productPanel.add(unitPrice_1);
		unitPrice_1.setColumns(10);

		JButton btnNewButton_3 = new JButton("Reset");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				productCodeText.setText("");
				imeiText.setText("");
				unitPrice_1.setText("");
				ramText.setText("");
				storageText.setText("");

				// Reset combos to default (index 0 or -1 based on
				// initialization)
				brandCombo.setSelectedIndex(0);
				ramCombo.setSelectedIndex(0);
				storageCombo.setSelectedIndex(0);

				// Optionally set focus back to productCodeText
				productCodeText.requestFocus();
			}

		});
		btnNewButton_3.setBounds(162, 248, 89, 23);
		productPanel.add(btnNewButton_3);

		JButton addProductbtn = new JButton("Add Product");

		addProductbtn.setBounds(331, 248, 104, 23);
		productPanel.add(addProductbtn);

		JButton btnNewButton_6 = new JButton("Add");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BrandAdd frame = new BrandAdd(MobilePos.this);
				frame.setVisible(rootPaneCheckingEnabled);
			}
		});
		btnNewButton_6.setBounds(232, 17, 69, 23);
		productPanel.add(btnNewButton_6);

		JComboBox modelCombo = new JComboBox();
		modelCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String modelName = (String) modelCombo.getSelectedItem();
				modelText.setText(modelName);
				PurchaseController ps = new PurchaseController();
				String code = ps.fetchProductCode(brandCombo.getSelectedItem().toString(),modelName);
				productCodeText.setText(code);
			}
		});
		modelCombo.setBounds(254, 50, 73, 22);
		productPanel.add(modelCombo);

		modelText = new JTextField();
		modelText.setText("Select Model");
		modelText.setBounds(107, 50, 137, 22);
		productPanel.add(modelText);
		modelText.setColumns(10);

		brandCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedBrand = (String) brandCombo.getSelectedItem();
				bc.loadmodelCombo(modelCombo, selectedBrand);
			}
		});

		ramText = new JTextField();
		ramText.setBounds(107, 156, 86, 20);
		productPanel.add(ramText);
		ramText.setColumns(10);

		storageText = new JTextField();
		storageText.setBounds(107, 194, 86, 20);
		productPanel.add(storageText);
		storageText.setColumns(10);

		JLabel lblNewLabel_35 = new JLabel("Type");
		lblNewLabel_35.setBounds(348, 67, 46, 14);
		productPanel.add(lblNewLabel_35);

		JComboBox billTypeCombo = new JComboBox();
		billTypeCombo.setModel(new DefaultComboBoxModel(new String[] { "GST", "NON_GST" }));
		billTypeCombo.setBounds(454, 64, 87, 20);
		productPanel.add(billTypeCombo);

		JPanel summaryPanel = new JPanel();
		tabbedPane.addTab("Summary", null, summaryPanel, null);
		tabbedPane.setBackgroundAt(2, SystemColor.controlHighlight);
		summaryPanel.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 11, 630, 233);
		summaryPanel.add(scrollPane);

		totalAmountlbl = new JLabel("00.00");
		totalAmountlbl.setFont(new Font("Times New Roman", Font.BOLD, 27));
		totalAmountlbl.setBounds(441, 518, 193, 31);
		totalAmountlbl.setForeground(Color.GREEN);
		totalAmountlbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
		totalAmountlbl.setHorizontalAlignment(SwingConstants.RIGHT);
		purchasePanel.add(totalAmountlbl);

		summaryTable = new JTable();
		scrollPane.setViewportView(summaryTable); // ✅ Correct way to display
													// the full table

		String[] columnHeaders = { "Brand", "Product Code", "Model", "IMEI No", "RAM", "Storage", "Unit Price" };

		DefaultTableModel modelTable = new DefaultTableModel(columnHeaders, 0);
		summaryTable.setModel(modelTable);

		summaryTable.getColumnModel().getColumn(3).setPreferredWidth(300);
		summaryTable.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Table
																	// cell font
		summaryTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));

		// 3. Set background and foreground color
		summaryTable.setBackground(new Color(240, 248, 255)); // Light blue-like
																// color
		summaryTable.setForeground(Color.BLACK); // Text color

		// 4. Optional: Set row height
		summaryTable.setRowHeight(25);

		// 5. Optional: Header background color
		JTableHeader header = summaryTable.getTableHeader();
		header.setBackground(new Color(200, 200, 255));
		header.setForeground(Color.BLACK);
		JButton btnNewButton_4 = new JButton("Reset");
	
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				   JLabel message = new JLabel("Are you sure you want to reset all data?");
	                message.setFont(new Font("Arial", Font.BOLD, 18));
	                message.setForeground(Color.RED);

	                // Show the dialog
	                int option = JOptionPane.showConfirmDialog(null,
	                        message,
	                        "Confirm Reset",
	                        JOptionPane.YES_NO_OPTION,
	                        JOptionPane.WARNING_MESSAGE);

	                if (option == JOptionPane.YES_OPTION) {
	                    JOptionPane.showMessageDialog(null, "data has been reset.");
	                    updatePurchase();
	                }
	                else
	                {
	                	return;
	                }
	               
			}
		});
		btnNewButton_4.setBounds(535, 248, 89, 23);
		summaryPanel.add(btnNewButton_4);

		addProductbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (imeiText.getText().trim().isEmpty() || invoiceno.getText().trim().isEmpty()
						|| unitPrice_1.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please fill all required fields", "Warning",
							JOptionPane.WARNING_MESSAGE);
					return; // stop further processing
				}
				if (dateChooser.getDate() == null) {
					JOptionPane.showMessageDialog(null, "Please select a date", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}
				String brand = brandCombo.getSelectedItem().toString();
				String productCode = productCodeText.getText();
				String modelVal = modelText.getText();
				String imei = imeiText.getText();
				ProductStockService pss = new ProductStockService();
				boolean k = pss.checkImei(imei);

				if (!isValidMobile(smobile.getText()) || !isValidName(sname.getText())) {
					JOptionPane.showMessageDialog(null, "Invalid name/mobile no");
					return;
				}
				if (!isValidIMEI(imei)) {
					JOptionPane.showMessageDialog(null, "IMEI invalid!", "invalid", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if (k) {
					JOptionPane.showMessageDialog(null, "IMEI already exists!", "Duplicate",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				PurchaseService ps = new PurchaseService();
				boolean ik = ps.checkInvoiceNo(invoiceno.getText());
				if (ik) {
					JOptionPane.showMessageDialog(null, "Invoice No already exists!", "Duplicate",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				String ram = ramText.getText();
				String storage = storageText.getText();
				if (!isValidAmount2(unitPrice_1.getText())) {
					JOptionPane.showMessageDialog(null, "invalid amount!", "invalid", JOptionPane.WARNING_MESSAGE);
					return;
				}
				double unitPrice = Double.parseDouble(unitPrice_1.getText());

				tamount = tamount + unitPrice;
				totalAmountlbl.setText(String.valueOf(tamount));
				// double discount = Double.parseDouble(discount_1.getText());

				// double rate = unitPrice - discount;
				// double cgst = rate * 0.09; // 9%
				// double sgst = rate * 0.09; // 9%
				// double amount = rate + cgst + sgst;
				// Assume you've parsed and calculated prices
				Object[] row = { brand, productCode, modelVal, imei, ram, storage, unitPrice, "", "", "", "", "" };
				modelTable.addRow(row);
				imeiText.setText("");

			}
		});

		JLabel totalbillLbl = new JLabel("Total Bill");
		totalbillLbl.setFont(new Font("Times New Roman", Font.BOLD, 30));
		totalbillLbl.setBounds(286, 514, 159, 37);
		totalbillLbl.setForeground(Color.WHITE);
		totalbillLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
		purchasePanel.add(totalbillLbl);

		JPanel UsersPanel = new JPanel();
		UsersPanel.setBackground(new Color(192, 192, 192));
		UsersPanel.setForeground(UIManager.getColor("Button.focus"));
		centerPanel.add(UsersPanel, "users");
		UsersPanel.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(169, 169, 169));
		panel_2.setBounds(85, 72, 457, 452);
		UsersPanel.add(panel_2);
		panel_2.setLayout(null);

		JButton btnNewButton_2 = new JButton("Add Users");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserService userService = new UserService(); // You'll need to
																// implement
																// this
				new AddUsers(userService).setVisible(true);
			}
		});
		btnNewButton_2.setBounds(175, 49, 148, 78);
		panel_2.add(btnNewButton_2);

		JButton btnNewButton_2_1 = new JButton("Edit Users");
		btnNewButton_2_1.setBounds(175, 166, 148, 78);
		panel_2.add(btnNewButton_2_1);

		JButton btnNewButton_2_2 = new JButton("Delete Users");
		btnNewButton_2_2.setBounds(175, 287, 148, 78);
		panel_2.add(btnNewButton_2_2);

		JLabel lblNewLabel_36 = new JLabel("Users ");
		lblNewLabel_36.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_36.setBackground(UIManager.getColor("Button.focus"));
		lblNewLabel_36.setBounds(310, 11, 161, 50);
		UsersPanel.add(lblNewLabel_36);

		JPanel ReportsPanel = new JPanel();
		ReportsPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		centerPanel.add(ReportsPanel, "reports");
		ReportsPanel.setLayout(null);

		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(72, 61, 139));
		panel_8.setBounds(0, 0, 713, 654);
		ReportsPanel.add(panel_8);
		panel_8.setLayout(null);

		JButton btnNewButton_5 = new JButton("Sales Report");

		btnNewButton_5.setBounds(23, 153, 123, 98);
		panel_8.add(btnNewButton_5);

		JButton btnGstReports = new JButton("GST Reports");
		btnGstReports.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JFrame frame = new JFrame("GST Report");
						frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
						GSTReportsView view = new GSTReportsView();
						try {
							new GSTReportController(view, new GSTReportModel());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						frame.getContentPane().add(view);
						frame.pack();
						frame.setLocationRelativeTo(null);
						frame.setVisible(true);
					}
				});

			}
		});
		btnGstReports.setBounds(175, 153, 123, 98);
		panel_8.add(btnGstReports);

		JLabel lblNewLabel_39 = new JLabel("Reports");
		lblNewLabel_39.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_39.setForeground(Color.WHITE);
		lblNewLabel_39.setBounds(238, 45, 135, 42);
		panel_8.add(lblNewLabel_39);

		JButton btnPrintLastBill = new JButton("Print Last Bill");
		btnPrintLastBill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				PrintCustomerBill view = new PrintCustomerBill();

				CustomerBillModel model = new CustomerBillModel();
				// Create controller and pass view and model
				new PrintCustomerBillController(view, model);

				// Make the frame visible
				view.setVisible(true);
			}
		});
		btnPrintLastBill.setBounds(528, 153, 123, 98);
		panel_8.add(btnPrintLastBill);

		JButton btnPurchaseReports = new JButton("Purchase Reports");
		btnPurchaseReports.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PurchaseReportView view = new PurchaseReportView();

				// (your own service implementing the DB logic)
				try {
					new PurchaseReportController(view);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				view.setVisible(true);
			}
		});
		btnPurchaseReports.setBounds(360, 153, 123, 98);
		panel_8.add(btnPurchaseReports);
		
		JButton btnNewButton_5_1 = new JButton("Stock Reports");
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StockReportView srv = new StockReportView();
				new StockReportsController2(srv);
				srv.setVisible(true);
			}
		});
		btnNewButton_5_1.setBounds(23, 299, 123, 98);
		panel_8.add(btnNewButton_5_1);

		AdminPanel = new JPanel();
		centerPanel.add(AdminPanel, "admin");
		AdminPanel.setLayout(null);

		JButton btnNewButton_7 = new JButton("Delete Product");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				DeleteProductView view = new DeleteProductView();

				new DeleteProductController(view);
				view.setVisible(true);
			}
		});

		btnNewButton_7.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnNewButton_7.setBounds(22, 37, 159, 133);
		AdminPanel.add(btnNewButton_7);

		JButton btnDeleteInvoice = new JButton("Delete Invoice");
		btnDeleteInvoice.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnDeleteInvoice.setBounds(239, 37, 172, 132);
		AdminPanel.add(btnDeleteInvoice);

		JButton btnUpdat = new JButton("Update Product");
		btnUpdat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ProductList pl = new ProductList();
				pl.setVisible(true);
				new ProductListtController(pl);
			}
		});
		btnUpdat.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnUpdat.setBounds(27, 245, 159, 117);
		AdminPanel.add(btnUpdat);

		JButton btnUpdateInvoice = new JButton("Update Invoice");
		btnUpdateInvoice.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnUpdateInvoice.setBounds(238, 245, 173, 117);
		AdminPanel.add(btnUpdateInvoice);

		JButton btnUpdateBrand = new JButton("Update Brand");
		btnUpdateBrand.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnUpdateBrand.setBounds(22, 439, 159, 117);
		AdminPanel.add(btnUpdateBrand);

		JButton btnPriceDrop = new JButton("Price Drop");
		btnPriceDrop.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnPriceDrop.setBounds(239, 439, 172, 117);
		AdminPanel.add(btnPriceDrop);

		JButton btnBackuprest = new JButton("Backup/Restore");
		btnBackuprest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						new DBBackup().setVisible(true);
					}
				});
			}
		});
		btnBackuprest.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnBackuprest.setBounds(474, 38, 172, 132);
		AdminPanel.add(btnBackuprest);
		
		JButton btnResetPassword = new JButton("Reset Password");
		btnResetPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetPassword rp = new ResetPassword();
				new ResetPasswordController(rp);
				rp.setVisible(true);
			}
		});
		btnResetPassword.setFont(new Font("Microsoft YaHei", Font.BOLD, 17));
		btnResetPassword.setBounds(473, 245, 173, 117);
		AdminPanel.add(btnResetPassword);

		JPanel toppANEL = new JPanel();
		toppANEL.setBackground(Color.LIGHT_GRAY);
		toppANEL.setBounds(10, 11, 916, 64);
		contentPane.add(toppANEL);
		toppANEL.setLayout(null);

		JLabel lblNewLabel = new JLabel("DIGITAL CELL CARE");
		lblNewLabel.setBounds(281, 11, 444, 42);
		toppANEL.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(0, 0, 139));
		lblNewLabel.setBackground(new Color(128, 128, 128));
		lblNewLabel.setFont(new Font("Cambria", Font.BOLD, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel lblNewLabel_16 = new JLabel("");
		lblNewLabel_16.setIcon(new ImageIcon(MobilePos.class.getResource("/resource/icons/app_11500001 (1).png")));
		lblNewLabel_16.setBounds(346, 11, 43, 42);
		toppANEL.add(lblNewLabel_16);

		purchaseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cl = (CardLayout) (centerPanel.getLayout());
				cl.show(centerPanel, "purchase");
			}
		});

		svbtn.addActionListener(new ActionListener() {
			private Date selectedDate;

			public void actionPerformed(ActionEvent e) {

				JLabel message = new JLabel("Do you want to Save Data?");
				message.setFont(new Font("Arial", Font.BOLD, 18));
				message.setForeground(new Color(0, 128, 0)); // Dark green

				int option = JOptionPane.showConfirmDialog(null,
				        message,
				        "Confirm Save",
				        JOptionPane.YES_NO_OPTION,
				        JOptionPane.INFORMATION_MESSAGE);

				if (option == JOptionPane.YES_OPTION) {
				    // Save and print logic here
				  
				}
				else
				{
					 JOptionPane.showMessageDialog(null, "Save Cancelled!");
					return;
				}
				
				
				String pbillno = invoiceno.getText();

				selectedDate = dateChooser.getDate();// Read date
				System.out.print(selectedDate);
				DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				String formattedDate = sdf.format(selectedDate);
				System.out.println(formattedDate);
				String uname = (String) userCombo.getSelectedItem();
				String spname = sname.getText();

				String spmobile = smobile.getText();

				String spaddr = saddr.getText();
				String brand = (String) brandCombo.getSelectedItem();
				try {
					pc.sendPurchaseDetailsToController(pbillno, formattedDate, uname, spname, spmobile, spaddr, brand,
							summaryTable, MobilePos.this, totalAmountlbl, (String) billTypeCombo.getSelectedItem());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		salesTotalPrice.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				double price = Double.parseDouble(salesTotalPrice.getText());
				double unitPrice = price / 1.18;
				double cgst = unitPrice * 0.09;
				double sgst = unitPrice * 0.09;
				DecimalFormat df = new DecimalFormat("#.##");

				salesUnitPrice.setText(df.format(unitPrice));
				salesCGST.setText(df.format(cgst));
				salesSGST.setText(df.format(sgst));

			}
		});

		salesTotalPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double price = Double.parseDouble(salesTotalPrice.getText());
				double unitPrice = price / 1.18;
				double cgst = unitPrice * 0.09;
				double sgst = unitPrice * 0.09;
				DecimalFormat df = new DecimalFormat("#.##");
				salesUnitPrice.setText(df.format(unitPrice));
				salesCGST.setText(df.format(cgst));
				salesSGST.setText(df.format(sgst));

			}
		});
		supplierCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String key = (String) supplierCombo.getSelectedItem();
				sname.setText(key);
				pc.loadSupplierDetails(key, smobile, saddr);
			}
		});

		salesButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cl = (CardLayout) (centerPanel.getLayout());
				cl.show(centerPanel, "sales");
				refreshSalesScreen();
			}

		});

		imeiFetchText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SalesController sc = new SalesController();
				ProductStock res = null;
				try {
					res = sc.getProductStockByIMEI(imeiFetchText.getText());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				updateSaleTableData(res);
			}

		});
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				SalesController sc = new SalesController();

				String name = cnameText.getText();
				String mobile = cmobileText.getText();
				if (name.isEmpty() || mobile.isEmpty() || !isValidName(name) || !isValidMobile(mobile)) {
					JOptionPane.showMessageDialog(null, "Customer name and mobile number are required.", "Input Error",
							JOptionPane.ERROR_MESSAGE);
					return; // Stop further processing
				}
				String imei = imeiFetchText.getText().trim();
				if (imei.isEmpty() || !isValidIMEI(imei)) {
					JOptionPane.showMessageDialog(null, "Please enter an IMEI number.", "Input Required",
							JOptionPane.WARNING_MESSAGE);
					return; // Stop further processing
				}
				ProductStockService pss = new ProductStockService();
				Boolean r = pss.checkImei(imei);
				if (!r) {
					JOptionPane.showMessageDialog(null, "Please enter a valid imei.", "Invalid EMI",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				String invoice_no = billNoTxt.getText();
				//SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				//String invoice_date = sdf.format(new Date());
				//System.out.println("Current Date & Time: " + invoice_date);
				String invoice_date = new DateTimeFetcher().getCurrentDateTime();
				String user = (String) saleUserCombo.getSelectedItem();
				String payment_type = (String) paymentCombo.getSelectedItem();
				Boolean isFinanced = financechkBox.isSelected();

				double downpayment = Double.parseDouble(downPayment.getText());
				if (downPayment.getText().isEmpty()) {
					downpayment = 0.00;
				}
				if (!isValidAmount(salesTotalPrice.getText())) {
					JOptionPane.showMessageDialog(null, "Please enter 0 valid amount.", "Input Required",
							JOptionPane.WARNING_MESSAGE);
					return; // Stop further processing
				}
				double total = Double.parseDouble(salesTotalPrice.getText());
				double cgst = Double.parseDouble(salesCGST.getText());
				double sgst = Double.parseDouble(salesSGST.getText());
				double uprice = Double.parseDouble(salesUnitPrice.getText());
				int choice = showConfirmationDialog();
				if(choice==-1)
				{
					return;
				}
			
				try {
					sc.addSalesToDB(imeiFetchText.getText(), name, mobile, invoice_no, invoice_date, user, payment_type,
							isFinanced, downpayment, total, uprice, cgst, sgst, MobilePos.this);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
         tblSearch.getDocument().addDocumentListener(new DocumentListener() {
			
			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				filter();
			}
			
			

			@Override
			public void insertUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				filter();
			}
			
			@Override
			public void changedUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}
			private void filter() {
				   String searchText = tblSearch.getText().toLowerCase();
	                TableRowSorter<TableModel> tempSorter = new TableRowSorter<TableModel>(model) {
	                    public void toggleSortOrder(int column) {} // Prevent sorting
	                };
	                tempSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
	                stockReportTable.setRowSorter(tempSorter);
				
			}
		});

		stockButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				CardLayout cl = (CardLayout) (centerPanel.getLayout());
				cl.show(centerPanel, "stocks");
				loadStocksScreen();
			}

		});

		reportsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				CardLayout cl = (CardLayout) (centerPanel.getLayout());
				cl.show(centerPanel, "reports");

			}
		});

		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						SalesReportModel model = new SalesReportModel();
						SalesReportView view = new SalesReportView();
						new SalesReportController(model, view);
						view.setVisible(true);
					}
				});
			}
		});
		usersBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				CardLayout cl = (CardLayout) (centerPanel.getLayout());
				cl.show(centerPanel, "users");

			}
		});

		btnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cl = (CardLayout) (centerPanel.getLayout());
				cl.show(centerPanel, "admin");
			}
		});

		if (!CurrentUser.getUsername().equals("admin")) {
			btnSettings.setEnabled(false);
			usersBtn.setEnabled(false);
		}

		
	}


	public void refreshSalesScreen() {

		LocalDate today = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		billDate.setText(today.format(formatter));
		String invoiceData = null;
		try {
			invoiceData = BillNumber.generateInvoiceNumber();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		billNoTxt.setText(invoiceData);
		UserController uc = new UserController();
		uc.loadUsernamesIntoComboBox(saleUserCombo);

	}

	@Override
	public void updateListener() {
		bc.loadBrandsIntoComboBox(brandCombo);

	}

	@Override
	
	public void updatePurchase() {

		DefaultTableModel model = (DefaultTableModel) summaryTable.getModel();
		model.setRowCount(0);
		invoiceno.setText("");
		imeiText.setText("");
		totalAmountlbl.setText("");
		tamount = 0;

	}

	public void updateSaleTableData(ProductStock res) {

		String[] columnHeaders = {

				"Brand", "Model", "RAM", "Storage" };
		if (res == null || res.getProduct() == null || res.getProduct().getBrand() == null) {
			JOptionPane.showMessageDialog(null, "Invalid product or brand information.");
			return;
		}

		// Get the table model
		DefaultTableModel model = (DefaultTableModel) saleTable.getModel(); // Replace
																			// 'salesTable'
																			// with
																			// your
																			// JTable
																			// reference
		model.setColumnIdentifiers(columnHeaders);
		// Extract product details

		String brand = res.getProduct().getBrand().getBrandName();
		String modelNumber = res.getProduct().getModel();
		String ram = res.getProduct().getRam();
		String storage = res.getProduct().getStorage();
		double price =  res.getSellingPrice();

		double unitPrice = price / 1.18;
		double cgst = unitPrice * 0.09;
		double sgst = unitPrice * 0.09;

		saleTable.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Table cell
																	// font
		saleTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));

		// 3. Set background and foreground color
		saleTable.setBackground(new Color(240, 248, 255)); // Light blue-like
															// color
		saleTable.setForeground(Color.BLACK); // Text color

		// 4. Optional: Set row height
		saleTable.setRowHeight(25);

		// 5. Optional: Header background color
		JTableHeader header = saleTable.getTableHeader();
		header.setBackground(new Color(200, 200, 255));
		header.setForeground(Color.BLACK);

		// Add row to the table
		model.addRow(new Object[] { brand, modelNumber, ram, storage });

		DecimalFormat df = new DecimalFormat("#.##");
		salesTotalPrice.setText("");//(df.format(price));
		dplbl.setText(df.format(price));
		salesUnitPrice.setText(df.format(unitPrice));
		salesCGST.setText(df.format(cgst));
		salesSGST.setText(df.format(sgst));

	}

	public void loadStocksScreen() {

		new StockReportsController(this);

	}

	@Override
	public void updateSales() {
		refreshSalesScreen();
		salesTotalPrice.setText("0.00");
		salesUnitPrice.setText("0.00");
		salesCGST.setText("0.00");
		salesSGST.setText("0.00");
		imeiFetchText.setText("");

		DefaultTableModel model = (DefaultTableModel) saleTable.getModel();
		model.setRowCount(0);
		cnameText.setText("");
		cmobileText.setText("");
		downPayment.setText("0.00");
		financechkBox.setSelected(false);
		paymentCombo.setSelectedIndex(0);

	}

	public boolean isValidIMEI(String imei) {
		if (imei.length() != 15 || !imei.matches("\\d+")) {
			return false;
		}

		int sum = 0;
		for (int i = 0; i < 15; i++) {
			int digit = Character.getNumericValue(imei.charAt(i));
			if ((i % 2) == 1) { // Even position from right (index starts at 0)
				digit *= 2;
				if (digit > 9)
					digit -= 9;
			}
			sum += digit;
		}
		return (sum % 10 == 0);
	}

	public boolean isValidMobile(String mobile) {
		return mobile.matches("^[6-9]\\d{9}$");
	}

	public boolean isValidName(String name) {
		return name.matches("^[a-zA-Z ]{2,}$");
	}

	public boolean isValidAmount(String amount) {
		return amount.matches("^\\d+(\\.\\d{1,2})?$");
	}

	public boolean isValidAmount2(String amount) {
		if (amount.matches("^\\d+(\\.\\d{1,2})?$")) {
			double value = Double.parseDouble(amount);
			return true;
		}
		return false;
	}

	public void setBrandList(java.util.List<String> brands) {
		reportsBrandComboBox.addItem("All");
		for (String b : brands)
			reportsBrandComboBox.addItem(b);
	}

	public void setSearchAction(ActionListener listener) {
		System.out.println("Listener attached"); // debug log
		reportsViewBtn.addActionListener(e -> {
			System.out.println("Search button clicked"); // test click
			listener.actionPerformed(e);
		});
		salesTotalPrice.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {

			}
		});


	}

	public JTable getTable() {
		return stockReportTable;
	}

	public String getSelectedBrand() {
		return (String) reportsBrandComboBox.getSelectedItem();
	}

	public String getSelectedStatus() {
		return (String) reportsStatuscomboBox.getSelectedItem();
	}

	public String getModelSearchText() {
		return reportsModelNameTxt.getText().trim();
	}

	public JLabel getTotalQtyLabel() {
		return reportQuantity;
	}

	public JLabel getTotalAmountLabel() {
		return reportAmount;
	}

	public String getBillTypeComboBox() {
		return (String) comboBox.getSelectedItem();
	}
	
	
	public  int showConfirmationDialog() {

		  String unitPrice = salesUnitPrice.getText();
	        String cgst = salesCGST.getText();
	        String sgst = salesSGST.getText();
	        String total = salesTotalPrice.getText();
	        String paymentType = paymentCombo.getSelectedItem().toString();
	        boolean underFinance = financechkBox.isSelected();
	        String downPay = downPayment.getText();

	        // Prepare checklist summary
	        StringBuilder checklist = new StringBuilder();
	   
	  
	        checklist.append("✔ Under Finance: ").append(underFinance ? "Yes" : "No").append("\n");
	        checklist.append("✔ Down Payment: ").append(downPay).append("\n");
	        checklist.append("✔ Total: ").append(total).append("\n");

	        // Show confirmation dialog
	        int option = JOptionPane.showOptionDialog(
	                null,
	                new JTextArea(checklist.toString()),
	                "Confirm Sale Details",
	                JOptionPane.YES_NO_OPTION,
	                JOptionPane.PLAIN_MESSAGE,
	                null,
	                new String[]{"Yes", "No"}, // Custom button texts
	                "No" // Default selection
	        );

	        if (option == JOptionPane.YES_OPTION) {
	            System.out.println("User confirmed the sale.");
	        } else {
	            System.out.println("User cancelled the sale.");
	        	return -1;
	        }
			return 1;
		
}
}
