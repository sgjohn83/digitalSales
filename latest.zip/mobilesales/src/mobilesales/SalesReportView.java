package mobilesales;

import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.*;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.toedter.calendar.JDateChooser;

import controller.UpdateSalesController;
import model.CurrentUser;
import model.SaleRecord;
import model.SaleReportRow;

public class SalesReportView extends JFrame {
	private JDateChooser startDateChooser, endDateChooser;
	private JComboBox<String> brandComboBox, financeFilterComboBox;
	private JLabel totalSalesLabel, totalTransactionsLabel, downPaymentTotalLabel;
	private JLabel totalPurchaseLabel, profitLossLabel,netProfitLabel,netLossLabel;
	private JTable reportTable;
	private DefaultTableModel reportModel;
	private TableRowSorter<DefaultTableModel> sorter;
	private JTextField searchField;
	private JButton generateReportButton, exportButton;

	public SalesReportView() {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception ignored) {
		}
		setTitle("Sales Report");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1100, 600);
		setLocationRelativeTo(null);
		initComponents();
	}

	private void initComponents() {
		JPanel content = new JPanel(new BorderLayout(10, 10));
		content.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(content);

		JPanel filters = new JPanel(new GridLayout(2, 4, 10, 10));
		filters.setBorder(new TitledBorder("Filters"));

		filters.add(mkLabel("Start Date:"));
		startDateChooser = new JDateChooser();
		filters.add(startDateChooser);
		filters.add(mkLabel("End Date:"));
		endDateChooser = new JDateChooser();
		filters.add(endDateChooser);
		filters.add(mkLabel("Brand:"));
		brandComboBox = new JComboBox<>();
		filters.add(brandComboBox);
		filters.add(mkLabel("Is Financed:"));
		financeFilterComboBox = new JComboBox<>(new String[] { "All", "Yes", "No" });
		filters.add(financeFilterComboBox);
		content.add(filters, BorderLayout.NORTH);

		JPanel summary = new JPanel(new GridLayout(0, 1, 5, 5));
		summary.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), "Summary",
				TitledBorder.LEFT, TitledBorder.TOP, new Font("Times New Roman", Font.BOLD, 16), Color.WHITE));
		summary.setBackground(Color.BLACK);

		Font f = new Font("Times New Roman", Font.BOLD, 16);
		Color light = Color.WHITE;

		totalSalesLabel = mkLabel("Total Sales: ₹0.00", f, light);
		totalTransactionsLabel = mkLabel("Total Transactions: 0", f, light);
		downPaymentTotalLabel = mkLabel("Total Down Payment: ₹0.00", f, light);
		totalPurchaseLabel = mkLabel("Total Purchase: ₹0.00", f, light);
		profitLossLabel = mkLabel("Profit/Loss: ₹0.00", f, light);
        netProfitLabel = mkLabel("Profit: ₹0.00", f, light);
        netLossLabel = mkLabel("Loss: ₹0.00", f, light);
		summary.add(totalSalesLabel);
		summary.add(totalTransactionsLabel);
		summary.add(downPaymentTotalLabel);
		summary.add(totalPurchaseLabel);
		//summary.add(profitLossLabel);
		summary.add(netProfitLabel);
		summary.add(netLossLabel);

		String[] cols = { "Invoice No", "Sale Date & Time", "IMEI", "Sold Amount", "Financed", "Down Payment",
				"Purchase Price", "Brand", "Model", "Ram", "Storage", "Customer", "Mobile", "Price Difference" };

		reportModel = new DefaultTableModel(cols, 0) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};

		reportTable = new JTable(reportModel) {
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
				Component comp = super.prepareRenderer(renderer, row, col);
				comp.setForeground(Color.BLACK);
				Object diffVal = getValueAt(row, getColumnCount() - 1);
				double diff = diffVal instanceof Double ? (Double) diffVal : 0;
				String isFinanced = (String) getValueAt(row, 4);
				
				if (isRowSelected(row)) {
					// Selected row styling
					comp.setForeground(Color.WHITE);
					comp.setFont(comp.getFont().deriveFont(Font.BOLD, 18f));
				}
				if (!isRowSelected(row)) {
					if (diff > 0)
						comp.setBackground(new Color(153, 255, 153));
					else if (diff < 0)
						comp.setBackground(new Color(255, 102, 102));
					else
						comp.setBackground(Color.WHITE);
					if (col == 3) {
						comp.setBackground(new Color(0, 102, 204));
						comp.setForeground(Color.WHITE);
					} else if (col == 6) {
						comp.setBackground(new Color(204, 204, 0));
						comp.setForeground(new Color(0, 0, 128));
					} 
					 else if (col==4 &&!isFinanced.equals("No")) {
							comp.setBackground(new Color(0, 128, 128));
							comp.setForeground(Color.white);
						} 

					else if (col == getColumnCount() - 1) {
						if (diff < 0)
							comp.setBackground(new Color(255, 102, 102));
						else if (diff > 0)
							comp.setBackground(new Color(153, 255, 153));
					}

				}
				if ((col == 3 || col==5|| col == 6 || col == 13) && comp instanceof JLabel) {
					((JLabel) comp).setHorizontalAlignment(SwingConstants.RIGHT);
				}
				return comp;
			}
		};
		reportTable.setRowHeight(25);
		reportTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 14));

		sorter = new TableRowSorter<>(reportModel);
		reportTable.setRowSorter(sorter);

		JPanel center = new JPanel(new BorderLayout(5, 5));
		center.add(summary, BorderLayout.NORTH);
		center.add(new JScrollPane(reportTable), BorderLayout.CENTER);
		content.add(center, BorderLayout.CENTER);

		JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		generateReportButton = new JButton("Generate Report");
		exportButton = new JButton("Export");
		btns.add(generateReportButton);
		btns.add(exportButton);

		searchField = new JTextField(25);
		searchField.setToolTipText("Search...");
		searchField.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				filterTable();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				filterTable();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				filterTable();
			}

		});

		btns.add(new JLabel("Search:"));
		btns.add(searchField);
		content.add(btns, BorderLayout.SOUTH);

		// Add MouseListener for double-click on table row
		reportTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2 && reportTable.getSelectedRow() != -1) {

					if (!CurrentUser.getUsername().equals("admin")) {
						JOptionPane.showMessageDialog(null, "permission denied", "invalid", JOptionPane.ERROR_MESSAGE);
						return;
					}
					SaleReportRow sr = new SaleReportRow();
					UpdateSales sales = new UpdateSales();
					int selectedRow = reportTable.convertRowIndexToModel(reportTable.getSelectedRow());
					String invoiceNo = (String) reportModel.getValueAt(selectedRow, 0);
					String saleDateTime = (String) reportModel.getValueAt(selectedRow, 1);
					String imei = (String) reportModel.getValueAt(selectedRow, 2);
					double totalAmount = (Double) reportModel.getValueAt(selectedRow, 3);
					Object value = reportModel.getValueAt(selectedRow, 4);

					// Convert the string "Yes" or "No" to a Boolean
					Boolean financed = false;
					if (value != null) {
						String valueStr = value.toString().trim();
						if ("Yes".equalsIgnoreCase(valueStr)) {
							financed = true;
						} else if ("No".equalsIgnoreCase(valueStr)) {
							financed = false;
						}
					}
					double downPayment = (Double) reportModel.getValueAt(selectedRow, 5);
					double purchasePrice = (Double) reportModel.getValueAt(selectedRow, 6);
					String brand = (String) reportModel.getValueAt(selectedRow, 7);
					String model = (String) reportModel.getValueAt(selectedRow, 8);
					String ram = (String) reportModel.getValueAt(selectedRow, 9);
					String storage = (String) reportModel.getValueAt(selectedRow, 10);
					String customer = (String) reportModel.getValueAt(selectedRow, 11);
					String mobile = (String) reportModel.getValueAt(selectedRow, 12);
					double priceDiff = (Double) reportModel.getValueAt(selectedRow, 13);

					sr.setInvoiceNo(invoiceNo);
					sr.setSaleDateTime(saleDateTime);
					sr.setImei(imei);
					sr.setTotalAmount(totalAmount);
					sr.setFinanced(financed);
					sr.setDownPayment(downPayment);
					sr.setPurchasePrice(purchasePrice);
					sr.setBrand(brand);
					sr.setModel(model);
					sr.setCustomer(customer);
					sr.setMobile(mobile);
					sr.setPriceDifference(priceDiff);
					new UpdateSalesController(sales, sr);
					sales.setVisible(true);

				}
			}
		});

	}

	private void filterTable() {
		String query = searchField.getText().trim();
		if (query.isEmpty()) {
			sorter.setRowFilter(null);
		} else {
			sorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
		}
	}

	private JLabel mkLabel(String txt) {
		return mkLabel(txt, new Font("Times New Roman", Font.PLAIN, 14), Color.BLACK);
	}

	private JLabel mkLabel(String txt, Font f, Color c) {
		JLabel lbl = new JLabel(txt);
		lbl.setFont(f);
		lbl.setForeground(c);
		return lbl;
	}

	public void setBrandOptions(List<String> brands) {
		brandComboBox.removeAllItems();
		brandComboBox.addItem("All Brands");
		for (String b : brands)
			brandComboBox.addItem(b);
	}

	public java.util.Date getStartDate() {
		return startDateChooser.getDate();
	}

	public java.util.Date getEndDate() {
		return endDateChooser.getDate();
	}

	public String getSelectedBrand() {
		return (String) brandComboBox.getSelectedItem();
	}

	public String getSelectedFinance() {
		return (String) financeFilterComboBox.getSelectedItem();
	}

	public void addGenerateListener(ActionListener l) {
		generateReportButton.addActionListener(l);
	}

	public void addExportListener(ActionListener l) {
		exportButton.addActionListener(l);
	}

	public void updateSummary(double sales, int tx, double down, double purchase, double profit,double netProfit,double netLoss) {
		totalSalesLabel.setText(String.format("Total Sales: ₹%.2f", sales));
		totalTransactionsLabel.setText("Total Transactions: " + tx);
		downPaymentTotalLabel.setText(String.format("Total Down Payment: ₹%.2f", down));
		totalPurchaseLabel.setText(String.format("Total Purchase: ₹%.2f", purchase));
		profitLossLabel.setText(String.format("Profit/Loss: ₹%.2f", profit));
		netProfitLabel.setText(String.format("Profit: ₹%.2f", netProfit));
		netLossLabel.setText(String.format("Loss: ₹%.2f", netLoss));
		netProfitLabel.setForeground(new Color(0, 204, 0));
		netLossLabel.setForeground(Color.RED);
		profitLossLabel.setForeground(profit >= 0 ? new Color(0, 204, 0) : Color.RED);
	}

	public void updateTable(List<SaleRecord> list) {
		reportModel.setRowCount(0);
		SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		for (SaleRecord r : list) {
			double diff = r.getTotalAmount() - r.getPurchasePrice();
			reportModel.addRow(new Object[] { r.getInvoiceNo(), fmt.format(r.getInvoiceDateTime()), r.getImei(),
					r.getTotalAmount(), r.isFinanced() ? "Yes" : "No", r.getDownPayment(), r.getPurchasePrice(),
					r.getBrand(), r.getModel(), r.getRam(), r.getStorage(), r.getCustomer(), r.getCustomerMobile(),
					diff });
		}

		reportTable.getColumnModel().getColumn(3).setCellRenderer(new DecimalCellRenderer());
		reportTable.getColumnModel().getColumn(6).setCellRenderer(new DecimalCellRenderer());
		reportTable.getColumnModel().getColumn(13).setCellRenderer(new DecimalCellRenderer());
	}

	public void exportToCSV() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save Report as CSV");
		if (fileChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION)
			return;

		File file = fileChooser.getSelectedFile();
		if (!file.getName().toLowerCase().endsWith(".csv")) {
			file = new File(file.getAbsolutePath() + ".csv");
		}

		try (PrintWriter writer = new PrintWriter(file)) {
			TableModel model = reportTable.getModel();
			for (int i = 0; i < model.getColumnCount(); i++) {
				writer.print(model.getColumnName(i));
				if (i < model.getColumnCount() - 1)
					writer.print(",");
			}
			writer.println();
			for (int row = 0; row < model.getRowCount(); row++) {
				for (int col = 0; col < model.getColumnCount(); col++) {
					Object val = model.getValueAt(row, col);
					writer.print(val != null ? val.toString().replace(",", " ") : "");
					if (col < model.getColumnCount() - 1)
						writer.print(",");
				}
				writer.println();
			}
			writer.println();
			writer.println("Summary");
			writer.println("Total Sales," + totalSalesLabel.getText().replace("Total Sales: ₹", ""));
			writer.println(
					"Total Transactions," + totalTransactionsLabel.getText().replace("Total Transactions: ", ""));
			writer.println(
					"Total Down Payment," + downPaymentTotalLabel.getText().replace("Total Down Payment: ₹", ""));
			writer.println("Total Purchase," + totalPurchaseLabel.getText().replace("Total Purchase: ₹", ""));
			writer.println("Profit/Loss," + profitLossLabel.getText().replace("Profit/Loss: ₹", ""));
			JOptionPane.showMessageDialog(this, "CSV exported successfully!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to export CSV:\n" + ex.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void exportToPDF() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save Report as PDF");
		if (fileChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION)
			return;

		File file = fileChooser.getSelectedFile();
		if (!file.getName().toLowerCase().endsWith(".pdf")) {
			file = new File(file.getAbsolutePath() + ".pdf");
		}

		Document document = new Document(PageSize.A4.rotate());

		try {
			PdfWriter.getInstance(document, new FileOutputStream(file));
			document.open();

			document.add(new Paragraph("Sales Report", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
			document.add(new Paragraph(" "));

			PdfPTable pdfTable = new PdfPTable(reportModel.getColumnCount());
			pdfTable.setWidthPercentage(100);

			for (int col = 0; col < reportModel.getColumnCount(); col++) {
				PdfPCell header = new PdfPCell(new Phrase(reportModel.getColumnName(col)));
				header.setBackgroundColor(BaseColor.LIGHT_GRAY);
				pdfTable.addCell(header);
			}

			for (int row = 0; row < reportModel.getRowCount(); row++) {
				for (int col = 0; col < reportModel.getColumnCount(); col++) {
					Object val = reportModel.getValueAt(row, col);
					pdfTable.addCell(val != null ? val.toString() : "");
				}
			}

			document.add(pdfTable);
			document.add(new Paragraph(" "));

			PdfPTable summaryTable = new PdfPTable(2);
			summaryTable.setSpacingBefore(10f);
			summaryTable.setWidths(new float[] { 2f, 3f });
			summaryTable.setWidthPercentage(50);

			summaryTable.addCell("Total Sales");
			summaryTable.addCell(totalSalesLabel.getText().replace("Total Sales: ₹", ""));
			summaryTable.addCell("Total Transactions");
			summaryTable.addCell(totalTransactionsLabel.getText().replace("Total Transactions: ", ""));
			summaryTable.addCell("Total Down Payment");
			summaryTable.addCell(downPaymentTotalLabel.getText().replace("Total Down Payment: ₹", ""));
			summaryTable.addCell("Total Purchase");
			summaryTable.addCell(totalPurchaseLabel.getText().replace("Total Purchase: ₹", ""));
			summaryTable.addCell("Profit/Loss");
			summaryTable.addCell(profitLossLabel.getText().replace("Profit/Loss: ₹", ""));

			document.add(summaryTable);
			document.close();

			JOptionPane.showMessageDialog(this, "PDF exported successfully!", "Export",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to export PDF:\n" + e.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}
}

class DecimalCellRenderer extends DefaultTableCellRenderer {
	private final DecimalFormat df = new DecimalFormat("#,##0.00"); // No comma

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {

		Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

		if (value instanceof Number) {
			setText(df.format(((Number) value).doubleValue()));
			setHorizontalAlignment(SwingConstants.RIGHT);
		}

		return c;
	}
}
