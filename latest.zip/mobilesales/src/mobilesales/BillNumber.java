package mobilesales;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BillNumber {
	 private static final String PREFIX = "DIG/";
	    private static final String FORMAT = "%04d"; // To get 0001, 0002, etc.

	    public static String generateInvoiceNumber() throws SQLException {
	        // Get the max invoice number from DB
	        String query = "SELECT invoice_no FROM sales ORDER BY sales_id DESC LIMIT 1";
	        Connection conn=DBConnection.getConnection();
			try (PreparedStatement stmt = conn.prepareStatement(query);
	             ResultSet rs = stmt.executeQuery()) {

	            int nextNumber = 1;

	            if (rs.next()) {
	                String lastInvoice = rs.getString("invoice_no");
	                String numericPart = lastInvoice.replace(PREFIX, ""); // remove "DIG/"
	                nextNumber = Integer.parseInt(numericPart) + 1;
	            }

	            return PREFIX + String.format(FORMAT, nextNumber);
	        }
	    }


	    
	}