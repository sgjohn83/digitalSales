package mobilesales;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.BrandController;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BrandAdd extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField brandValue;
	private JPanel purchasePanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BrandAdd frame = new BrandAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BrandAdd(MyListener ml) throws HeadlessException {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 434, 261);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Brand Name");
		lblNewLabel_1.setBounds(72, 89, 127, 22);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Add Brand");
		lblNewLabel.setBounds(154, 11, 83, 22);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panel.add(lblNewLabel);
		
		brandValue = new JTextField();
		brandValue.setBounds(185, 90, 154, 20);
		panel.add(brandValue);
		brandValue.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String text = brandValue.getText();
				 BrandController bc = new BrandController();
				 boolean res = bc.addBrand(text);
				 if(res)
				 {
					 JOptionPane.showMessageDialog(null, "Brand added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
					 ml.updateListener();
				 }
				 
			}
		});
		btnNewButton.setBounds(146, 144, 116, 36);
		panel.add(btnNewButton);
        ml.updateListener();
		
	}
	
	public BrandAdd() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 434, 261);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Brand Name");
		lblNewLabel_1.setBounds(72, 89, 127, 22);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Add Brand");
		lblNewLabel.setBounds(154, 11, 83, 22);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panel.add(lblNewLabel);
		
		brandValue = new JTextField();
		brandValue.setBounds(185, 90, 154, 20);
		panel.add(brandValue);
		brandValue.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String text = brandValue.getText();
				 BrandController bc = new BrandController();
				 boolean res = bc.addBrand(text);
				 if(res)
				 {
					 JOptionPane.showMessageDialog(null, "Brand added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				 }
				 
			}
		});
		btnNewButton.setBounds(146, 144, 116, 36);
		panel.add(btnNewButton);
	}

	

	
}
