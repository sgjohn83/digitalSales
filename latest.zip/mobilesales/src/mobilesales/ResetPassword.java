package mobilesales;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;

public class ResetPassword extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox usersCombo;
	private JButton btnResetPassword;


	/**
	 * Create the frame.
	 */
	public ResetPassword() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Reset Password");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(149, 28, 212, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(61, 79, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		 btnResetPassword = new JButton("Reset");
		btnResetPassword.setBounds(141, 139, 149, 30);
		contentPane.add(btnResetPassword);
		
		JLabel lblNewLabel_2 = new JLabel("User Name");
		lblNewLabel_2.setBounds(79, 79, 69, 14);
		contentPane.add(lblNewLabel_2);
		
	   usersCombo = new JComboBox();
		usersCombo.setBounds(149, 79, 138, 22);
		contentPane.add(usersCombo);
	}

	public JButton getBtnResetPassword() {
		return btnResetPassword;
	}

	public void setBtnResetPassword(JButton btnResetPassword) {
		this.btnResetPassword = btnResetPassword;
	}

	public JComboBox getUsersCombo() {
		return usersCombo;
	}

	public void setUsersCombo(JComboBox usersCombo) {
		this.usersCombo = usersCombo;
	}
}
