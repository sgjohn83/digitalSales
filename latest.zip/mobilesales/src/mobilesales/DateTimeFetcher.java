package mobilesales;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;

import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.swing.JOptionPane;

public class DateTimeFetcher {

    public  String getCurrentDateTime() {
        String formattedTime;
        try {
            // Step 1: Try to get time from NTP server
            String TIME_SERVER = "pool.ntp.org";
            NTPUDPClient client = new NTPUDPClient();
            client.setDefaultTimeout(3000);
            InetAddress hostAddr = InetAddress.getByName(TIME_SERVER);
            TimeInfo info = client.getTime(hostAddr);
            info.computeDetails(); // computes offset/delay
            long currentTimeMillis = info.getMessage().getTransmitTimeStamp().getTime();

            Date ntpDate = new Date(currentTimeMillis);
            formattedTime = format(ntpDate);
        } catch (Exception e) {
            // Step 2: Fallback to system time
            Date localDate = new Date();
            formattedTime = format(localDate);
            String lastDatetime = getLatestInvoiceDateTime();
            try {
                // Step 3: Parse both dates to compare
            	Date localDate1 = new Date();
                SimpleDateFormat systemFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                String localFormatted = systemFormat.format(localDate1);
                Date localParsed = systemFormat.parse(localFormatted);

                // Format lastDatetime: dd/MM/yy HH:mm:ss
                SimpleDateFormat lastFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                Date lastParsed = lastFormat.parse(lastDatetime);

                // Compare
                if (localParsed.before(lastParsed)) {
                    JOptionPane.showMessageDialog(null,
                            "System time is behind the clock",
                            "Date Error",
                            JOptionPane.ERROR_MESSAGE);
                    System.exit(0);
                } else {
                    System.out.println("System time is OK.");
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }

        return formattedTime;
    }

    private  String format(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        sdf.setTimeZone(TimeZone.getDefault()); // or TimeZone.getTimeZone("UTC")
        return sdf.format(date);
    }

  
    public String getLatestInvoiceDateTime() {
        String sql = "SELECT invoice_date FROM sales ORDER BY invoice_date DESC LIMIT 1";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String formattedDateTime = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {
                Date invoiceDate = rs.getTimestamp("invoice_date");

                // Format as dd/MM/yy HH:mm:ss
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                formattedDateTime = sdf.format(invoiceDate);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Proper JDBC cleanup in Java 7
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        return formattedDateTime;
    }
}
