package mobilesales;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OTPFormFixedEmail extends JDialog {
    private final String email;
    private boolean verified = false;

    private JButton sendOtpButton;
    private JTextField otpField;
    private JButton validateButton;
    private JLabel statusLabel;

    public OTPFormFixedEmail(Frame parent, String email) {
        super(parent, "OTP Verification", true);
        this.email = email;

        setSize(350, 200);
        setLayout(null);
        setLocationRelativeTo(parent);

        JLabel emailLabel = new JLabel("Email: " + email);
        emailLabel.setBounds(30, 20, 300, 25);
       // add(emailLabel);

        sendOtpButton = new JButton("Send OTP");
        sendOtpButton.setBounds(30, 50, 120, 30);
        add(sendOtpButton);

        JLabel otpLabel = new JLabel("Enter OTP:");
        otpLabel.setBounds(30, 90, 80, 25);
        add(otpLabel);

        otpField = new JTextField();
        otpField.setBounds(110, 90, 180, 25);
        add(otpField);

        validateButton = new JButton("Validate");
        validateButton.setBounds(110, 125, 120, 30);
        add(validateButton);

        statusLabel = new JLabel();
        statusLabel.setBounds(30, 160, 300, 25);
        add(statusLabel);

        sendOtpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String otp = OTPUtil.generateOTP(6);
                OTPStore.storeOTP(email, otp);
                EmailSender.sendEmail(email, "Your OTP", "Your OTP is: " + otp);
                statusLabel.setText("OTP sent to: " + email);
            }
        });

        validateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String inputOtp = otpField.getText();
                if (OTPStore.validateOTP(email, inputOtp)) {
                    statusLabel.setText("✅ OTP Verified!");
                    verified = true;
                    dispose();  // Close dialog and unblock caller
                } else {
                    statusLabel.setText("❌ Invalid OTP.");
                }
            }
        });
    }

    public boolean isVerified() {
        return verified;
    }
}
