package mobilesales;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;

import service.SalesService;

import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.Vector;

public class PrintCustomerBill extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField mobileText;
    private JTable customerbillTable;
    private JButton searchButton;

    public PrintCustomerBill() {
        setTitle("Customer Bill Print");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 1000, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Print Bill");
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 32));

        JLabel lblMobile = new JLabel("Customer Mobile No");
        lblMobile.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        mobileText = new JTextField();
        mobileText.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        mobileText.setColumns(10);

        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JScrollPane scrollPane = new JScrollPane();
        customerbillTable = new JTable();
        customerbillTable.setModel(new DefaultTableModel(
            new Object[][] {},
            new String[] {
                "Sales Invoice No", "Sales Date", "Model", "Imei", "Ram", "Storage", "Total Amount", "Print"
            }
        ));

        // Table Styling
        customerbillTable.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        customerbillTable.setRowHeight(30);

        JTableHeader header = customerbillTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 20));
        header.setBackground(new Color(60, 63, 65));
        header.setForeground(Color.WHITE);

        customerbillTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : new Color(220, 230, 241));
                setHorizontalAlignment(CENTER);
                return c;
            }
        });

        customerbillTable.getColumn("Print").setCellRenderer(new ButtonRenderer());
        customerbillTable.getColumn("Print").setCellEditor(new ButtonEditor(new JCheckBox()));

        scrollPane.setViewportView(customerbillTable);

        GroupLayout gl = new GroupLayout(contentPane);
        gl.setAutoCreateGaps(true);
        gl.setAutoCreateContainerGaps(true);
        contentPane.setLayout(gl);

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(lblTitle)
                .addGroup(gl.createSequentialGroup()
                    .addComponent(lblMobile)
                    .addComponent(mobileText, GroupLayout.PREFERRED_SIZE, 250, GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButton))
                .addComponent(scrollPane)
        );

        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addComponent(lblTitle)
                .addGap(20)
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMobile)
                    .addComponent(mobileText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButton))
                .addGap(20)
                .addComponent(scrollPane)
        );
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JTextField getMobileText() {
        return mobileText;
    }

    public JTable getCustomerbillTable() {
        return customerbillTable;
    }

    // Renderer for button column
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setFont(new Font("Segoe UI", Font.BOLD, 16));
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText("Print");
            return this;
        }
    }

    // Editor for button column
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String invoiceNo;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton("Print");
            button.setFont(new Font("Segoe UI", Font.BOLD, 16));
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SalesService ss = new SalesService();
                    int id=0;
                    try {
						id= ss.getSalesIdByInvoiceNo(invoiceNo);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                    BillPrinter print = new BillPrinter();
                    print.printBill(id);
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            invoiceNo = table.getValueAt(row, 0).toString();
            return button;
        }
    }

 
}
