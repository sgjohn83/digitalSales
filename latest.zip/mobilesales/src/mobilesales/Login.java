package mobilesales;


import javax.swing.*;
import java.awt.*;

public class Login extends JFrame {

    public JTextField txtUsername;
    public JPasswordField txtPassword;
    public JButton btnLogin;
    public JLabel lblMessage;

    public Login() {
        setTitle("Digital Cell Care");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.white);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel lblTitle = new JLabel("Login");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(60, 63, 65));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth = 1;

        // Username label
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Username:"), gbc);

        // Username field
        txtUsername = new JTextField(15);
        gbc.gridx = 1;
        panel.add(txtUsername, gbc);

        // Password label
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Password:"), gbc);

        // Password field
        txtPassword = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(txtPassword, gbc);

        // Login button
        btnLogin = new JButton("Login");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(btnLogin, gbc);
        
        getRootPane().setDefaultButton(btnLogin);

        // Message label with fixed size wrapper
        lblMessage = new JLabel(" ", JLabel.CENTER);
        lblMessage.setForeground(Color.RED);

        JPanel messagePanel = new JPanel();
        messagePanel.setPreferredSize(new Dimension(300, 25));
        messagePanel.setLayout(new BorderLayout());
        messagePanel.add(lblMessage, BorderLayout.CENTER);
        messagePanel.setBackground(Color.white);

        gbc.gridy = 4;
        panel.add(messagePanel, gbc);

        getContentPane().add(panel);
    }
   
}