package mobilesales;

import java.util.HashMap;
import java.util.Map;

public class OTPStore {
    private static final Map<String, String> otpMap = new HashMap<>();

    public static void storeOTP(String email, String otp) {
        otpMap.put(email, otp);
    }

    public static boolean validateOTP(String email, String inputOtp) {
        String storedOtp = otpMap.get(email);
        if (storedOtp == null) return false;

        boolean isMatch = storedOtp.equals(inputOtp);
        if (isMatch) {
            otpMap.remove(email); // Optional: remove after successful use
        }
        return isMatch;
    }
}
