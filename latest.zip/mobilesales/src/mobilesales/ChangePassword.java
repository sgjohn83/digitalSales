package mobilesales;

import java.awt.EventQueue;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChangePassword extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPasswordField txtCurrentPassword;
	private JPasswordField txtNewPassword;
	private JPasswordField txtConfirmPassword;
	private JButton btnSubmit;

	

	public ChangePassword() {
		setTitle("Change Password");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(450, 300);
		setLocationRelativeTo(null); // Center the frame

		JPanel contentPane = new JPanel();
		setContentPane(contentPane);

		JLabel lblTitle = new JLabel("Change Password");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));

		JLabel lblCurrentPassword = new JLabel("Current Password:");
		txtCurrentPassword = new JPasswordField(20);

		JLabel lblNewPassword = new JLabel("New Password:");
		txtNewPassword = new JPasswordField(20);

		JLabel lblConfirmPassword = new JLabel("Confirm Password:");
		txtConfirmPassword = new JPasswordField(20);

		btnSubmit = new JButton("Submit");
		

		// Responsive layout using GroupLayout
		GroupLayout layout = new GroupLayout(contentPane);
		contentPane.setLayout(layout);
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		layout.setHorizontalGroup(
			layout.createParallelGroup(GroupLayout.Alignment.CENTER)
				.addComponent(lblTitle)
				.addGroup(layout.createSequentialGroup()
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblCurrentPassword)
						.addComponent(lblNewPassword)
						.addComponent(lblConfirmPassword))
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(txtCurrentPassword)
						.addComponent(txtNewPassword)
						.addComponent(txtConfirmPassword)))
				.addComponent(btnSubmit)
		);

		layout.setVerticalGroup(
			layout.createSequentialGroup()
				.addComponent(lblTitle)
				.addGap(20)
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
					.addComponent(lblCurrentPassword)
					.addComponent(txtCurrentPassword))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
					.addComponent(lblNewPassword)
					.addComponent(txtNewPassword))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
					.addComponent(lblConfirmPassword)
					.addComponent(txtConfirmPassword))
				.addGap(20)
				.addComponent(btnSubmit)
		);
	}



	public JPasswordField getTxtCurrentPassword() {
		return txtCurrentPassword;
	}



	public void setTxtCurrentPassword(JPasswordField txtCurrentPassword) {
		this.txtCurrentPassword = txtCurrentPassword;
	}



	public JPasswordField getTxtNewPassword() {
		return txtNewPassword;
	}



	public void setTxtNewPassword(JPasswordField txtNewPassword) {
		this.txtNewPassword = txtNewPassword;
	}



	public JPasswordField getTxtConfirmPassword() {
		return txtConfirmPassword;
	}



	public void setTxtConfirmPassword(JPasswordField txtConfirmPassword) {
		this.txtConfirmPassword = txtConfirmPassword;
	}



	public JButton getBtnSubmit() {
		return btnSubmit;
	}



	public void setBtnSubmit(JButton btnSubmit) {
		this.btnSubmit = btnSubmit;
	}
}
