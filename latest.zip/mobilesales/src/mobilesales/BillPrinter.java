package mobilesales;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.util.JRLoader;

import java.io.InputStream;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

public class BillPrinter {

    public void printBill(int sales_id) {
        Connection conn = null;
        try {
            // Load the compiled .jasper file from the classpath (works in both Eclipse and JAR)
            InputStream jasperStream = getClass().getResourceAsStream("/salesbill_1.jasper");

         

            // Load the compiled report
            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);

            // Database connection
            conn = DBConnection.getConnection();

            // Parameters
            Map<String, Object> parameters = new HashMap<String, Object>();
            parameters.put("salesid", sales_id);

            // Fill and print
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, conn);
            JasperPrintManager.printReport(jasperPrint, true); // true = show print dialog

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (Exception ignored) {}
        }
    }
}
