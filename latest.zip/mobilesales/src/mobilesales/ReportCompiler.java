package mobilesales;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;

public class ReportCompiler {
    public static void compile() {
        try {
            String jrxmlPath = "src/report/salesbill.jrxml";
            String jasperPath = "src/report/salesbill_1.jasper";
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
            System.out.println("Compiled successfully.");
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
  
   
  /*public static void main(String[] args)
    {
    	ReportCompiler.compile();
    } */
    
}