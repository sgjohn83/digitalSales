package mobilesales;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.ColorUIResource;
import java.util.Enumeration;

public class UpdateProduct extends JFrame {

    private JTextField txtId;
    private JComboBox<String> comboBrand;
    private JTextField txtModel;
    private JTextField txtImei;
    private JTextField txtRam;
    private JTextField txtStorage;
    private JTextField txtPrice;
    private JButton btnUpdate;

    public UpdateProduct() {
        super("Update Product");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        applyGlobalStyles();
        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    private void applyGlobalStyles() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }

            Font baseFont = new Font("Segoe UI", Font.PLAIN, 14);
            Font buttonFont = new Font("Segoe UI", Font.BOLD, 16);
            Enumeration<Object> keys = UIManager.getDefaults().keys();
            while (keys.hasMoreElements()) {
                Object key = keys.nextElement();
                Object value = UIManager.get(key);
                if (value instanceof FontUIResource) {
                    UIManager.put(key, new FontUIResource(baseFont));
                } else if ("Button.font".equals(key)) {
                    UIManager.put(key, new FontUIResource(buttonFont));
                }
            }

            UIManager.put("Panel.background", new ColorUIResource(245, 245, 245));
            UIManager.put("Button.background", new ColorUIResource(0, 123, 255));
            UIManager.put("Button.foreground", new ColorUIResource(255, 255, 255));
            UIManager.put("TextField.background", new ColorUIResource(255, 255, 255));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        txtId = createTextField();              txtId.setEnabled(false);
        comboBrand = createComboBox();
        txtModel = createTextField();
        txtImei = createTextField();
        txtRam = createTextField();
        txtStorage = createTextField();
        txtPrice = createTextField();
        btnUpdate = createButton("Update Product");

        JLabel header = new JLabel("Update Product", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.setBorder(new EmptyBorder(20, 0, 10, 0));
        header.setForeground(new Color(51, 51, 51));

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 15));
        formPanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        formPanel.add(new JLabel("Product ID:"));      formPanel.add(txtId);
        formPanel.add(new JLabel("Brand:"));           formPanel.add(comboBrand);
        formPanel.add(new JLabel("Model:"));           formPanel.add(txtModel);
        formPanel.add(new JLabel("IMEI:"));            formPanel.add(txtImei);
        formPanel.add(new JLabel("RAM:"));             formPanel.add(txtRam);
        formPanel.add(new JLabel("Storage:"));         formPanel.add(txtStorage);
        formPanel.add(new JLabel("Price:"));           formPanel.add(txtPrice);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        buttonPanel.add(btnUpdate);

        JPanel content = new JPanel(new BorderLayout());
        content.setBorder(new EmptyBorder(0, 0, 0, 0));
        content.add(header, BorderLayout.NORTH);
        content.add(formPanel, BorderLayout.CENTER);
        content.add(buttonPanel, BorderLayout.SOUTH);
        setContentPane(content);
    }

    private JTextField createTextField() {
        JTextField tf = new JTextField();
        tf.setColumns(15);
        tf.setBorder(new LineBorder(new Color(204, 204, 204)));
        return tf;
    }

    private JComboBox<String> createComboBox() {
        JComboBox<String> cb = new JComboBox<>();
        cb.setBorder(new LineBorder(new Color(204, 204, 204)));
        return cb;
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        return btn;
    }

    // Getters for controller
    public JTextField getTxtId() { return txtId; }
    public JComboBox<String> getComboBrand() { return comboBrand; }
    public JTextField getTxtModel() { return txtModel; }
    public JTextField getTxtImei() { return txtImei; }
    public JTextField getTxtRam() { return txtRam; }
    public JTextField getTxtStorage() { return txtStorage; }
    public JTextField getTxtPrice() { return txtPrice; }
    public JButton getBtnUpdate() { return btnUpdate; }
}
