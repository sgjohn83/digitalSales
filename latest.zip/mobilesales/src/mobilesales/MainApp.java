package mobilesales;

import java.net.ServerSocket;
import java.time.LocalDateTime;

import controller.LoginController;
import model.LoginModel;
import model.User;
import service.UserService;

public class MainApp {
	  /**
	   * @wbp.parser.entryPoint
	   */
	private static ServerSocket lockSocket;
	  public static void main(String[] args) {
		  
	        
		  if (!acquireLock(9999)) {
	            System.out.println("Another instance is already running.");
	            System.exit(0);
	        }
		  BackupScheduler.startBackupTask();

	       UserService us = new UserService();
	       int count = us.getUserCount();
	       User manual = new User();
	        manual.setUserId(1);
	        manual.setUsername("admin");
	        manual.setPassword("digital@786");
	        manual.setRole("Admin");
	        manual.setCreatedAt(LocalDateTime.now());  // e.g. a week ago
	        manual.setLastLogin(LocalDateTime.now());
	       if(count==0)
	       {
	    	   us.addUser(manual);
	       }
		  
		  javax.swing.SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                LoginModel model = new LoginModel();
	                Login view =  new Login();
	                LoginController controller = new LoginController(model, view);
	                view.setVisible(true);
	            }
	        });
	    }
	  private static boolean acquireLock(int port) {
	        try {
	            lockSocket = new ServerSocket(port);
	            return true;
	        } catch (Exception e) {
	            return false;
	        }
	    }
}
 