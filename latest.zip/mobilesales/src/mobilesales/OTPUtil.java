package mobilesales;

import java.security.SecureRandom;

public class OTPUtil {
    public static String generateOTP(int length) {
        String chars = "0123456789";
        SecureRandom random = new SecureRandom();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < length; i++) {
            otp.append(chars.charAt(random.nextInt(chars.length())));
        }

        return otp.toString();
    }
}
