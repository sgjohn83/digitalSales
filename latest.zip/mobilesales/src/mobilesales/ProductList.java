package mobilesales;

import java.awt.EventQueue;
import model.Product2;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import controller.UpdateProductController;

import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProductList extends JFrame {

    private JPanel contentPane;
    private JTextField searchText;
    private JTable producrTable;
    private JButton btnEditProduct;

    public ProductList() {
        setTitle("Update Product");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 700, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Product List");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(lblTitle.getFont().deriveFont(18f));

        JLabel lblSearch = new JLabel("Search:");

        searchText = new JTextField();
        searchText.setColumns(20);

        btnEditProduct = new JButton("Edit Product");
        btnEditProduct.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		UpdateProduct up = new UpdateProduct();
        		Product2 product = new Product2();
        		int selectedRow = producrTable.getSelectedRow();

        		if (selectedRow == -1) {
        		    JOptionPane.showMessageDialog(null, "Please select a row to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
        		    return;
        		}

        		// Example: Extracting data from selected row
        		product.setProductId(Integer.parseInt(producrTable.getValueAt(selectedRow, 0).toString()));  // ID
        		product.setBrandName(producrTable.getValueAt(selectedRow, 1).toString());                   // Brand
        		product.setModel(producrTable.getValueAt(selectedRow, 2).toString());                       // Model
        		product.setImei(producrTable.getValueAt(selectedRow, 3).toString());                        // IMEI
        		product.setRam(producrTable.getValueAt(selectedRow, 4).toString());                         // RAM
        		product.setStorage(producrTable.getValueAt(selectedRow, 5).toString());                     // Storage
        		product.setPrice(Double.parseDouble(producrTable.getValueAt(selectedRow, 6).toString())); 
        		
        		new UpdateProductController(up,product);
        		up.setVisible(true);
        	}
        });

        producrTable = new JTable(new DefaultTableModel(
            new Object[][] {},
            new String[] { "ID", "Brand", "Model", "IMEI", "RAM", "Storage", "Price" }
        ));
        JScrollPane scrollPane = new JScrollPane(producrTable);

        GroupLayout gl = new GroupLayout(contentPane);
        contentPane.setLayout(gl);
        gl.setAutoCreateGaps(true);
        gl.setAutoCreateContainerGaps(true);

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(lblTitle, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(gl.createSequentialGroup()
                    .addComponent(lblSearch)
                    .addComponent(searchText, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE))
                .addComponent(scrollPane)
                .addGroup(GroupLayout.Alignment.CENTER, gl.createSequentialGroup()
                    .addComponent(btnEditProduct, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
        );

        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addComponent(lblTitle)
                .addGap(20)
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSearch)
                    .addComponent(searchText))
                .addGap(20)
                .addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                .addGap(20)
                .addComponent(btnEditProduct)
        );

        setupSearch();
    }

    private void setupSearch() {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>((DefaultTableModel) producrTable.getModel());
        producrTable.setRowSorter(sorter);

        searchText.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { search(); }
            public void removeUpdate(DocumentEvent e) { search(); }
            public void changedUpdate(DocumentEvent e) { search(); }

            private void search() {
                String text = searchText.getText();
                if (text.trim().length() == 0) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });
    }

    // Getters and Setters
    public JTextField getSearchText() {
        return searchText;
    }

    public void setSearchText(JTextField searchText) {
        this.searchText = searchText;
    }

    public JTable getProducrTable() {
        return producrTable;
    }

    public void setProducrTable(JTable producrTable) {
        this.producrTable = producrTable;
    }

    public JButton getBtnEditProduct() {
        return btnEditProduct;
    }

    public void setBtnEditProduct(JButton btnEditProduct) {
        this.btnEditProduct = btnEditProduct;
    }
}
