package mobilesales;

import java.awt.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.JTableHeader;

public class StockReportView extends JFrame {

    private static final long serialVersionUID = 1L;
    public JTable getStockReportTable() {
		return stockReportTable;
	}

	public void setStockReportTable(JTable stockReportTable) {
		this.stockReportTable = stockReportTable;
	}

	public JTextField getReportsModelNameTxt() {
		return reportsModelNameTxt;
	}

	public void setReportsModelNameTxt(JTextField reportsModelNameTxt) {
		this.reportsModelNameTxt = reportsModelNameTxt;
	}

	public JTextField getTblSearch() {
		return tblSearch;
	}

	public void setTblSearch(JTextField tblSearch) {
		this.tblSearch = tblSearch;
	}

	public JLabel getReportQuantity() {
		return reportQuantity;
	}

	public void setReportQuantity(JLabel reportQuantity) {
		this.reportQuantity = reportQuantity;
	}

	public JLabel getReportAmount() {
		return reportAmount;
	}

	public void setReportAmount(JLabel reportAmount) {
		this.reportAmount = reportAmount;
	}

	public JComboBox<String> getReportsBrandComboBox() {
		return reportsBrandComboBox;
	}

	public void setReportsBrandComboBox(List<String> list) {
		this.reportsBrandComboBox = (JComboBox<String>) list;
	}

	public JComboBox<String> getComboBox() {
		return comboBox;
	}

	public void setComboBox(JComboBox<String> comboBox) {
		this.comboBox = comboBox;
	}

	public JComboBox<String> getReportsStatuscomboBox() {
		return reportsStatuscomboBox;
	}

	public void setReportsStatuscomboBox(JComboBox<String> reportsStatuscomboBox) {
		this.reportsStatuscomboBox = reportsStatuscomboBox;
	}

	public JButton getReportsViewBtn() {
		return reportsViewBtn;
	}

	public void setReportsViewBtn(JButton reportsViewBtn) {
		this.reportsViewBtn = reportsViewBtn;
	}

	private JPanel contentPane;
    private JTable stockReportTable;
    private JTextField reportsModelNameTxt;
    private JTextField tblSearch;
    private JLabel reportQuantity;
    private JLabel reportAmount;
    private JComboBox<String> reportsBrandComboBox;
    private JComboBox<String> comboBox;
    private JComboBox<String> reportsStatuscomboBox;
    private JButton reportsViewBtn;



    public StockReportView() {
        setTitle("Stock Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 750, 600);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(245, 245, 245));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        JPanel filterPanel = new JPanel();
        filterPanel.setBackground(new Color(230, 230, 250));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Filters"));

        JLabel brandLabel = new JLabel("Select Brand:");
        reportsBrandComboBox = new JComboBox<>();

        JLabel billTypeLabel = new JLabel("Bill Type:");
        comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel(new String[] {"ALL", "GST", "NON_GST"}));

        JLabel statusLabel = new JLabel("Status:");
        reportsStatuscomboBox = new JComboBox<>();
        reportsStatuscomboBox.setModel(new DefaultComboBoxModel(new String[] {"ALL", "In Stock", "Sold"}));

        JLabel modelLabel = new JLabel("Model/Product Code:");
        reportsModelNameTxt = new JTextField(15);

        reportsViewBtn = new JButton("View");

        // Forcefully setting the button colors and UI
        reportsViewBtn.setBackground(new Color(0, 102, 204)); // Dark Blue
        reportsViewBtn.setForeground(Color.WHITE); // White text
        reportsViewBtn.setFocusPainted(false);
        reportsViewBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));

        // Remove default UI and apply custom UI to ensure color settings
        reportsViewBtn.setUI(new BasicButtonUI() {
            @Override
            public void installUI(JComponent c) {
                super.installUI(c);
                c.setBackground(new Color(0, 102, 204)); // Dark Blue
                c.setForeground(Color.WHITE); // White text
            }
        });

        GroupLayout gl_filterPanel = new GroupLayout(filterPanel);
        filterPanel.setLayout(gl_filterPanel);
        gl_filterPanel.setAutoCreateGaps(true);
        gl_filterPanel.setAutoCreateContainerGaps(true);

        gl_filterPanel.setHorizontalGroup(
            gl_filterPanel.createSequentialGroup()
                .addGroup(gl_filterPanel.createParallelGroup(GroupLayout.Alignment.TRAILING)
                    .addComponent(brandLabel)
                    .addComponent(billTypeLabel))
                .addGroup(gl_filterPanel.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(reportsBrandComboBox)
                    .addComponent(comboBox))
                .addGroup(gl_filterPanel.createParallelGroup(GroupLayout.Alignment.TRAILING)
                    .addComponent(statusLabel)
                    .addComponent(modelLabel))
                .addGroup(gl_filterPanel.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(reportsStatuscomboBox)
                    .addComponent(reportsModelNameTxt))
                .addComponent(reportsViewBtn)
        );

        gl_filterPanel.setVerticalGroup(
            gl_filterPanel.createSequentialGroup()
                .addGroup(gl_filterPanel.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(brandLabel)
                    .addComponent(reportsBrandComboBox)
                    .addComponent(statusLabel)
                    .addComponent(reportsStatuscomboBox)
                    .addComponent(reportsViewBtn))
                .addGroup(gl_filterPanel.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(billTypeLabel)
                    .addComponent(comboBox)
                    .addComponent(modelLabel)
                    .addComponent(reportsModelNameTxt))
        );

        JPanel tablePanel = new JPanel();
        tablePanel.setBorder(BorderFactory.createTitledBorder("Stock Data"));
        tablePanel.setLayout(new BorderLayout(5, 5));
        tablePanel.setBackground(new Color(245, 245, 245));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(new Color(245, 245, 245));
        JLabel searchLabel = new JLabel("Search:");
        tblSearch = new JTextField(20);
        searchPanel.add(searchLabel);
        searchPanel.add(tblSearch);

        stockReportTable = new JTable();
        stockReportTable.setRowHeight(24);
        stockReportTable.setSelectionBackground(new Color(173, 216, 230));
        stockReportTable.setGridColor(new Color(220, 220, 220));
        stockReportTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JTableHeader header = stockReportTable.getTableHeader();
        header.setBackground(new Color(100, 149, 237));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JScrollPane tableScrollPane = new JScrollPane(stockReportTable);

        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(tableScrollPane, BorderLayout.CENTER);

        JPanel summaryPanel = new JPanel();
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Summary"));
        summaryPanel.setLayout(new GridLayout(2, 2, 10, 10));
        summaryPanel.setBackground(new Color(245, 245, 245));

        JLabel totalQtyLabel = new JLabel("Total Quantity:");
        reportQuantity = new JLabel("0");
        reportQuantity.setFont(new Font("Segoe UI", Font.BOLD, 14));
        reportQuantity.setForeground(new Color(34, 139, 34));

        JLabel totalAmountLabel = new JLabel("Total Amount:");
        reportAmount = new JLabel("0.00");
        reportAmount.setFont(new Font("Segoe UI", Font.BOLD, 14));
        reportAmount.setForeground(new Color(178, 34, 34));

        summaryPanel.add(totalQtyLabel);
        summaryPanel.add(reportQuantity);
        summaryPanel.add(totalAmountLabel);
        summaryPanel.add(reportAmount);

        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(filterPanel)
                .addComponent(tablePanel)
                .addComponent(summaryPanel)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(filterPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(tablePanel)
                .addComponent(summaryPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        );

        setLocationRelativeTo(null);
    }
}
