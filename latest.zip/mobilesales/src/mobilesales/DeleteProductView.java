package mobilesales;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;

public class DeleteProductView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField imeiTextField;
    private JButton deleteButton;

    public DeleteProductView() {
        setTitle("Delete Product");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 250);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titleLabel = new JLabel("Delete Product");
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBounds(100, 10, 250, 30);
        contentPane.add(titleLabel);

        JLabel imeiLabel = new JLabel("IMEI No:");
        imeiLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        imeiLabel.setBounds(70, 70, 80, 25);
        contentPane.add(imeiLabel);

        imeiTextField = new JTextField();
        imeiTextField.setBounds(150, 70, 200, 25);
        contentPane.add(imeiTextField);
        imeiTextField.setColumns(15);

        deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        deleteButton.setBounds(160, 120, 100, 30);
        contentPane.add(deleteButton);
    }

    // Getter for IMEI input
    public String getImeiInput() {
        return imeiTextField.getText().trim();
    }

    // Attach controller's listener to button
    public void addDeleteListener(ActionListener listener) {
        deleteButton.addActionListener(listener);
    }

    // Show a message dialog
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    // Clear the input field
    public void clearInput() {
        imeiTextField.setText("");
    }
	
}
