package mobilesales;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;
import com.toedter.calendar.JDateChooser;

public class PurchaseReportView extends JFrame {

    private JTable invoiceTable;
    private JTable detailTable;
    private JTextField invoiceText;
    private JComboBox supplierCombo, brandCombo;
    private JLabel statusLabel;
    private JButton searchBtn;
    private JDateChooser startDate;
    private JDateChooser endDate;
    private JComboBox typeCombo;

    public JLabel totalInvoiceItems;
    public JLabel totalInvoiceAmount;
    public JLabel totalDetailItems;
    public JLabel totalInventoryStock; // ✅ new label

    public PurchaseReportView() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            Font uiFont = new Font("Segoe UI", Font.PLAIN, 14);
            UIManager.put("Label.font", uiFont);
            UIManager.put("Button.font", new Font("Segoe UI", Font.BOLD, 13));
            UIManager.put("TextField.font", uiFont);
            UIManager.put("ComboBox.font", uiFont);
            UIManager.put("Table.font", uiFont);
            UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 13));
            UIManager.put("TitledBorder.font", new Font("Segoe UI", Font.BOLD, 14));
            UIManager.put("Table.rowHeight", 24);
            UIManager.put("control", Color.WHITE);
            UIManager.put("nimbusBlueGrey", new Color(220, 220, 220));
        } catch (Exception ex) {}

        setTitle("Purchase Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1100, 800);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5, 5));

        add(createToolBar(), BorderLayout.NORTH);
        add(createFilterPanel(), BorderLayout.PAGE_START);

        JSplitPane split = new JSplitPane(
            JSplitPane.VERTICAL_SPLIT,
            createInvoiceTablePanel(),
            createDetailAndSummaryPanel()
        );
        split.setResizeWeight(0.5);
        add(split, BorderLayout.CENTER);

        add(createStatusBar(), BorderLayout.SOUTH);
    }

    public JTable getInvoiceTable() { return invoiceTable; }
    public JTable getDetailTable() { return detailTable; }
    public JTextField getInvoiceText() { return invoiceText; }
    public JComboBox getSupplierCombo() { return supplierCombo; }
    public JComboBox getBrandCombo() { return brandCombo; }
    public JLabel getStatusLabel() { return statusLabel; }
    public JComboBox getTypeCombo() { return typeCombo; }
    public JDateChooser getStartDate() { return startDate; }
    public JDateChooser getEndDate() { return endDate; }
    public JButton getSearchBtn() { return searchBtn; }

    private JToolBar createToolBar() {
        JToolBar tb = new JToolBar();
        tb.setFloatable(false);

        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> statusLabel.setText("Data refreshed"));
        JButton print = new JButton("Print");
        print.addActionListener(e -> statusLabel.setText("Print job sent"));
        JButton export = new JButton("Export");
        export.addActionListener(e -> statusLabel.setText("Export completed"));

        tb.add(refresh);
        tb.add(print);
        tb.add(export);
        return tb;
    }

    private JPanel createFilterPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(new TitledBorder("Filter Options"));

        JLabel startLbl = new JLabel("Start Date:"); startDate = new JDateChooser();
        JLabel endLbl = new JLabel("End Date:"); endDate = new JDateChooser();
        JLabel supLbl = new JLabel("Supplier:"); supplierCombo = new JComboBox();
        JLabel brandLbl = new JLabel("Brand:"); brandCombo = new JComboBox();
        JLabel typeLbl = new JLabel("Type:"); typeCombo = new JComboBox(new String[]{"ALL","GST","NON_GST"});
        JLabel invLbl = new JLabel("Invoice No:"); invoiceText = new JTextField();
        searchBtn = new JButton("Search");
        searchBtn.addActionListener(e -> statusLabel.setText("Search clicked"));

        GroupLayout g = new GroupLayout(panel);
        panel.setLayout(g);
        g.setAutoCreateGaps(true); g.setAutoCreateContainerGaps(true);
        g.setHorizontalGroup(
            g.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(g.createSequentialGroup()
                 .addComponent(startLbl).addComponent(startDate,120,GroupLayout.PREFERRED_SIZE,Short.MAX_VALUE)
                 .addComponent(endLbl).addComponent(endDate,120,GroupLayout.PREFERRED_SIZE,Short.MAX_VALUE))
             .addGroup(g.createSequentialGroup()
                 .addComponent(supLbl).addComponent(supplierCombo,120,GroupLayout.PREFERRED_SIZE,Short.MAX_VALUE)
                 .addComponent(brandLbl).addComponent(brandCombo,120,GroupLayout.PREFERRED_SIZE,Short.MAX_VALUE)
                 .addComponent(typeLbl).addComponent(typeCombo,100,GroupLayout.PREFERRED_SIZE,Short.MAX_VALUE)
                 .addComponent(invLbl).addComponent(invoiceText,100,GroupLayout.PREFERRED_SIZE,Short.MAX_VALUE)
                 .addComponent(searchBtn))
        );
        g.setVerticalGroup(
            g.createSequentialGroup()
             .addGroup(g.createParallelGroup(GroupLayout.Alignment.BASELINE)
                 .addComponent(startLbl).addComponent(startDate)
                 .addComponent(endLbl).addComponent(endDate))
             .addGroup(g.createParallelGroup(GroupLayout.Alignment.BASELINE)
                 .addComponent(supLbl).addComponent(supplierCombo)
                 .addComponent(brandLbl).addComponent(brandCombo)
                 .addComponent(typeLbl).addComponent(typeCombo)
                 .addComponent(invLbl).addComponent(invoiceText)
                 .addComponent(searchBtn))
        );
        return panel;
    }

    private JScrollPane createInvoiceTablePanel() {
        invoiceTable = new JTable(new DefaultTableModel(new Object[][]{},
            new String[]{"Invoice No","Date","By User","Supplier","Total Amount"}));
        styleStripedTable(invoiceTable);
        JScrollPane sp = new JScrollPane(invoiceTable);
        sp.setBorder(new TitledBorder("Invoice List"));
        return sp;
    }

    private JPanel createDetailAndSummaryPanel() {
        JPanel pnl = new JPanel(new BorderLayout(8,8));

        detailTable = new JTable(new DefaultTableModel(new Object[][]{},
            new String[]{"Brand","Model","IMEI","RAM","Storage","Total Amount"}));
        styleStripedTable(detailTable);
        JScrollPane sp = new JScrollPane(detailTable);
        sp.setBorder(new TitledBorder("Purchase Item Details"));
        pnl.add(sp, BorderLayout.CENTER);

        JPanel summaryContainer = new JPanel(new BorderLayout(10,10));
        Font titleFont = new Font("Segoe UI", Font.BOLD, 16);
        Font valueFont = new Font("Segoe UI", Font.BOLD, 14);
        Color invoiceBg = new Color(200,230,201);
        Color detailBg = new Color(255,224,178);

        // ✅ Invoice Summary (3x2)
        JPanel invoiceSummary = new JPanel(new GridLayout(3,2,8,8));
        invoiceSummary.setBorder(new TitledBorder("Invoice Summary"));
        invoiceSummary.setBackground(invoiceBg);
        JLabel invCountLbl = new JLabel("Total Invoices:"); invCountLbl.setFont(titleFont);
        totalInvoiceItems = new JLabel("0"); totalInvoiceItems.setFont(valueFont);
        JLabel invAmtLbl = new JLabel("Total Amount:"); invAmtLbl.setFont(titleFont);
        totalInvoiceAmount = new JLabel("0.00"); totalInvoiceAmount.setFont(valueFont);
        JLabel stockLbl = new JLabel("Total Inventory Stock:"); stockLbl.setFont(titleFont);
        totalInventoryStock = new JLabel("0"); totalInventoryStock.setFont(valueFont);

        invoiceSummary.add(invCountLbl); invoiceSummary.add(totalInvoiceItems);
        invoiceSummary.add(invAmtLbl); invoiceSummary.add(totalInvoiceAmount);
        invoiceSummary.add(stockLbl); invoiceSummary.add(totalInventoryStock);

        // Detail Summary
        JPanel detailSummary = new JPanel(new GridLayout(1,2,8,8));
        detailSummary.setBorder(new TitledBorder("Detail Summary"));
        detailSummary.setBackground(detailBg);
        JLabel detCountLbl = new JLabel("Total Items:"); detCountLbl.setFont(titleFont);
        totalDetailItems = new JLabel("0"); totalDetailItems.setFont(valueFont);
        detailSummary.add(detCountLbl); detailSummary.add(totalDetailItems);

        summaryContainer.add(invoiceSummary, BorderLayout.WEST);
        summaryContainer.add(detailSummary, BorderLayout.EAST);
        pnl.add(summaryContainer, BorderLayout.SOUTH);
        return pnl;
    }

    private void styleStripedTable(JTable table) {
        table.setRowHeight(24);
        JTableHeader hdr = table.getTableHeader(); hdr.setReorderingAllowed(false);
        DefaultTableCellRenderer r = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tbl, Object val,
                boolean isSel, boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(tbl,val,isSel,hasFocus,row,col);
                if (!isSel) c.setBackground((row%2==0)?Color.WHITE:new Color(245,245,245));
                return c;
            }
        };
        table.setDefaultRenderer(Object.class, r);
    }

    private JPanel createStatusBar() {
        JPanel status = new JPanel(new BorderLayout());
        statusLabel = new JLabel("Ready");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(2,5,2,5));
        status.add(statusLabel, BorderLayout.WEST);
        return status;
    }
}
