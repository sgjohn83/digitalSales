package mobilesales;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class UpdateSales extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldInvoiceNo;
    private JTextField textFieldDownPayment;
    private JTextField textFieldSoldAmount;
    private JCheckBox chckbxIsFinanced;
    private JButton btnUpdate;


    /**
     * Create the frame.
     */
    public UpdateSales() {
        setTitle("Update Sales");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 660, 524);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        // Use GroupLayout for better layout management
        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Components
        JLabel lblTitle = new JLabel("Update Sales", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(new Color(0, 123, 255)); // Adding a nice color

        JLabel lblSalesInvoiceNo = new JLabel("Sales Invoice No");
        lblSalesInvoiceNo.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        textFieldInvoiceNo = new JTextField();
        textFieldInvoiceNo.setEnabled(false);
        textFieldInvoiceNo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textFieldInvoiceNo.setBorder(new LineBorder(new Color(204, 204, 204), 1));

        JLabel lblDownPayment = new JLabel("Down Payment");
        lblDownPayment.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        textFieldDownPayment = new JTextField();
        textFieldDownPayment.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textFieldDownPayment.setBorder(new LineBorder(new Color(204, 204, 204), 1));

        JLabel lblSoldAmount = new JLabel("Sold Amount");
        lblSoldAmount.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        textFieldSoldAmount = new JTextField();
        textFieldSoldAmount.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textFieldSoldAmount.setBorder(new LineBorder(new Color(204, 204, 204), 1));

        chckbxIsFinanced = new JCheckBox("Is Financed");
        chckbxIsFinanced.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chckbxIsFinanced.setBackground(new Color(245, 245, 245));

        btnUpdate = new JButton("Update");
        btnUpdate.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnUpdate.setBackground(new Color(0, 123, 255));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFocusPainted(false);
        btnUpdate.setBorder(new LineBorder(new Color(0, 123, 255)));

        // Layout definition
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(lblTitle, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(lblSalesInvoiceNo)
                        .addComponent(lblDownPayment)
                        .addComponent(lblSoldAmount))
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(textFieldInvoiceNo, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textFieldDownPayment, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textFieldSoldAmount, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(chckbxIsFinanced)
                    .addGap(20)
                    .addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                )
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(lblTitle)
                .addGap(20)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSalesInvoiceNo)
                    .addComponent(textFieldInvoiceNo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDownPayment)
                    .addComponent(textFieldDownPayment, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSoldAmount)
                    .addComponent(textFieldSoldAmount, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(chckbxIsFinanced)
                    .addComponent(btnUpdate))
        );
    }

    // Getters and Setters

    public JTextField getTextFieldInvoiceNo() {
        return textFieldInvoiceNo;
    }

    public void setTextFieldInvoiceNo(JTextField textFieldInvoiceNo) {
        this.textFieldInvoiceNo = textFieldInvoiceNo;
    }

    public JTextField getTextFieldDownPayment() {
        return textFieldDownPayment;
    }

    public void setTextFieldDownPayment(JTextField textFieldDownPayment) {
        this.textFieldDownPayment = textFieldDownPayment;
    }

    public JTextField getTextFieldSoldAmount() {
        return textFieldSoldAmount;
    }

    public void setTextFieldSoldAmount(JTextField textFieldSoldAmount) {
        this.textFieldSoldAmount = textFieldSoldAmount;
    }

    public JCheckBox getChckbxIsFinanced() {
        return chckbxIsFinanced;
    }

    public void setChckbxIsFinanced(JCheckBox chckbxIsFinanced) {
        this.chckbxIsFinanced = chckbxIsFinanced;
    }

    public JButton getBtnUpdate() {
        return btnUpdate;
    }

    public void setBtnUpdate(JButton btnUpdate) {
        this.btnUpdate = btnUpdate;
    }
}
