package mobilesales;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.swing.*;

public class DBBackup extends JFrame {

	private JPanel contentPane;
	private JLabel statusLbl;

	public DBBackup() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JLabel lblNewLabel = new JLabel("BACKUP/RESTORE DATA");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(120, 10, 250, 30);
		contentPane.add(lblNewLabel);

		JButton backupBtn = new JButton("BACKUP");
		backupBtn.setBounds(170, 60, 120, 50);
		backupBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				callBackup();
			}
		});
		contentPane.add(backupBtn);

		JButton restoreBtn = new JButton("RESTORE");
		restoreBtn.setBounds(170, 120, 120, 50);
		restoreBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				callRestore();
			}
		});
		contentPane.add(restoreBtn);

		statusLbl = new JLabel("");
		statusLbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		statusLbl.setBounds(40, 200, 360, 30);
		contentPane.add(statusLbl);
	}

	public void callBackup() {
		new Thread(new Runnable() {
			public void run() {
				try {
					String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
					JFileChooser chooser = new JFileChooser();
					chooser.setDialogTitle("Save Backup ZIP File");
					chooser.setSelectedFile(new File("db_backup_" + timestamp + ".zip"));
					if (chooser.showSaveDialog(DBBackup.this) == JFileChooser.APPROVE_OPTION) {
						String zipPath = chooser.getSelectedFile().getAbsolutePath();
						statusLbl.setText("⏳ Creating backup...");
						String sqlPath = createBackupSQL(timestamp);
						zipFile(sqlPath, zipPath);
						new File(sqlPath).delete(); // cleanup
						statusLbl.setText("✅ Backup saved: " + zipPath);
					}
				} catch (Exception e) {
					e.printStackTrace();
					statusLbl.setText("❌ Backup failed: " + e.getMessage());
				}
			}
		}).start();
	}

	public String createBackupSQL(String timestamp) throws IOException, InterruptedException {
		String sqlPath = "db_backup_" + timestamp + ".sql";
		String command = "mysqldump -uroot -p1234 mobileshop -r " + sqlPath;
		Process process = Runtime.getRuntime().exec(command);
		if (process.waitFor() == 0) {
			return sqlPath;
		} else {
			throw new IOException("mysqldump failed");
		}
	}

	public void zipFile(String sqlPath, String zipPath) throws IOException {
		FileInputStream fis = new FileInputStream(sqlPath);
		FileOutputStream fos = new FileOutputStream(zipPath);
		ZipOutputStream zos = new ZipOutputStream(fos);

		ZipEntry entry = new ZipEntry(new File(sqlPath).getName());
		zos.putNextEntry(entry);

		byte[] buffer = new byte[1024];
		int read;
		while ((read = fis.read(buffer)) > 0) {
			zos.write(buffer, 0, read);
		}

		zos.closeEntry();
		zos.close();
		fis.close();
	}

	public void callRestore() {
		new Thread(new Runnable() {
			public void run() {
				try {
					JFileChooser chooser = new JFileChooser();
					chooser.setDialogTitle("Select ZIP File to Restore");
					if (chooser.showOpenDialog(DBBackup.this) == JFileChooser.APPROVE_OPTION) {
						File zipFile = chooser.getSelectedFile();
						statusLbl.setText("⏳ Restoring...");
						String extractedSQL = extractSQLFromZip(zipFile);
						restoreSQL(extractedSQL);
						new File(extractedSQL).delete(); // cleanup
						statusLbl.setText("✅ Restore completed.");
					}
				} catch (Exception e) {
					e.printStackTrace();
					statusLbl.setText("❌ Restore failed: " + e.getMessage());
				}
			}
		}).start();
	}

	public String extractSQLFromZip(File zipFile) throws IOException {
		String outputSql = "restored_" + System.currentTimeMillis() + ".sql";
		ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
		ZipEntry entry = zis.getNextEntry();
		if (entry != null && entry.getName().endsWith(".sql")) {
			FileOutputStream fos = new FileOutputStream(outputSql);
			byte[] buffer = new byte[1024];
			int read;
			while ((read = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, read);
			}
			fos.close();
			zis.closeEntry();
			zis.close();
			return outputSql;
		} else {
			zis.close();
			throw new IOException("No .sql file found in ZIP");
		}
	}

	public void restoreSQL(String sqlFilePath) throws IOException, InterruptedException {
		String command = "mysql -uroot -p1234 mobileshop < " + sqlFilePath;
		String[] fullCommand = { "cmd.exe", "/c", command };
		Process process = Runtime.getRuntime().exec(fullCommand);
		if (process.waitFor() != 0) {
			throw new IOException("mysql restore failed");
		}
	}

	public static void autoBackup() {
		new Thread(new Runnable() {
			public void run() {
				try {
					// Set backup directory on D: drive
					String backupDirPath = "D:\\Backups";
					File backupDir = new File(backupDirPath);
					if (!backupDir.exists()) {
						backupDir.mkdirs(); // Create if not exists
					}

					// Generate filenames
					String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
					String sqlPath = backupDirPath + "\\db_backup_" + timestamp + ".sql";
					String zipPath = backupDirPath + "\\db_backup_" + timestamp + ".zip";

					// Run mysqldump command
					String command = "mysqldump -uroot -p1234 mobileshop -r \"" + sqlPath + "\"";
					Process process = Runtime.getRuntime().exec(command);
					if (process.waitFor() != 0) {
						throw new IOException("mysqldump failed");
					}

					// Zip the SQL file
					FileInputStream fis = new FileInputStream(sqlPath);
					FileOutputStream fos = new FileOutputStream(zipPath);
					ZipOutputStream zos = new ZipOutputStream(fos);
					zos.putNextEntry(new ZipEntry(new File(sqlPath).getName()));

					byte[] buffer = new byte[1024];
					int len;
					while ((len = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, len);
					}

					zos.closeEntry();
					zos.close();
					fis.close();
					fos.close();

					// Delete original .sql
					new File(sqlPath).delete();

					System.out.println("✅ Auto backup created: " + zipPath);
				} catch (Exception ex) {
					ex.printStackTrace();
					System.err.println("❌ Auto backup failed: " + ex.getMessage());
				}
			}
		}).start();
	}

}
