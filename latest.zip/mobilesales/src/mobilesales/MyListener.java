package mobilesales;

public interface MyListener {
	public void updateListener();
	public void updatePurchase();
	public void updateSales();

}
