package mobilesales;


import java.util.concurrent.*;

public class BackupScheduler {
    public static void startBackupTask() {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        Runnable task = new Runnable() {
            @Override
            public void run() {
                DBBackup.autoBackup();
            }
        };

        // Run first after 10 seconds, then every 24 hours
        scheduler.scheduleAtFixedRate(task, 10, 60 * 60, TimeUnit.SECONDS);
    }
}
