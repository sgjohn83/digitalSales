
package controller;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import model.Brand;
import service.BrandService;

public class BrandController {

    private BrandService brandService;

    public BrandController() {
        brandService = new BrandService();
    }

    // Method to add a brand
    public boolean addBrand(String brandName) {
        // Create a new Brand object
        Brand brand = new Brand(brandName);

        // Use BrandService to add the brand to the database
        return brandService.addBrand(brand);
    }

    // Method to update a brand
    public boolean updateBrand(int brandId, String brandName) {
        // Create a new Brand object with the updated details
        Brand brand = new Brand();
        brand.setBrandId(brandId);
        brand.setBrandName(brandName);

        // Use BrandService to update the brand in the database
        return brandService.updateBrand(brand);
    }

    // Method to delete a brand
    public boolean deleteBrand(int brandId) {
        // Use BrandService to delete the brand from the database
        return brandService.deleteBrand(brandId);
    }

    // Method to get a brand by its ID
    public Brand getBrandById(int brandId) {
        // Use BrandService to fetch a brand by ID
        return brandService.getBrandById(brandId);
    }

    // Method to check if a brand exists
    public boolean brandExists(String brandName) {
        // Use BrandService to check if the brand exists in the database
        return brandService.brandExists(brandName);
    }

    // Method to get all brands
    public void getAllBrands() {
        // Use BrandService to retrieve all brands
        for (Brand brand : brandService.getAllBrands()) {
            System.out.println(brand);
        }
    }

    // Method to get the total count of brands
    public int getBrandCount() {
        // Use BrandService to get the count of brands
        return brandService.getBrandCount();
    }
    
    public void loadBrandsIntoComboBox(JComboBox<String> comboBox) {
        // Create an instance of the BrandService
        BrandService brandService = new BrandService();

        // Get all brands from the database
        List<Brand> brands = brandService.getAllBrands();

        // Clear existing items in the combo box
        comboBox.removeAllItems();
        comboBox.addItem("   Select Brand   ");
        comboBox.addItem("ALL");
        // Add brand names to the combo box
        for (Brand brand : brands) {
            comboBox.addItem(brand.getBrandName());
        }
    }

	public void loadmodelCombo(JComboBox<String> modelCombo, String selectedBrand) {
	
		int brandId = getBrandIdByName(selectedBrand);
		// Query to fetch product models for the selected brand
		System.out.print("brand id = "+brandId);
        String query = "SELECT model FROM product WHERE brand_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, brandId);  // Set the brand_id parameter in the query
            ResultSet rs = pstmt.executeQuery();
            
            // Clear previous models
            modelCombo.removeAllItems();
            System.out.println("[INFO] Cleared model combo and added default option.");
            modelCombo.addItem("");  // Default option
          
            // Add models to the combo box
            while (rs.next()) {
                String model = rs.getString("model");
                modelCombo.addItem(model);
                System.out.println("[DEBUG] Model added: " + model);
            }
            modelCombo.revalidate();
            modelCombo.repaint();
            
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading models from database.");
        }
	}
	
    private int getBrandIdByName(String brandName) {
        String query = "SELECT brand_id FROM brand WHERE brand_name = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, brandName);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("brand_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return -1;  // Return an invalid ID if brand is not found
    }

}
