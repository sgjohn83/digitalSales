package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import mobilesales.DeleteProductView;
import service.ProductService;

public class DeleteProductController {
	DeleteProductView view;
	ProductService ps ;
	public DeleteProductController(DeleteProductView view) {
		this.view= view;
		ps = new ProductService();
		initController();
	}
	private void initController() {
		// TODO Auto-generated method stub
		this.view.addDeleteListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteProduct();
            }

			private void deleteProduct() {
				
				String imei = view.getImeiInput();
	            if (imei.isEmpty()) {
	                view.showMessage("Please enter IMEI number");
	                return;
	            }

	            try {
	                boolean isSold = ps.isProductSold(imei);
	                if (isSold) {
	                    view.showMessage("Cannot delete. Product has already been sold.");
	                } else {
	                    boolean deleted = ps.deleteProductByImei(imei);
	                    if (deleted) {
	                        view.showMessage("Product deleted successfully.");
	                        view.clearInput();
	                    } else {
	                        view.showMessage("IMEI not found or could not be deleted.");
	                    }
	                }
	            } catch (Exception ex) {
	                ex.printStackTrace();
	                view.showMessage("Error: " + ex.getMessage());
	            }
			}
        });
	}
    
}
