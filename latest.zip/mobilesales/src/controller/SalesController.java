package controller;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JOptionPane;

import mobilesales.BillPrinter;
import mobilesales.DBConnection;
import mobilesales.MyListener;
import mobilesales.MobilePos;
import model.Brand;
import model.Customer;
import model.Product;
import model.ProductStock;
import model.Sales;
import model.SalesItem;
import model.User;
import service.CustomerService;
import service.ProductStockService;
import service.SalesItemService;
import service.SalesService;
import service.UserService;

public class SalesController {
	private Connection conn;

	public ProductStock getProductStockByIMEI(String imeiNo) throws SQLException {
		String sql = "SELECT ps.imei_no, ps.selling_price, ps.status, ps.quantity, ps.date_added, "
				+ "p.product_id, p.product_code, p.model, p.ram, p.storage, p.price, p.description, "
				+ "b.brand_id, b.brand_name " + "FROM productstock ps "
				+ "JOIN product p ON ps.product_id = p.product_id " + "JOIN brand b ON p.brand_id = b.brand_id "
				+ "WHERE ps.imei_no = ?";
		try {

			conn = DBConnection.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, imeiNo);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				Brand brand = new Brand(rs.getInt("brand_id"), rs.getString("brand_name"));

				Product product = new Product();
				product.setProductId(rs.getInt("product_id"));
				product.setProductCode(rs.getString("product_code"));
				product.setModel(rs.getString("model"));
				product.setRam(rs.getString("ram"));
				product.setStorage(rs.getString("storage"));
				product.setPrice(rs.getDouble("price"));
				product.setDescription(rs.getString("description"));
				product.setBrand(brand);

				ProductStock stock = new ProductStock();
				stock.setImeiNo(rs.getString("imei_no"));
				stock.setSellingPrice(rs.getDouble("selling_price"));
				stock.setStatus(rs.getString("status"));
				stock.setQuantity(rs.getInt("quantity"));
				stock.setDateAdded(rs.getTimestamp("date_added"));
				stock.setProduct(product);

				return stock;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void addSalesToDB(String imei, String name, String mobile, String invoice_no, String invoice_date,
			String user, String payment_type, Boolean isFinanced, double downpayment, double total, double uprice,
			double cgst, double sgst, MyListener ml) throws SQLException {
		System.out.print("button clicked" + invoice_date);
		ProductStockService p1 = new ProductStockService();
		Boolean status = p1.isProductSold(imei);
		if (status) {
			JOptionPane.showMessageDialog(null, "Product with IMEI " + imei + " is already sold.", "Sold Product",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		ProductStock product = getProductStockByIMEI(imei);

		CustomerService cs = new CustomerService();
		Customer cust = cs.addOrGetCustomer(name, mobile);
		UserService usc = new UserService();
		int uid = usc.getUserIdByUsername(user);
		System.out.println("button clicked" + uid);
		System.out.println("button clicked" + imei);
		// Parse invoice_date (String to java.sql.Date)
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

		// Parse the string to LocalDateTime
		LocalDateTime localDateTime = LocalDateTime.parse(invoice_date, formatter);

		// Convert to java.sql.Timestamp
		Timestamp sqlTimestamp = Timestamp.valueOf(localDateTime);

		// Set to Sales object
		Sales sale = new Sales();
		sale.setInvoiceNo(invoice_no);
		sale.setInvoiceDate(sqlTimestamp);
		sale.setCustomerId(cust.getCustomerId());
		sale.setUserId(uid);
		sale.setPaymentType(payment_type);
		sale.setFinanced(isFinanced);
		sale.setDownPayment(BigDecimal.valueOf(downpayment));
		sale.setTotalAmount(BigDecimal.valueOf(total));

		// Save using service
		SalesService ss = new SalesService();
		Sales savedSale = ss.addSale(sale);

		SalesItem salitem = new SalesItem();
		salitem.setCgst(new BigDecimal(String.valueOf(cgst)));
		salitem.setImeiNo(imei);
		salitem.setSalesId(savedSale.getSalesId());
		salitem.setSgst(new BigDecimal(String.valueOf(sgst)));
		salitem.setUnitPrice(new BigDecimal(String.valueOf(uprice)));

		SalesItemService sis = new SalesItemService();
		sis.insertSalesItem(salitem);
		// (Optional) Show ID or further action

		updateProductStockAfterSale(imei);
		BillPrinter bp = new BillPrinter();
		bp.printBill(savedSale.getSalesId());
		JOptionPane.showMessageDialog(null, "Sale inserted with ID: " + savedSale.getSalesId());
		ml.updateSales();
		

	}

	public boolean updateProductStockAfterSale(String imeiNo) {
		String sql = "UPDATE productstock SET status = 'Sold' WHERE imei_no = ?";

		try {
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, imeiNo);
			int rowsUpdated = stmt.executeUpdate();
			return rowsUpdated > 0;

		} catch (SQLException e) {
			System.err.println("Error updating product stock after sale: " + e.getMessage());
			return false;
		}
	}

	public void handleRefresh(java.util.Date from, java.util.Date to) {
		// TODO Auto-generated method stub
		
	}

}
