package controller;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import mobilesales.MobilePos;
import mobilesales.StockReportView;
import model.StockItem;
import service.StockReports;

public class StockReportsController2 {

	private StockReportView view;
	private StockReports dao;
	DefaultTableModel modelTable;

	public StockReportsController2(StockReportView view) {
		this.view = view;
		this.dao = new StockReports();
		modelTable = (DefaultTableModel) view.getStockReportTable().getModel();
		init();
	}

	private void init() {
		BrandController bc = new BrandController();
		bc.loadBrandsIntoComboBox(view.getReportsBrandComboBox());
		view.getReportsViewBtn().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				loadStockData();
			}
		});
		view.getStockReportTable().setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				String status = table.getValueAt(row, 6).toString(); // 5th
																		// column
				System.out.println(status); // =
				// Status
				// (after
				// adding
				// RAM,
				// Storage)

				if (!isSelected) {
					if (status.equalsIgnoreCase("In Stock")) {
						c.setBackground(new Color(200, 255, 200)); // light
																	// green
					} else if (status.equalsIgnoreCase("Sold")) {
						c.setBackground(new Color(255, 102, 102)); // light red
					} else {
						c.setBackground(Color.WHITE); // default color
					}
				} else {
					c.setBackground(table.getSelectionBackground()); // selection
																		// background
				}

				return c;
			}
		});
		view.getTblSearch().getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				filter();
			}

			@Override
			public void insertUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				filter();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub

			}

			private void filter() {
				String searchText = view.getTblSearch().getText().toLowerCase();
				TableRowSorter<TableModel> tempSorter = new TableRowSorter<TableModel>(modelTable) {
					public void toggleSortOrder(int column) {
					} // Prevent sorting
				};
				tempSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
				view.getStockReportTable().setRowSorter(tempSorter);

			}
		});

	

	}

	private void loadStockData() {
		System.out.println("loadstock");
		String brand = (String) view.getReportsBrandComboBox().getSelectedItem();
		String status = (String) view.getReportsStatuscomboBox().getSelectedItem();
		String model = view.getReportsModelNameTxt().getText();
		String billTyoe = (String) view.getComboBox().getSelectedItem();
		List<StockItem> data = dao.searchStock(brand, status, model, billTyoe);

	
		modelTable.setRowCount(0);

		// Set headers
		if (modelTable.getColumnCount() == 0) {
			modelTable.setColumnIdentifiers(new String[] { "IMEI", "Model", "Product Code", "Brand", "RAM", "Storage",
					"Status", "Price", "Purchase Date" });
		}

		int totalQty = 0;
		double totalAmount = 0.0;

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

		for (StockItem ps : data) {

			modelTable.addRow(new Object[] { ps.getImei(), ps.getModel(), ps.getProductCode(), ps.getBrand(),
					ps.getRam(), ps.getStorage(), ps.getStatus(), ps.getPrice(),
					ps.getPurchaseDate() != null ? ps.getPurchaseDate().format(dtf) : "" });
			totalQty++;
			totalAmount += ps.getPrice();
		}

		view.getReportQuantity().setText(String.valueOf(totalQty));
		view.getReportAmount().setText(String.format("%.2f", totalAmount));
	}
}
