package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import mobilesales.ResetPassword;
import model.User;
import service.UserService;

public class ResetPasswordController {
	private ResetPassword rp;
	private UserService us;
	private List<User> users;
	private JComboBox<String> ucombo;

	public ResetPasswordController(ResetPassword rp) {
		this.rp = rp;
		us = new UserService();
		ucombo = rp.getUsersCombo();

		// Load users into combo box
		try {
			users = us.getAllUsers();
			for (User user : users) {
				ucombo.addItem(user.getUsername());
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(rp, "Error loading users: " + e.getMessage());
		}

		// Add submit listener
		rp.getBtnResetPassword().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				resetPassword();
			}
		});
	}

	public void resetPassword() {
		String selectedUser = (String) ucombo.getSelectedItem();
	


		try {
			String hashed = us.hashPassword("123456");

			boolean success = updatePasswordByUsername(selectedUser, hashed);
			if (success) {
				JOptionPane.showMessageDialog(rp, "Password updated successfully for user: " + selectedUser);
				rp.dispose();
			} else {
				JOptionPane.showMessageDialog(rp, "Failed to update password.");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(rp, "Error: " + ex.getMessage());
		}
	}

	    // Method to update password by username
	    public boolean updatePasswordByUsername(String username, String hashedPassword) throws SQLException {
	        String query = "UPDATE user SET password = ? WHERE username = ?";

	        try (Connection conn = DBConnection.getConnection(); 
	             PreparedStatement ps = conn.prepareStatement(query)) {

	            ps.setString(1, hashedPassword);  // Set hashed password
	            ps.setString(2, username);  // Set username condition

	            int rowsUpdated = ps.executeUpdate();

	            // Return true if the password is successfully updated
	            return rowsUpdated > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw new SQLException("Error updating password", e);
	        }
	    }
	}



