package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import mobilesales.PrintCustomerBill;
import model.SalesBillModel;
import service.CustomerBillModel;

public class PrintCustomerBillController {
	PrintCustomerBill view;
	CustomerBillModel model;

	public PrintCustomerBillController(PrintCustomerBill view,CustomerBillModel model) {
		this.view = view;
		this.model = model;
		initController();
	}
	 private void initController() {
	        view.getSearchButton().addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                onSearchClicked(e);
	            }
	        });
	    }

	 private void onSearchClicked(ActionEvent e) {
		    String mobileNo = view.getMobileText().getText().trim();

		    if (mobileNo.isEmpty()) {
		        javax.swing.JOptionPane.showMessageDialog(view, "Please enter a mobile number.");
		        return;
		    }

		    List<SalesBillModel> customerData = model.getBillsByCustomerMobile(mobileNo);

		    DefaultTableModel tableModel = (DefaultTableModel) view.getCustomerbillTable().getModel();
		    tableModel.setRowCount(0); // Clear existing data

		    if (customerData == null || customerData.isEmpty()) {
		        javax.swing.JOptionPane.showMessageDialog(view, "No bill found for this mobile number.");
		    } else {
		        for (SalesBillModel bill : customerData) {
		            tableModel.addRow(new Object[] {
		                bill.getInvoiceNo(),
		                bill.getInvoiceDate(),
		                bill.getModel(),
		                bill.getImei(),
		                bill.getRam(),
		                bill.getStorage(),
		                bill.getTotalAmount()
		            });
		        }
		    }
		}

}
