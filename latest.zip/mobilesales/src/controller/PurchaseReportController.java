package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import mobilesales.DBBackup;
import mobilesales.DBConnection;
import mobilesales.PurchaseReportView;
import model.Brand;
import model.Supplier;
import service.BrandService;
import service.SupplierService;

public class PurchaseReportController {
	PurchaseReportView view;

	public PurchaseReportController(PurchaseReportView view) throws SQLException {
		this.view = view;
		initController();
	}

	private void initController() throws SQLException {
		BrandService b = new BrandService();
		List<Brand> brands = b.getAllBrands();
		view.getBrandCombo().addItem("ALL");
		for (Brand brand : brands) {
			view.getBrandCombo().addItem(brand.getBrandName()); // Assuming Brand has a getName() method
		}
		SupplierService ss = new SupplierService();
		List<Supplier> sup = ss.getAllSuppliers();
		view.getSupplierCombo().addItem("ALL");
		for (Supplier s : sup) {
			view.getSupplierCombo().addItem(s.getSupplierName()); // Assuming Brand has a getName() method
		}

		view.getSearchBtn().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				loadTable1();

			}

		});
		view.getInvoiceTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					{
						int selectedRow = view.getInvoiceTable().getSelectedRow();
						if (selectedRow != -1) {
							Object invoiceNoObj = view.getInvoiceTable().getValueAt(selectedRow, 0); // assuming column
																										// 0 has invoice
																										// no
							String invoiceNo = invoiceNoObj.toString();
							System.out.println("Invoice No selected: " + invoiceNo);
							loadProductTable(invoiceNo);

						}
					}
				}

			}

		});

	}

	private void loadProductTable(String invoiceno) {

		String[] headers = {
	            "Brand", "Model", "IMEI", "RAM", "Storage", "Total Amount"
	        };
	        DefaultTableModel model = new DefaultTableModel(headers, 0);

	        Connection con = null;
	        PreparedStatement pst = null;
	        ResultSet rs = null;

	        try {
	            // 2) load driver and connect
	            Class.forName("com.mysql.jdbc.Driver");
	            con = DBConnection.getConnection();
	            // 3) query using exact schema names
	            String sql =
	                "SELECT b.brand_name, pr.model, pi.imei_no, pr.ram, pr.storage, pi.unit_price " +
	                "FROM purchaseitem pi " +
	                "JOIN purchase pu       ON pi.purchase_id    = pu.purchase_id " +
	                "JOIN productstock ps   ON pi.imei_no        = ps.imei_no " +
	                "JOIN product pr        ON ps.product_id     = pr.product_id " +
	                "JOIN brand b           ON pr.brand_id       = b.brand_id " +
	                "WHERE pu.invoice_no = ?";

	            pst = con.prepareStatement(sql);
	            pst.setString(1, invoiceno);
	            rs = pst.executeQuery();

	            // 4) populate model
	            while (rs.next()) {
	                Object[] row = new Object[] {
	                    rs.getString("brand_name"),
	                    rs.getString("model"),
	                    rs.getString("imei_no"),
	                    rs.getString("ram"),
	                    rs.getString("storage"),
	                    rs.getDouble("unit_price")
	                };
	                model.addRow(row);
	            }

	            // 5) set it on the table
	            view.getDetailTable().setModel(model);
	            int totalDetailCount = model.getRowCount();
	            view.totalDetailItems.setText(String.valueOf(totalDetailCount));

	        } catch (ClassNotFoundException cnf) {
	            JOptionPane.showMessageDialog(
	                null,
	                "JDBC Driver not found:\n" + cnf.getMessage(),
	                "Driver Error",
	                JOptionPane.ERROR_MESSAGE
	            );
	        } catch (SQLException sqle) {
	            JOptionPane.showMessageDialog(
	                null,
	                "Database error:\n" + sqle.getMessage(),
	                "SQL Error",
	                JOptionPane.ERROR_MESSAGE
	            );
	        } finally {
	            // 6) clean up
	            try { if (rs  != null) rs.close();  } catch (SQLException e) { /* ignore */ }
	            try { if (pst != null) pst.close(); } catch (SQLException e) { /* ignore */ }
	            try { if (con != null) con.close(); } catch (SQLException e) { /* ignore */ }
	        }
	    }
	

	private void loadTable1() {
		JDateChooser sdate = view.getStartDate();
		JDateChooser edate = view.getEndDate();
		String brandName = (String) view.getBrandCombo().getSelectedItem();
		String supname = (String) view.getSupplierCombo().getSelectedItem();
		String type = (String) view.getTypeCombo().getSelectedItem();
		String invoice_no = view.getInvoiceText().getText();
		performSearch(brandName, supname, type, invoice_no);

	}

	private void performSearch(String brandName, String supname, String type, String invoice_no) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		// Get values from the view

		JDateChooser sDate = view.getStartDate();
		JDateChooser eDate = view.getEndDate();

		String[] columnNames = { "Invoice No", "Date", "By User", "Supplier", "Total Amount" };
		DefaultTableModel model = new DefaultTableModel(columnNames, 0);
		view.getInvoiceTable().setModel(model);

		String query = "SELECT DISTINCT p.invoice_no, p.invoice_date, u.username, s.supplier_name, p.total_amount "
				+ "FROM purchase p " + "JOIN user u ON p.user_id = u.user_id "
				+ "JOIN supplier s ON p.supplier_id = s.supplier_id "
				+ "JOIN purchaseitem pi ON pi.purchase_id = p.purchase_id "
				+ "JOIN productstock ps ON ps.imei_no = pi.imei_no "
				+ "JOIN product prod ON ps.product_id = prod.product_id "
				+ "JOIN brand b ON prod.brand_id = b.brand_id " + "WHERE 1=1 ";

		List<Object> params = new ArrayList<>();

		if (sDate.getDate() != null && eDate.getDate() != null) {
			query += "AND p.invoice_date BETWEEN ? AND ? ";
			params.add(new java.sql.Date(sDate.getDate().getTime()));
			params.add(new java.sql.Date(eDate.getDate().getTime()));
		}

		if (brandName != null && !brandName.equalsIgnoreCase("ALL")) {
			query += "AND b.brand_name = ? ";
			params.add(brandName);
		}

		if (supname != null && !supname.equalsIgnoreCase("ALL")) {
			query += "AND s.supplier_name = ? ";
			params.add(supname);
		}

		if (type != null && !type.equalsIgnoreCase("ALL")) {
			query += "AND prod.product_type = ? ";
			params.add(type);
		}

		if (invoice_no != null && !invoice_no.trim().isEmpty()) {
			query += "AND p.invoice_no LIKE ? ";
			params.add("%" + invoice_no.trim() + "%");
		}
		double totalAmountSum = 0;
		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(query)) {

			for (int i = 0; i < params.size(); i++) {
				ps.setObject(i + 1, params.get(i));
			}

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				double amt = rs.getDouble("total_amount");
				model.addRow(new Object[] { rs.getString("invoice_no"), rs.getDate("invoice_date"),
						rs.getString("username"), rs.getString("supplier_name"), rs.getDouble("total_amount") });
				   totalAmountSum += amt;
			}
			
			
			int totalInvCount = model.getRowCount();
			int totalInvStockCount  = countStockFromJTable(view.getInvoiceTable());
			System.out.println(totalInvStockCount);
			view.totalInventoryStock.setText(String.valueOf(totalInvStockCount));
	        view.totalInvoiceItems.setText(String.valueOf(totalInvCount));
	        view.totalInvoiceAmount.setText(String.format("%.2f", totalAmountSum));

	        // Clear detail-items summary when you re-search
	        view.totalDetailItems.setText("0");

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
		}

	}
	
	public static int countStockFromJTable(JTable table) {
        int totalStockCount = 0;

        // Database configuration (update with your DB credentials)
        String url = "jdbc:mysql://localhost:3306/mobileshop";
        String user = "root";
        String password = "your_password";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Load driver and connect
            Class.forName("com.mysql.jdbc.Driver");
            conn =  DBConnection.getConnection();

            // Collect invoice numbers from JTable (assuming 2nd column is invoice number)
            Set<String> invoiceSet = new HashSet<String>();
            int invoiceColIndex = 1; // 2nd column (0-based index)
            for (int i = 0; i < table.getRowCount(); i++) {
                Object val = table.getValueAt(i, 0);
                System.out.println(val.toString());
                if (val != null && !val.toString().trim().isEmpty()) {
                    invoiceSet.add(val.toString().trim());
                }
            }

            if (invoiceSet.isEmpty()) return 0;

            // Generate placeholders (?, ?, ...)
            StringBuilder placeholder = new StringBuilder();
            for (int i = 0; i < invoiceSet.size(); i++) {
                placeholder.append("?");
                if (i < invoiceSet.size() - 1) {
                    placeholder.append(",");
                }
            }

            // Query using purchase path (assumes GST report is from purchase invoices)
            String sql = "SELECT COUNT(DISTINCT ps.imei_no) FROM productstock ps " +
                         "JOIN purchase p ON ps.purchase_id = p.purchase_id " +
                         "WHERE p.invoice_no IN (" + placeholder.toString() + ")";

            stmt = conn.prepareStatement(sql);
            int idx = 1;
            for (String invoice : invoiceSet) {
                stmt.setString(idx++, invoice);
            }

            rs = stmt.executeQuery();
            if (rs.next()) {
                totalStockCount = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        return totalStockCount;
    }

}