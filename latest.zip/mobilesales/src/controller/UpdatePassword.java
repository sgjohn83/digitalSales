package controller;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.text.View;

import mobilesales.ChangePassword;
import mobilesales.DBConnection;
import model.CurrentUser;
import model.LoginModel;
import service.UserService;

public class UpdatePassword {
	ChangePassword view;
	LoginModel model;
    UserService us = new UserService();
	public UpdatePassword(ChangePassword frame) {
		view = frame;
		view.getBtnSubmit().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					update();
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NoSuchAlgorithmException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
	}
   public void update() throws HeadlessException, NoSuchAlgorithmException
   {
	   String currentpwd = view.getTxtCurrentPassword().getText();
	   String newPassword = view.getTxtNewPassword().getText();
	   String confirmPassword = view.getTxtConfirmPassword().getText();
	   String username = CurrentUser.getUsername();
		if (username == null || username.isEmpty()) {
			JOptionPane.showMessageDialog(view, "No user is currently logged in.");
			return;
		}

		if (currentpwd.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
			JOptionPane.showMessageDialog(view, "All fields are required.");
			return;
		}

		if (!newPassword.equals(confirmPassword)) {
			JOptionPane.showMessageDialog(view, "New password and confirm password do not match.");
			return;
		}
	     String codePwd = us.hashPassword(currentpwd);
	 
		try (Connection con = DBConnection.getConnection()) {
			// Verify current password
			PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE username=? AND password=?");
			ps.setString(1, username);
			ps.setString(2, codePwd);
			ResultSet rs = ps.executeQuery();
          
			if (rs.next()) {
				String newCode = us.hashPassword(confirmPassword);
				// Update password
				ps = con.prepareStatement("UPDATE user SET password=? WHERE username=?");
				ps.setString(1, newCode);
				ps.setString(2, username);
				int updated = ps.executeUpdate();

				if (updated > 0) {
					JOptionPane.showMessageDialog(view, "Password updated successfully.");
					view.dispose();
				} else {
					JOptionPane.showMessageDialog(view, "Failed to update password.");
				}
			} else {
				JOptionPane.showMessageDialog(view, "Current password is incorrect.");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(view, "Error: " + ex.getMessage());
		}
	}
   }

