package controller;

import javax.swing.*;

import model.Supplier;
import service.SupplierService;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class SupplierController {

    private JTextField txtSupplierName;
    private JTextField txtMobileNo;
    private JTextArea txtAddress;
    private SupplierService supplierService;
    
   

    public SupplierController(JTextField txtSupplierName, JTextField txtMobileNo, JTextArea txtAddress) {
        this.txtSupplierName = txtSupplierName;
        this.txtMobileNo = txtMobileNo;
        this.txtAddress = txtAddress;
        this.supplierService = new SupplierService();
    }

    public SupplierController() {
		// TODO Auto-generated constructor stub
	}

	// This method is triggered when the Save button is clicked
    public void saveSupplier() {
        try {
            String name = txtSupplierName.getText().trim();
            String mobile = txtMobileNo.getText().trim();
            String address = txtAddress.getText().trim();

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Supplier name is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Supplier supplier = new Supplier();
            supplier.setSupplierName(name);
            supplier.setMobileNo(mobile);
            supplier.setAddress(address);

            supplierService.addSupplier(supplier);

            JOptionPane.showMessageDialog(null, "Supplier saved successfully!");
            clearForm();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving supplier: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public void clearForm() {
        txtSupplierName.setText("");
        txtMobileNo.setText("");
        txtAddress.setText("");
    }

    // Optional: attach this to a Save button
    public ActionListener getSaveActionListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveSupplier();
            }
        };
    }
  

}

