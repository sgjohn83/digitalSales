package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import mobilesales.UpdateSales;
import model.SaleReportRow;

public class UpdateSalesController {
	UpdateSales view;;
	SaleReportRow sr;

	public UpdateSalesController(UpdateSales sales, SaleReportRow sr) {
		this.view = sales;
		this.sr = sr;
		loadFields();
		view.getBtnUpdate().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				 updateSales();

			}

		});
	}

	// Method to load data into the fields from SaleReportRow
	private void loadFields() {

		view.getTextFieldInvoiceNo().setText(sr.getInvoiceNo());

		view.getTextFieldDownPayment().setText(String.valueOf(sr.getDownPayment()));

		view.getTextFieldSoldAmount().setText(String.valueOf(sr.getTotalAmount()));

		view.getChckbxIsFinanced().setSelected(sr.getFinanced());
	}



	public void updateSales() {
	    // Get values from the fields in UpdateSales view

	    String salesInvoiceNo = view.getTextFieldInvoiceNo().getText();
	    String downPaymentText = view.getTextFieldDownPayment().getText();
	    double downPayment = 0;
	    if (!downPaymentText.isEmpty()) {
	        downPayment = Double.parseDouble(downPaymentText);
	    }

	    String soldAmountText = view.getTextFieldSoldAmount().getText();
	    double soldAmount = 0;
	    if (!soldAmountText.isEmpty()) {
	        soldAmount = Double.parseDouble(soldAmountText);
	    }

	    boolean isFinanced = view.getChckbxIsFinanced().isSelected();
	    int financedFlag = isFinanced ? 1 : 0; // Convert boolean to 0/1 for DB

	    Connection conn = DBConnection.getConnection();
	    PreparedStatement updateSalesItemStmt = null;
	    PreparedStatement updateSalesStmt = null;

	    try {
	        conn.setAutoCommit(false); // Start transaction

	        // 1. Update salesitem (unit_price, cgst, sgst)
	        String updateSalesItemSQL = 
	                "UPDATE salesitem si " +
	                "JOIN sales s ON s.sales_id = si.sales_id " +
	                "SET " +
	                "    si.unit_price = ROUND((?/1.18), 2), " +
	                "    si.cgst = ROUND((?/1.18) * 0.09, 2), " +
	                "    si.sgst = ROUND((?/1.18) * 0.09, 2) " +
	                "WHERE s.invoice_no = ?";

	        updateSalesItemStmt = conn.prepareStatement(updateSalesItemSQL);
	        updateSalesItemStmt.setDouble(1, soldAmount);
	        updateSalesItemStmt.setDouble(2, soldAmount);
	        updateSalesItemStmt.setDouble(3, soldAmount);
	        updateSalesItemStmt.setString(4, salesInvoiceNo);

	        int rowsAffectedSalesItem = updateSalesItemStmt.executeUpdate();
	        System.out.println("Rows affected in salesitem: " + rowsAffectedSalesItem);

	        // 2. Update sales (total_amount, down_payment, is_financed)
	        String updateSalesSQL = 
	                "UPDATE sales " +
	                "SET total_amount = ?, " +
	                "    down_payment = ?, " +
	                "    is_financed = ? " +
	                "WHERE invoice_no = ?";

	        updateSalesStmt = conn.prepareStatement(updateSalesSQL);
	        updateSalesStmt.setDouble(1, soldAmount);
	        updateSalesStmt.setDouble(2, downPayment);
	        updateSalesStmt.setInt(3, financedFlag);
	        updateSalesStmt.setString(4, salesInvoiceNo);

	        int rowsAffectedSales = updateSalesStmt.executeUpdate();
	        if(rowsAffectedSales>0)
	        JOptionPane.showMessageDialog(
	                view, 
	                "Sales record updated successfully!", 
	                "Success", 
	                JOptionPane.INFORMATION_MESSAGE);

	        conn.commit(); // Commit transaction

	    } catch (SQLException e) {
	        e.printStackTrace();
	        if (conn != null) {
	            try {
	                conn.rollback(); // Rollback on error
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	        }
	    } finally {
	        try {
	            if (updateSalesItemStmt != null) updateSalesItemStmt.close();
	            if (updateSalesStmt != null) updateSalesStmt.close();
	            if (conn != null) conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

}