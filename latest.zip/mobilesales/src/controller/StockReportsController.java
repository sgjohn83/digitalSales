package controller;

import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.table.DefaultTableModel;

import mobilesales.MobilePos;
import model.StockItem;
import service.StockReports;

public class StockReportsController {

    private MobilePos view;
    private StockReports dao;

    public StockReportsController(MobilePos view) {
        this.view = view;
        this.dao = new StockReports();
        init();
    }

    private void init() {
        view.setBrandList(dao.getAllBrands());
        view.setSearchAction(e -> loadStockData());
        loadStockData();
    }

    private void loadStockData() {
        System.out.println("loadstock");
        String brand = view.getSelectedBrand();
        String status = view.getSelectedStatus();
        String model = view.getModelSearchText();
        String billTyoe  = view.getBillTypeComboBox();
        List<StockItem> data = dao.searchStock(brand, status, model,billTyoe);

        DefaultTableModel modelTable = (DefaultTableModel) view.getTable().getModel();
        modelTable.setRowCount(0);

        // Set headers
        if (modelTable.getColumnCount() == 0) {
            modelTable.setColumnIdentifiers(new String[]{
                "IMEI", "Model","Product Code", "Brand", "RAM", "Storage", "Status", "Price", "Purchase Date"
            });
        }

        int totalQty = 0;
        double totalAmount = 0.0;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

        for (StockItem ps : data) {
        
            modelTable.addRow(new Object[]{
                ps.getImei(),
                ps.getModel(),
                ps.getProductCode(),
                ps.getBrand(),
                ps.getRam(),
                ps.getStorage(),
                ps.getStatus(),
                ps.getPrice(),
                ps.getPurchaseDate() != null ? ps.getPurchaseDate().format(dtf) : ""
            });
            totalQty++;
            totalAmount += ps.getPrice();
        }

        view.getTotalQtyLabel().setText(String.valueOf(totalQty));
        view.getTotalAmountLabel().setText(String.format("%.2f", totalAmount));
    }
}
