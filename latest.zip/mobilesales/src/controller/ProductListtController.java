package controller;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import mobilesales.ProductList;
import model.Product;
import model.Product2;
import service.ProductService;

public class ProductListtController {
   ProductService ps;
   private ProductList  pl;
   private List<Product2> productList;
private JTable table;
private DefaultTableModel model;
   
   
   public ProductListtController(ProductList pl)
   {
	   this.pl  = pl;
	   ps =  new ProductService();
	   table = pl.getProducrTable() ;
	   model = (DefaultTableModel) table.getModel();
	   loadProducts();
	  
	   
   }
   private void loadProducts() {
	    try {
	        System.out.println("Loading products from ProductService...");
	        productList = ps.getAllProducts();

	        if (productList == null) {
	            System.out.println("Product list is null.");
	        } else {
	            System.out.println("Products loaded successfully. Total: " + productList.size());
	        }

	        showInTable(productList);
	        System.out.println("Products displayed in table.");

	    } catch (Exception e) {
	        System.err.println("Exception in loadProducts: " + e.getMessage());
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error loading products: " + e.getMessage());
	    }
	}

   private void showInTable(List<Product2> productList2) {
	    System.out.println("Populating table with products...");

	    if (model == null) {
	        model = (DefaultTableModel) table.getModel(); // Initialize if not already
	    }

	    model.setRowCount(0);

	    if (productList2 == null) {
	        System.out.println("Product list is null.");
	        return;
	    }

	    if (productList2.isEmpty()) {
	        System.out.println("Product list is empty.");
	        return;
	    }

	    int index = 0;
	    for (Product2 p : productList2) {
	        if (p == null) {
	            System.out.println("Null product at index " + index);
	            continue;
	        }

	        System.out.println("Adding to table: " +
	           
	            p.getProductId() + ", " +
	            p.getBrandName() + ", " +
	            p.getModel() + ", " +
	            p.getImei() + ", " + // IMEI added here
	            p.getRam() + ", " +
	            p.getStorage() + ", " +
	            p.getPrice());

	        model.addRow(new Object[]{
	            p.getProductId(),
	            p.getBrandName(),
	            p.getModel(),
	            p.getImei(),      // ✅ Added IMEI here properly
	            p.getRam(),
	            p.getStorage(),
	            String.format("%.2f", p.getPrice())
	        });

	        index++;
	    }

	    System.out.println("Total products added to table: " + index);
	}

       private void styleTable() {
           table.setFont(new Font("SansSerif", Font.PLAIN, 14));
           table.setRowHeight(24);
           JTableHeader header = table.getTableHeader();
           header.setFont(new Font("SansSerif", Font.BOLD, 15));
           header.setBackground(new Color(60, 120, 180));
           header.setForeground(Color.WHITE);
           table.setSelectionBackground(new Color(220, 240, 255));
           table.setGridColor(Color.LIGHT_GRAY);
       }
       private void filterProducts(String query) {
           Vector<Product2> filtered = new Vector<Product2>();
           for (Product2 p : productList) {
               if (p.getBrandName().toLowerCase().contains(query) || p.getModel().toLowerCase().contains(query)) {
                   filtered.add(p);
               }
           }
           showInTable(filtered);
       }
}
