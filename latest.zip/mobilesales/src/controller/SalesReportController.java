package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import model.SaleRecord;
import model.SalesReportModel;
import mobilesales.SalesReportView;

public class SalesReportController {
    private SalesReportModel model;
    private SalesReportView view;

    public SalesReportController(SalesReportModel model, SalesReportView view) {
        this.model = model;
        this.view  = view;
        initController();
        loadBrands();
    }

    private void initController() {
        view.addGenerateListener(new ActionListener() {
            @Override public void actionPerformed(ActionEvent e) {
                onGenerate();
            }
        });
        view.addExportListener(e -> view.exportToPDF());

    }

    private void loadBrands() {
        List<String> brands = model.fetchBrands();
        view.setBrandOptions(brands);
    }
  
    private void onGenerate() {
        java.util.Date start = view.getStartDate();
        java.util.Date end = view.getEndDate();
        String brand = view.getSelectedBrand();
        String isFinance = view.getSelectedFinance();

        model.fetchData(start, end, brand, null, isFinance);
        List<SaleRecord> recs = model.getRecords();

        view.updateTable(recs);
        view.updateSummary(
            model.getTotalSales(),
            model.getTotalTransactions(),
            model.getTotalDownPayment(),
            model.getTotalPurchase(),
            model.getProfitLoss(),
            model.getNetProfit(),
            model.getNetLoss()
        );
    }
}
