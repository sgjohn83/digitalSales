

package controller;



import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;

import javax.swing.JOptionPane;

import mobilesales.EmailSender;
import mobilesales.Login;
import mobilesales.MobilePos;
import mobilesales.OTPFormFixedEmail;
import mobilesales.OTPUtil;
import model.CurrentUser;
import model.LoginModel;

public class LoginController {

    private LoginModel model;
    private Login view;

    public LoginController(LoginModel model, Login view) {
        this.model = model;
        this.view = view;

        this.view.btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = view.txtUsername.getText().trim();
                String password = new String(view.txtPassword.getPassword());

                try {
					if (model.authenticate(username, password)) {
						if(username.equals("admin"))
						{
							boolean b= verifyOtp();
							if(!b)
							{
								System.exit(0);
							}
						}
					    view.lblMessage.setText("Login successful!");
					    JOptionPane.showMessageDialog(view, "Welcome, " + username + "!");
					    CurrentUser.setUsername(username);
					    view.dispose(); // Close login window
					   MobilePos m =  new MobilePos();// Open POS app
					   System.out.print(username);
					   m.mobileAppPos(username);
					    // Here you can open your main dashboard
					} else {
					    view.lblMessage.setText("Invalid username or password.");
					}
				} catch (HeadlessException | NoSuchAlgorithmException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }

			
        });
    }
    private boolean verifyOtp() {
		
    	OTPFormFixedEmail otpDialog = new OTPFormFixedEmail(null, "digital.eck@gmail.com");
        otpDialog.setVisible(true);  // Blocks here until user closes dialog

        if (otpDialog.isVerified()) {
            System.out.println("OTP verified, continue processing...");
            return true;
          
        } else {
            System.out.println("OTP not verified or cancelled.");
           return false;
        }

	}
}
