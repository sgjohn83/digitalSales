package controller;

/* GSTReportController.java */


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import mobilesales.GSTReportsView;
import model.ReportEntry;
import service.GSTReportModel;

public class GSTReportController {
    private final GSTReportsView view;
    private final GSTReportModel model;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public GSTReportController(GSTReportsView view, GSTReportModel model) throws Exception {
        this.view = view;
        this.model = model;
        view.setBrandOptions(model.getBrands());
        view.addGenerateListener(new GenerateListener());
        view.addExportListener(new ExportListener());
        view.addExportCsvListener(new ExportCsvListener());
    }

    private class GenerateListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                String brandFilter = "All".equals(view.getSelectedBrand()) ? null : view.getSelectedBrand();
                String typeFilter  = view.getSelectedType();
                List<ReportEntry> entries = model.getReport(
                    view.getStartDate(), view.getEndDate(), brandFilter, typeFilter
                );
                view.updateTable(entries);
                view.updateSummary(entries);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Error: " + ex.getMessage());
            }
        }
    }

    private class ExportListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Save GST Report");
                chooser.setSelectedFile(new File("GST_Report.pdf"));
                int userSelection = chooser.showSaveDialog(view);
                if (userSelection != JFileChooser.APPROVE_OPTION) return;
                File fileToSave = chooser.getSelectedFile();

                List<ReportEntry> entries = view.getTableData();
                Document doc = new Document();
                PdfWriter.getInstance(doc, new java.io.FileOutputStream(fileToSave));
                doc.open();
                
                doc.add(new Paragraph("GST Report"+view.getSelectedType()));
                doc.add(new Paragraph(view.getSummaryText_1()));
             // Add vertical space (e.g., 15pt gap)
                doc.add(Chunk.NEWLINE);  // You can call it multiple times or use setSpacingBefore on the table
                doc.add(Chunk.NEWLINE);
                PdfPTable table = new PdfPTable(8);
                table.setWidthPercentage(100);
                int i=1;
              //  String[] headers = {"Type","Invoice No","Date","IMEI","Model","Brand","Taxable","CGST","SGST"};
                String[] headers = {"S.NO","Invoice No","Date","Model","Brand","CGST","SGST","Total AMount"};
                for (String h : headers) {
                    PdfPCell cell = new PdfPCell(new Paragraph(h));
                    table.addCell(cell);
                }
                for (ReportEntry r : entries) {
                	double unitPrice = r.getTaxableValue();
                    double cgst = r.getCgst();
                    double sgst = r.getSgst();
                    double finalAmount = unitPrice + cgst + sgst;
                   // table.addCell(r.getType());
                    
                    String formattedSerial = String.format("%02d", i);
                    table.addCell(formattedSerial);
                    table.addCell(r.getInvoiceNo());
                    table.addCell(dateFormat.format(r.getDate()));
                    //table.addCell(r.getImei());
                    table.addCell(r.getModel());
                    table.addCell(r.getBrand());
                   // table.addCell(String.format("%.2f", r.getTaxableValue()));
                    table.addCell(String.format("%.2f", r.getCgst()));
                    table.addCell(String.format("%.2f", r.getSgst()));
                    table.addCell(String.format("%.2f", finalAmount));
                    i++;
                }
                doc.add(table);
                doc.close();
                JOptionPane.showMessageDialog(view, "Exported to " + fileToSave.getAbsolutePath());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Export Error: " + ex.getMessage());
            }
        }
    }
    
    
 
    private class ExportCsvListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Save CSV Report");
                chooser.setSelectedFile(new File("GST_Report.csv"));
                int userSelection = chooser.showSaveDialog(view);
                if (userSelection != JFileChooser.APPROVE_OPTION) return;

                File fileToSave = chooser.getSelectedFile();
                List<ReportEntry> entries = view.getTableData();
                StringBuilder sb = new StringBuilder();

                // Report Heading
                sb.append("GST REPORT\n");
                sb.append("TYPE: "+view.getSelectedType() +"\n"); // or make this dynamic if needed
                sb.append("\n");

                // Column Headers
                sb.append("S.No,Invoice No,Date,Model,Brand,Unit Price,CGST,SGST,Total Amount\n");

                double totalUnitPrice = 0, totalCGST = 0, totalSGST = 0;
                int j = 1;
                for (ReportEntry r : entries) {
                    double unitPrice = r.getTaxableValue();
                    double cgst = r.getCgst();
                    double sgst = r.getSgst();
                    double finalAmount = unitPrice + cgst + sgst;

                    totalUnitPrice += unitPrice;
                    totalCGST += cgst;
                    totalSGST += sgst;

                    sb.append(String.format("%d,%s,%s,%s,%s,%.2f,%.2f,%.2f,%.2f\n",
                            j,
                            escapeCsv(r.getInvoiceNo()),
                            dateFormat.format(r.getDate()),
                            escapeCsv(r.getModel()),
                            escapeCsv(r.getBrand()),
                            unitPrice, cgst, sgst, finalAmount));
                    j++;
                }

                double grandTotal = totalUnitPrice + totalCGST + totalSGST;

                // Add Summary Row
                sb.append(String.format(",,,,TOTAL,%.2f,%.2f,%.2f,%.2f\n",
                        totalUnitPrice, totalCGST, totalSGST, grandTotal));

                java.nio.file.Files.write(fileToSave.toPath(), sb.toString().getBytes("UTF-8"));
                JOptionPane.showMessageDialog(view, "✅ CSV exported to:\n" + fileToSave.getAbsolutePath());

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "❌ CSV Export Error: " + ex.getMessage());
            }
        }

        private String escapeCsv(String value) {
            if (value == null) return "";
            if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
                return "\"" + value.replace("\"", "\"\"") + "\"";
            }
            return value;
        }
    }



}