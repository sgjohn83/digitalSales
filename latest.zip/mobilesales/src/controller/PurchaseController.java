package controller;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import mobilesales.DBConnection;
import mobilesales.MyListener;
import model.Brand;
import model.Product;
import model.ProductStock;
import model.Purchase;
import model.PurchaseItem;
import model.Supplier;
import service.BrandService;
import service.ProductService;
import service.ProductStockService;
import service.PurchaseItemService;
import service.PurchaseService;
import service.SupplierService;
import service.UserService;

public class PurchaseController {
	
	private SupplierService sc;
	private SupplierService ss;
	private PurchaseService ps;
	private ProductService productService;
	private PurchaseItemService service;
	private ProductStockService pss;
	
	   
	  
	   public void loadSupplierComboBox(JComboBox<String> comboBox) {
		   sc= new SupplierService();
		   comboBox.removeAllItems(); // Clear existing items
            
	        List<Supplier> supplierList = null;
			try {
				supplierList =sc.getAllSuppliers();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (Supplier supplier : supplierList) {
			    comboBox.addItem(supplier.getSupplierName());
			}
	    }
	public void loadSupplierDetails(String sname)
	{
		
	}
	public void loadSupplierDetails(String key, JTextField smobile, JTextArea saddr) {
		sc= new SupplierService();
		
		List<Supplier> suppliers = sc.searchSuppliersByName(key);

		if (!suppliers.isEmpty()) {
		    Supplier supplier = suppliers.get(0); // Take the first matching supplier
		    smobile.setText(supplier.getMobileNo());
		    saddr.setText(supplier.getAddress());
		} else {
		    // If no match found, clear the fields
		    smobile.setText("");
		    saddr.setText("");
		}
    }
	public void sendPurchaseDetailsToController(String pbillno, String formattedDate, String uname, String spname, String spmobile, String spaddr, String brand, JTable summaryTable, MyListener m, JLabel totalAmountlbl, String billtype) throws SQLException {

		int supplier_id= createSuppler(spname,spmobile,spaddr);
		ss.commit();
		int user_id = getUserId(uname);
		double amount = getTotalAmount(summaryTable);
		totalAmountlbl.setText(String.valueOf(amount));
		int purchase_id = createPurchase(supplier_id,user_id,amount,pbillno,formattedDate);
		ps.commit();
		List<Product> plist = createProduct(summaryTable,billtype);
	
		
		productService.commit();
		
		
		insertProductStock(plist,purchase_id);
		pss.commit();
		System.out.print("starting purchaseitem record");
		insertPurchaseItem(plist,purchase_id);
		
		
	
	
		service.commit();
		JOptionPane.showMessageDialog(null, "Purchase Successfully Added", "Success", JOptionPane.INFORMATION_MESSAGE);

		m.updatePurchase();
	
		
	    
	}
	
	private void insertProductStock(List<Product> plist, int purchase_id) throws SQLException {
		 List<ProductStock> stockList = new ArrayList<>();

		    for (Product p : plist) {
		        ProductStock ps = new ProductStock();
                System.out.print("imei" +p.getImei());
		        ps.setImeiNo(p.getImei()); // Assuming productCode is IMEI
		        ps.setProductId(p.getProductId()); // Should be set in product earlier
		        ps.setPurchaseId(purchase_id);
		        ps.setSellingPrice(p.getPrice());
		        ps.setStatus("In Stock");
		        ps.setQuantity(1); // One per IMEI
		        ps.setDateAdded(new Timestamp(System.currentTimeMillis()));

		        stockList.add(ps);
		    }
		    pss = new ProductStockService();
		    List<ProductStock> savedStock = pss.saveProductStock(plist, purchase_id);
		    
		
	}
	private void insertPurchaseItem(List<Product> plist, int purchase_id) throws SQLException {
	    
		
		
		List<PurchaseItem> itemList = new ArrayList<>();

	    for (Product p : plist) {
	        PurchaseItem pi = new PurchaseItem();

	        pi.setPurchaseId(purchase_id);
	        pi.setImeiNo(p.getImei());  // Assuming productCode = IMEI
	        pi.setUnitPrice(p.getPrice());
	        pi.setDiscount(0.00);  // default, or customize as needed
	        pi.setCgst(0.00);
	        pi.setSgst(0.00);
	        pi.setRate(0.0); // assume rate = price (if no tax/discount logic)
	        pi.setAmount(0); // quantity assumed 1, so price = amount

	        itemList.add(pi);
	    }

	     service = new PurchaseItemService();
	     service.savePurchaseItems(itemList);
		
	}
	private List<Product> createProduct(JTable summaryTable, String billtype) throws SQLException {
		DefaultTableModel model = (DefaultTableModel) summaryTable.getModel();
		int rowCount = model.getRowCount();
        List<Product> productList = new ArrayList<>();
  
		for (int row = 0; row < rowCount; row++) {
		    // Initialize variables
		    String brand = (String) model.getValueAt(row, 0);
		    String product = (String) model.getValueAt(row, 1);
		    String modelName = (String) model.getValueAt(row, 2);
		    String imei = (String) model.getValueAt(row, 3);
		    String ram = (String) model.getValueAt(row, 4);
		    String storage = (String) model.getValueAt(row, 5);

		    double unitPrice = parseDouble(model.getValueAt(row, 6));
		    int brand_id = getBrandId(brand);
		
 
		    Product p = new Product(-1, product, brand_id, modelName, ram, storage,unitPrice,"",billtype);
		    p.setImei(imei);
		    productList.add(p);
		}
		 productService = new ProductService();
		List<Product> finalProductList = productService.saveOrFetchProducts(productList);
		return finalProductList;

		
	}
	private int  getBrandId(String brand) {
		
		BrandService bs = new BrandService();
		Brand b = bs.getBrandByName(brand);
		return b.getBrandId();
	}
	private int  createPurchase(int supplier_id, int user_id, double amount, String pbillno, String formattedDate) throws SQLException {
		
		System.out.print("creating pur");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(formattedDate, formatter);
		BigDecimal bigAmount = BigDecimal.valueOf(amount);
		Purchase pur = new Purchase(-1,pbillno,date,supplier_id,user_id,bigAmount);

		ps = new PurchaseService();
		Purchase newp = ps.createPurchase(pur);
		System.out.print("id "+newp.getPurchaseId());
		return newp.getPurchaseId();
		
	}
	private double getTotalAmount(JTable summaryTable) {
		int totalAmount = 0;
		for (int i = 0; i < summaryTable.getRowCount(); i++) {
		    Object value = summaryTable.getValueAt(i, 6); // assuming column 5 has the amount
		    if (value != null) {
		        try {
		            totalAmount += Double.parseDouble(value.toString());
		        } catch (NumberFormatException e) {
		            // handle or ignore invalid numbers
		        	e.printStackTrace();
		        }
		    }
		  
		}
		return totalAmount;
		
	}
	private int getUserId(String uname) {
	     
		UserService us = new UserService();
		int id = us.getUserIdByUsername(uname);
		return id;
		
	}
	private int createSuppler(String spname, String spmobile, String spaddr) throws SQLException {
		
		Supplier sup = new Supplier(-1,spname,spmobile,spaddr);
		ss = new SupplierService();
		Supplier s2 = ss.addOrGetSupplier(sup);
		return s2.getSupplierId();
		
		
		
	}
	private double parseDouble(Object val) {
	    if (val == null) return 0.0;
	    try {
	        return Double.parseDouble(val.toString());
	    } catch (NumberFormatException e) {
	        return 0.0;
	    }
	}
	public boolean isValidIMEI(String imei) {
		if (imei.length() != 15 || !imei.matches("\\d+")) {
			return false;
		}

		int sum = 0;
		for (int i = 0; i < 15; i++) {
			int digit = Character.getNumericValue(imei.charAt(i));
			if ((i % 2) == 1) { // Even position from right (index starts at 0)
				digit *= 2;
				if (digit > 9)
					digit -= 9;
			}
			sum += digit;
		}
		return (sum % 10 == 0);
	}

	public boolean isValidMobile(String mobile) {
		return mobile.matches("^[6-9]\\d{9}$");
	}

	public boolean isValidName(String name) {
		return name.matches("^[a-zA-Z ]{2,}$");
	}

	public boolean isValidAmount(String amount) {
		 if (amount.matches("^\\d+(\\.\\d{1,2})?$")) {
		        double value = Double.parseDouble(amount);
		        return true;
		    }
		    return false;
	}
	public String fetchProductCode(String brandName, String modelName) {
	    String productCode = null;
	    Connection con = null;
	    PreparedStatement pst = null;
	    ResultSet rs = null;

	    try {
	        con = DBConnection.getConnection(); // DB connection method
	        String sql = "SELECT p.product_code " +
	                     "FROM product p " +
	                     "JOIN brand b ON p.brand_id = b.brand_id " +
	                     "WHERE b.brand_name = ? AND p.model = ?";
	        pst = con.prepareStatement(sql);
	        pst.setString(1, brandName);
	        pst.setString(2, modelName);
	        rs = pst.executeQuery();

	        if (rs.next()) {
	            productCode = rs.getString("product_code");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) rs.close();
	            if (pst != null) pst.close();
	            if (con != null) con.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return productCode;
	}


	}

