package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import mobilesales.UpdateProduct;
import model.Product2;
import service.BrandService;

public class UpdateProductController {
	UpdateProduct view;
	 Product2 product;
	String brand_name;
	private Connection conn;
	public UpdateProductController(UpdateProduct up, Product2 product) {
	   this.product= product;
	   this.view= up;
	   conn = DBConnection.getConnection();
	   loadbrandCombo();
	   view.getTxtId().setText(String.valueOf(product.getProductId()));
	    view.getComboBrand().setSelectedItem(product.getBrandName());
	    view.getTxtModel().setText(product.getModel());
	    view.getTxtRam().setText(product.getRam());
	    view.getTxtStorage().setText(product.getStorage());
	    view.getTxtPrice().setText(String.valueOf(product.getPrice()));
	    view.getTxtImei().setText(product.getImei());
	    view.getBtnUpdate().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				updateToDB();				
			}

		
		});
	}
	private void loadbrandCombo() {
	
		BrandController bc = new BrandController();
		bc.loadBrandsIntoComboBox(view.getComboBrand());
	}
	private void updateToDB() {
	    try {
	        conn.setAutoCommit(false); // 🔥 Start transaction

	        int productId = Integer.parseInt(view.getTxtId().getText());
	        String brandName = (String) view.getComboBrand().getSelectedItem(); 
	        String model = view.getTxtModel().getText();                 
	        String imei = view.getTxtImei().getText();                    
	        String ram = view.getTxtRam().getText();                     
	        String storage = view.getTxtStorage().getText();             
	        double price = Double.parseDouble(view.getTxtPrice().getText());

	        // 1. Find brand_id
	        int brandId = -1;
	        String sqlBrand = "SELECT brand_id FROM brand WHERE brand_name = ?";
	        try (PreparedStatement pst = conn.prepareStatement(sqlBrand)) {
	            pst.setString(1, brandName);
	            ResultSet rs = pst.executeQuery();
	            if (rs.next()) {
	                brandId = rs.getInt("brand_id");
	            } else {
	                throw new Exception("Brand not found: " + brandName);
	            }
	        }

	        // 2. Update product
	        String sqlProduct = "UPDATE product SET brand_id = ?, model = ?, ram = ?, storage = ?, price = ? WHERE product_id = ?";
	        try (PreparedStatement pst = conn.prepareStatement(sqlProduct)) {
	            pst.setInt(1, brandId);
	            pst.setString(2, model);
	            pst.setString(3, ram);
	            pst.setString(4, storage);
	            pst.setDouble(5, price);
	            pst.setInt(6, productId);
	            pst.executeUpdate();
	        }

	        // 3. Update productstock
	        String sqlStock = "UPDATE productstock SET imei_no = ?, selling_price = ? WHERE product_id = ?";
	        try (PreparedStatement pst = conn.prepareStatement(sqlStock)) {
	            pst.setString(1, imei);
	            pst.setDouble(2, price);
	            pst.setInt(3, productId);
	            pst.executeUpdate();
	        }

	        // 4. Update purchaseitem (unit_price)
	        String sqlPurchaseItem = "UPDATE purchaseitem pi " +
	                                 "JOIN productstock ps ON pi.imei_no = ps.imei_no " +
	                                 "SET pi.unit_price = ? " +
	                                 "WHERE ps.product_id = ?";
	        try (PreparedStatement pst = conn.prepareStatement(sqlPurchaseItem)) {
	            pst.setDouble(1, price);
	            pst.setInt(2, productId);
	            pst.executeUpdate();
	        }

	        // 5. OPTIONAL: If you want, recalculate amount = (unit_price - discount + cgst + sgst)
	        String sqlRecalculateAmount = "UPDATE purchaseitem SET amount = (unit_price - discount + cgst + sgst)";
	        try (PreparedStatement pst = conn.prepareStatement(sqlRecalculateAmount)) {
	            pst.executeUpdate();
	        }

	        // 6. Update purchase total_amount
	        String sqlUpdatePurchase = "UPDATE purchase p " +
	                                   "JOIN ( " +
	                                   "  SELECT purchase_id, SUM(amount) AS total " +
	                                   "  FROM purchaseitem " +
	                                   "  GROUP BY purchase_id " +
	                                   ") sub ON p.purchase_id = sub.purchase_id " +
	                                   "SET p.total_amount = sub.total";
	        try (PreparedStatement pst = conn.prepareStatement(sqlUpdatePurchase)) {
	            pst.executeUpdate();
	        }

	        conn.commit(); // 🔥 Commit transaction
	        JOptionPane.showMessageDialog(view, "Product and related data updated successfully!");

	    } catch (Exception e) {
	        try {
	            conn.rollback(); // 🔥 Rollback on error
	        } catch (SQLException rollbackEx) {
	            rollbackEx.printStackTrace();
	        }
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(view, "Error updating product: " + e.getMessage());
	    } finally {
	        try {
	            conn.setAutoCommit(true); // Restore default behavior
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}


}
