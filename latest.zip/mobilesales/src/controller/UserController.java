package controller;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JComboBox;

import model.CurrentUser;
import model.User;
import service.UserService;

public class UserController {
	 private UserService userService;

	    public UserController() {
	        userService = new UserService();
	    }

	    // 🔽 Load all usernames into combo box
	    public void loadUsernamesIntoComboBox(JComboBox<String> comboBox) {
	        comboBox.removeAllItems(); // Clear existing items
	        try {
	            List<User> users = userService.getAllUsers();
	            for (User user : users) {
	                comboBox.addItem(user.getUsername());
	            }
	          String u =  CurrentUser.getUsername() ;
	          comboBox.setSelectedItem(u);
	          comboBox.disable();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
