package model;



public class SaleReportRow {
    private String invoiceNo;
    private String saleDateTime;
    private String imei;
    private double totalAmount;
    private Boolean financed;
    private double downPayment;
    private double purchasePrice;
    private String brand;
    private String model;
    private String customer;
    private String mobile;
    private double priceDifference;

    // Getters and setters
    public String getInvoiceNo() { return invoiceNo; }
    public void setInvoiceNo(String invoiceNo) { this.invoiceNo = invoiceNo; }

    public String getSaleDateTime() { return saleDateTime; }
    public void setSaleDateTime(String saleDateTime) { this.saleDateTime = saleDateTime; }

    public String getImei() { return imei; }
    public void setImei(String imei) { this.imei = imei; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public Boolean getFinanced() { return financed; }
    public void setFinanced(Boolean financed) { this.financed = financed; }

    public double getDownPayment() { return downPayment; }
    public void setDownPayment(double downPayment) { this.downPayment = downPayment; }

    public double getPurchasePrice() { return purchasePrice; }
    public void setPurchasePrice(double purchasePrice) { this.purchasePrice = purchasePrice; }

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public String getCustomer() { return customer; }
    public void setCustomer(String customer) { this.customer = customer; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public double getPriceDifference() { return priceDifference; }
    public void setPriceDifference(double priceDifference) { this.priceDifference = priceDifference; }
}
