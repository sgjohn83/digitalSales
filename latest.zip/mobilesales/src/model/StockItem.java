package model;

import java.util.Date;


import java.time.LocalDateTime;

public class StockItem {
    private String imei;
    private String model;
    private String brand;
    private String status;
    private double price;

    private String ram;
    private String storage;
    private LocalDateTime purchaseDate;
	private String productCode;

	public StockItem(String imei, String model,String pcode, String brand, String status,  double price,
                     String ram, String storage, LocalDateTime purchaseDate) {
        this.imei = imei;
        this.model = model;
        this.brand = brand;
        this.status = status;
        this.price = price;
        this.productCode = pcode;
        this.ram = ram;
        this.storage = storage;
        this.purchaseDate = purchaseDate;
    }

    public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	// Getters
    public String getImei() { return imei; }
    public String getModel() { return model; }
    public String getBrand() { return brand; }
    public String getStatus() { return status; }
    public double getPrice() { return price; }
    public String getRam() { return ram; }
    public String getStorage() { return storage; }
    public LocalDateTime getPurchaseDate() { return purchaseDate; }

    // Optional Setters (if you need to update fields)
    public void setImei(String imei) { this.imei = imei; }
    public void setModel(String model) { this.model = model; }
    public void setBrand(String brand) { this.brand = brand; }
    public void setStatus(String status) { this.status = status; }
    public void setPrice(double price) { this.price = price; }
    public void setRam(String ram) { this.ram = ram; }
    public void setStorage(String storage) { this.storage = storage; }
    public void setPurchaseDate(LocalDateTime purchaseDate) { this.purchaseDate = purchaseDate; }
}
