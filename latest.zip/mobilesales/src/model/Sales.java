package model;

import java.math.BigDecimal;
import java.sql.Date;


import java.math.BigDecimal;
import java.sql.Timestamp;

public class Sales {

    private int salesId;
    private String invoiceNo;
    private Timestamp invoiceDate;
    private int customerId;
    private int userId;
    private String paymentType; // Cash, Card, UPI, Finance
    private boolean isFinanced;
    private BigDecimal downPayment;
    private BigDecimal totalAmount;

    public Sales() {
    }

    public int getSalesId() {
        return salesId;
    }

    public void setSalesId(int salesId) {
        this.salesId = salesId;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public Timestamp getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Timestamp invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public boolean isFinanced() {
        return isFinanced;
    }

    public void setFinanced(boolean isFinanced) {
        this.isFinanced = isFinanced;
    }

    public BigDecimal getDownPayment() {
        return downPayment;
    }

    public void setDownPayment(BigDecimal downPayment) {
        this.downPayment = downPayment;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}
