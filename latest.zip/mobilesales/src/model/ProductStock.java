package model;
import java.sql.Timestamp;

public class ProductStock {
    private String imeiNo;
    private int productId;
    private int purchaseId;
    private double sellingPrice;
    private String status;
    private int quantity;
    private Timestamp dateAdded;
    private Product product;

    public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	// Constructors
    public ProductStock() {}

    public ProductStock(String imeiNo, int productId, int purchaseId, double sellingPrice,
                        String status, int quantity, Timestamp dateAdded) {
        this.imeiNo = imeiNo;
        this.productId = productId;
        this.purchaseId = purchaseId;
        this.sellingPrice = sellingPrice;
        this.status = status;
        this.quantity = quantity;
        this.dateAdded = dateAdded;
    }

    // Getters and Setters
    public String getImeiNo() {
        return imeiNo;
    }

    public void setImeiNo(String imeiNo) {
        this.imeiNo = imeiNo;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public double getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(double sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Timestamp getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Timestamp dateAdded) {
        this.dateAdded = dateAdded;
    }

    // Optional toString
    @Override
    public String toString() {
        return "ProductStock{" +
                "imeiNo='" + imeiNo + '\'' +
                ", productId=" + productId +
                ", purchaseId=" + purchaseId +
                ", sellingPrice=" + sellingPrice +
                ", status='" + status + '\'' +
                ", quantity=" + quantity +
                ", dateAdded=" + dateAdded +
                '}';
    }
}
