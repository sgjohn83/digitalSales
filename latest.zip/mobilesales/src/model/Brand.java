package model;

public class Brand {
    private int brandId;
    private String brandName;

    // Default constructor
    public Brand() {}

    public Brand(int brandId, String brandName) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
	}

	// Constructor with parameters
    public Brand(String brandName) {
        this.brandName = brandName;
    }

    // Getters and Setters
    public int getBrandId() {
        return brandId;
    }

    public void setBrandId(int brandId) {
        this.brandId = brandId;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    @Override
    public String toString() {
        return "Brand [brandId=" + brandId + ", brandName=" + brandName + "]";
    }
}
