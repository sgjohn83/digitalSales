package model;

import java.util.Date;

public class PurchaseReportRecord {
    // Removed unnecessary fields: imeiNo, totalAmount, rate
    private String invoiceNo;
    private Date invoiceDate;
    private String supplierName;
    private String purchasedBy;
    private String productCode;
    private String brandName;
    private String model;
    private double unitPrice;
    private double discount;
    private double cgst;
    private double sgst;
    private double amount;

    // Getters and Setters for remaining fields
    public String getInvoiceNo() { return invoiceNo; }
    public void setInvoiceNo(String invoiceNo) { this.invoiceNo = invoiceNo; }
    
    public Date getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(Date invoiceDate) { this.invoiceDate = invoiceDate; }
    
    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }
    
    public String getPurchasedBy() { return purchasedBy; }
    public void setPurchasedBy(String purchasedBy) { this.purchasedBy = purchasedBy; }
    
    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) { this.productCode = productCode; }
    
    public String getBrandName() { return brandName; }
    public void setBrandName(String brandName) { this.brandName = brandName; }
    
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    
    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }
    
    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }
    
    public double getCgst() { return cgst; }
    public void setCgst(double cgst) { this.cgst = cgst; }
    
    public double getSgst() { return sgst; }
    public void setSgst(double sgst) { this.sgst = sgst; }
    
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}