package model;

public class PurchaseItem {
    private int purchaseItemId;
    private int purchaseId;
    private String imeiNo;
    private double unitPrice;
    private double discount;
    private double cgst;
    private double sgst;
    private double rate;
    private double amount;

    // Constructors
    public PurchaseItem() {
    }

    public PurchaseItem(int purchaseItemId, int purchaseId, String imeiNo, double unitPrice,
                        double discount, double cgst, double sgst, double rate, double amount) {
        this.purchaseItemId = purchaseItemId;
        this.purchaseId = purchaseId;
        this.imeiNo = imeiNo;
        this.unitPrice = unitPrice;
        this.discount = discount;
        this.cgst = cgst;
        this.sgst = sgst;
        this.rate = rate;
        this.amount = amount;
    }

    // Getters and Setters
    public int getPurchaseItemId() {
        return purchaseItemId;
    }

    public void setPurchaseItemId(int purchaseItemId) {
        this.purchaseItemId = purchaseItemId;
    }

    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getImeiNo() {
        return imeiNo;
    }

    public void setImeiNo(String imeiNo) {
        this.imeiNo = imeiNo;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getCgst() {
        return cgst;
    }

    public void setCgst(double cgst) {
        this.cgst = cgst;
    }

    public double getSgst() {
        return sgst;
    }

    public void setSgst(double sgst) {
        this.sgst = sgst;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    // Optional toString
    @Override
    public String toString() {
        return "PurchaseItem{" +
                "purchaseItemId=" + purchaseItemId +
                ", purchaseId=" + purchaseId +
                ", imeiNo='" + imeiNo + '\'' +
                ", unitPrice=" + unitPrice +
                ", discount=" + discount +
                ", cgst=" + cgst +
                ", sgst=" + sgst +
                ", rate=" + rate +
                ", amount=" + amount +
                '}';
    }
}
