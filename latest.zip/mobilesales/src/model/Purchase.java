package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Purchase {

    private int purchaseId;
    private String invoiceNo;
    private LocalDate invoiceDate;
    private int supplierId;
    private int userId;
    private BigDecimal totalAmount;

    // Default constructor
    public Purchase() {}

    // Full constructor (with ID)
    public Purchase(int purchaseId, String invoiceNo, LocalDate invoiceDate, int supplierId, int userId, BigDecimal totalAmount) {
        this.purchaseId = purchaseId;
        this.invoiceNo = invoiceNo;
        this.invoiceDate = invoiceDate;
        this.supplierId = supplierId;
        this.userId = userId;
        this.totalAmount = totalAmount;
    }

    // Constructor without ID (for inserts where ID is auto-generated)
    public Purchase(String invoiceNo, LocalDate invoiceDate, int supplierId, int userId, BigDecimal totalAmount) {
        this.invoiceNo = invoiceNo;
        this.invoiceDate = invoiceDate;
        this.supplierId = supplierId;
        this.userId = userId;
        this.totalAmount = totalAmount;
    }

    // Getters and Setters
    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {
        return "Purchase{" +
                "purchaseId=" + purchaseId +
                ", invoiceNo='" + invoiceNo + '\'' +
                ", invoiceDate=" + invoiceDate +
                ", supplierId=" + supplierId +
                ", userId=" + userId +
                ", totalAmount=" + totalAmount +
                '}';
    }
}
