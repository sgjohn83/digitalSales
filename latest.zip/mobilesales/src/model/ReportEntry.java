package model;

import java.util.Date;

/**
 * Data holder for a single GST report entry.
 */
public class ReportEntry {
    private final String type;
    private final String invoiceNo;
    private final Date   date;
    private final String imei;
    private final String model;
    private final String brand;
    private final double taxableValue;
    private final double cgst;
    private final double sgst;

    public ReportEntry(String type, String invoiceNo, Date date,
                       String imei, String model, String brand,
                       double taxableValue, double cgst, double sgst) {
        this.type         = type;
        this.invoiceNo    = invoiceNo;
        this.date         = date;
        this.imei         = imei;
        this.model        = model;
        this.brand        = brand;
        this.taxableValue = taxableValue;
        this.cgst         = cgst;
        this.sgst         = sgst;
    }

    public String getType()         { return type; }
    public String getInvoiceNo()    { return invoiceNo; }
    public Date   getDate()         { return date; }
    public String getImei()         { return imei; }
    public String getModel()        { return model; }
    public String getBrand()        { return brand; }
    public double getTaxableValue() { return taxableValue; }
    public double getCgst()         { return cgst; }
    public double getSgst()         { return sgst; }
}
