package model;

import java.sql.Timestamp;
import java.util.Date;

public class SaleRecord {
    private Date invoiceDateTime;
    private String invoiceNo;
    private String imei;
    private double totalAmount;
    private boolean financed;
    private double downPayment;
    private double purchasePrice;
    private String brand;
    private String model;
    private String customer;
    private String customerMobile;
	private String ram;
	private String storage;

    public SaleRecord(Date invoiceDateTime, String invoiceNo, String imei,
                      double totalAmount, boolean financed, double downPayment,
                      double purchasePrice, String brand, String model,String ram,String storage,
                      String customer, String customerMobile) {
        this.invoiceDateTime = invoiceDateTime;
        this.invoiceNo = invoiceNo;
        this.imei = imei;
        this.totalAmount = totalAmount;
        this.financed = financed;
        this.downPayment = downPayment;
        this.purchasePrice = purchasePrice;
        this.brand = brand;
        this.model = model;
        this.ram= ram;
        this.storage=storage;
        this.customer = customer;
        this.customerMobile = customerMobile;
    }

 
	public Date getInvoiceDateTime() { return invoiceDateTime; }
    public String getInvoiceNo() { return invoiceNo; }
    public String getImei() { return imei; }
    public double getTotalAmount() { return totalAmount; }
    public boolean isFinanced() { return financed; }
    public void setRam(String ram) {
		this.ram = ram;
	}

	public double getDownPayment() { return downPayment; }
    public double getPurchasePrice() { return purchasePrice; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public String getCustomer() { return customer; }
    public String getCustomerMobile() { return customerMobile; }

	public String getRam() {
		// TODO Auto-generated method stub
		return ram;
	}

	public String getStorage() {
		// TODO Auto-generated method stub
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}
}
