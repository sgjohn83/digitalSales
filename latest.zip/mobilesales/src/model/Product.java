package model;

public class Product {
    private int productId;
    private String productCode;
    private int brandId;
    private String model;
    private double price;
    private String ram;
    private String storage;
    private String description;
    private String imei;
    private Brand brand;
    private String productType; // ✅ New field

    // Constructors
    public Product() {}

    public Product(int productId, String productCode, int brandId, String model, String ram, String storage, double price, String description, String productType) {
        this.productId = productId;
        this.productCode = productCode;
        this.brandId = brandId;
        this.model = model;
        this.ram = ram;
        this.storage = storage;
        this.price = price;
        this.description = description;
        this.productType = productType;
    }

    // Getters and Setters
    public int getProductId() {
        return productId;
    }
    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductCode() {
        return productCode;
    }
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public int getBrandId() {
        return brandId;
    }
    public void setBrandId(int brandId) {
        this.brandId = brandId;
    }

    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getRam() {
        return ram;
    }
    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getStorage() {
        return storage;
    }
    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getImei() {
        return imei;
    }
    public void setImei(String imei) {
        this.imei = imei;
    }

    public Brand getBrand() {
        return brand;
    }
    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public String getProductType() {
        return productType;
    }
    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Override
    public String toString() {
        return model + " (" + productCode + ")";
    }
}
