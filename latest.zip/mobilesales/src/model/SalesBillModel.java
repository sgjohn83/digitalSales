package model;



import java.util.Date;

public class SalesBillModel {
    private String invoiceNo;
    private Date invoiceDate;
    private String model;
    private String imei;
    private String ram;
    private String storage;
    private double totalAmount;

    // Getters and Setters
    public String getInvoiceNo() { return invoiceNo; }
    public void setInvoiceNo(String invoiceNo) { this.invoiceNo = invoiceNo; }

    public Date getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(Date invoiceDate) { this.invoiceDate = invoiceDate; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public String getImei() { return imei; }
    public void setImei(String imei) { this.imei = imei; }

    public String getRam() { return ram; }
    public void setRam(String ram) { this.ram = ram; }

    public String getStorage() { return storage; }
    public void setStorage(String storage) { this.storage = storage; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

}
