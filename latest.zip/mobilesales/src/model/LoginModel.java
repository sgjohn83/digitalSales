package model;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Optional;

import service.UserService;


public class LoginModel {

    public boolean authenticate(String username, String password) throws NoSuchAlgorithmException {
        UserService us = new UserService();
        try {
			Optional<User> gg = us.authenticate(username, password);
			if(gg.isPresent())
			{
				return true;
			}
			else
				return false;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
    }
}
