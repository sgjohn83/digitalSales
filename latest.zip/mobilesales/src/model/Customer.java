package model;

public class Customer {
    private int customerId;
    private String customerName;
    private String mobileNo;

    // Constructors
    public Customer() {}

    public Customer(int customerId, String customerName, String mobileNo) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.mobileNo = mobileNo;
    }

    public Customer(String customerName, String mobileNo) {
        this.customerName = customerName;
        this.mobileNo = mobileNo;
    }

    // Getters and Setters
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    // toString
    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                '}';
    }
}

