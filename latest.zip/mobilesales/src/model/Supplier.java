package model;

public class Supplier {
    private int supplierId;
    private String supplierName;
    private String mobileNo;
    private String address;

    // Constructors
    public Supplier() {}

    public Supplier(int supplierId, String supplierName, String mobileNo, String address) {
        this.supplierId = supplierId;
        this.supplierName = supplierName;
        this.mobileNo = mobileNo;
        this.address = address;
    }

    // Getters and Setters
    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
