package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mobilesales.DBConnection;

public class SalesReportModel {
    private List<SaleRecord> records;

    public SalesReportModel() {
        records = new ArrayList<SaleRecord>();
    }
    public List<String> fetchBrands() {
        List<String> list = new ArrayList<String>();
        String sql = "SELECT brand_name FROM brand ORDER BY brand_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("brand_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void fetchData(Date startDate, Date endDate,
                          String brand, String paymentMode, String financeFilter) {
        records.clear();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String formattedStart = sdf.format(startDate) + " 00:00:00";
        String formattedEnd = sdf.format(endDate) + " 23:59:59";

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT s.invoice_date, s.invoice_no, si.imei_no, s.total_amount, s.is_financed, ")
           .append("s.down_payment, p.price AS purchase_price, b.brand_name, p.model,p.ram,p.storage, ")
           .append("c.customer_name, c.mobile_no ")
           .append("FROM sales s ")
           .append("JOIN salesitem si ON si.sales_id = s.sales_id ")
           .append("JOIN productstock ps ON ps.imei_no = si.imei_no ")
           .append("JOIN product p ON p.product_id = ps.product_id ")
           .append("JOIN brand b ON b.brand_id = p.brand_id ")
           .append("JOIN customer c ON c.customer_id = s.customer_id ")
           .append("WHERE s.invoice_date BETWEEN '").append(formattedStart).append("' AND '").append(formattedEnd).append("' ");

        if (!"All Brands".equals(brand)) {
            sql.append("AND b.brand_name = '").append(brand).append("' ");
        }

        if (!"All".equals(financeFilter)) {
            boolean isFinanced = "Yes".equals(financeFilter);
            sql.append("AND s.is_financed = ").append(isFinanced).append(" ");
        }

        sql.append("ORDER BY s.invoice_date DESC");

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql.toString())) {

            while (rs.next()) {
                records.add(new SaleRecord(
                    rs.getTimestamp("invoice_date"),
                    rs.getString("invoice_no"),
                    rs.getString("imei_no"),
                    rs.getDouble("total_amount"),
                    rs.getBoolean("is_financed"),
                    rs.getDouble("down_payment"),
                    rs.getDouble("purchase_price"),
                    rs.getString("brand_name"),
                    rs.getString("model"),
                    rs.getString("ram"),
                    rs.getString("storage"),
                    rs.getString("customer_name"),
                    rs.getString("mobile_no")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<SaleRecord> getRecords() { return records; }
    public double getTotalSales()        { return records.stream().mapToDouble(SaleRecord::getTotalAmount).sum(); }
    public double getTotalPurchase()     { return records.stream().mapToDouble(SaleRecord::getPurchasePrice).sum(); }
    public double getTotalDownPayment()  { return records.stream().mapToDouble(SaleRecord::getDownPayment).sum(); }
    public int    getTotalTransactions() { return records.size(); }
    public double getProfitLoss()        { return getTotalSales() - getTotalPurchase(); }
    public double getNetProfit() {
        return records.stream()
                .mapToDouble(r -> r.getTotalAmount() - r.getPurchasePrice())
                .filter(profit -> profit > 0)
                .sum();
    }

    public double getNetLoss() {
        return records.stream()
                .mapToDouble(r -> r.getTotalAmount() - r.getPurchasePrice())
                .filter(loss -> loss < 0)
                .sum();
    }
}
