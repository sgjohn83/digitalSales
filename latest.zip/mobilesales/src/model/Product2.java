package model;
public class Product2 {
    private int productId;
    private String productCode;
    private String brandName;
    private String model;
    private String ram;
    private String storage;
    private double price;
    private String productType;
    private String description;
    private String imei;

    public Product2(int productId, String productCode, String brandName, String model,
                   String ram, String storage, double price, String productType,
                   String description, String imei) {
        this.productId = productId;
        this.productCode = productCode;
        this.brandName = brandName;
        this.model = model;
        this.ram = ram;
        this.storage = storage;
        this.price = price;
        this.productType = productType;
        this.description = description;
        this.imei = imei;
    }

    public Product2() {
		// TODO Auto-generated constructor stub
	}

	public int getProductId() { return productId; }
    public String getProductCode() { return productCode; }
    public String getBrandName() { return brandName; }
    public String getModel() { return model; }
    public String getRam() { return ram; }
    public String getStorage() { return storage; }
    public double getPrice() { return price; }
    public void setProductId(int productId) {
		this.productId = productId;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getProductType() { return productType; }
    public String getDescription() { return description; }
    public String getImei() { return imei; }
    @Override
    public String toString() {
        return "[ID=" + productId + ", Code=" + productCode + ", Brand=" + brandName + ", IMEI=" + imei + "]";
    }

}

