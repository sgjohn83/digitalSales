package model;

import java.math.BigDecimal;

public class SalesItem {

    private Integer salesItemId;
    private int salesId;
    private String imeiNo;
    private String productCode;
    public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	private BigDecimal unitPrice;
    private BigDecimal cgst;
    private BigDecimal sgst;

    // Default constructor
    public SalesItem() {
        this.cgst = BigDecimal.ZERO;
        this.sgst = BigDecimal.ZERO;
    }

    // Full constructor
    public SalesItem(Integer salesItemId, int salesId, String imeiNo,
                     BigDecimal unitPrice, BigDecimal cgst, BigDecimal sgst) {
        this.salesItemId = salesItemId;
        this.salesId = salesId;
        this.imeiNo = imeiNo;
        this.unitPrice = unitPrice;
        this.cgst = cgst != null ? cgst : BigDecimal.ZERO;
        this.sgst = sgst != null ? sgst : BigDecimal.ZERO;
    }

    // Getters and Setters
    public Integer getSalesItemId() {
        return salesItemId;
    }

    public void setSalesItemId(Integer salesItemId) {
        this.salesItemId = salesItemId;
    }

    public int getSalesId() {
        return salesId;
    }

    public void setSalesId(int salesId) {
        this.salesId = salesId;
    }

    public String getImeiNo() {
        return imeiNo;
    }

    public void setImeiNo(String imeiNo) {
        this.imeiNo = imeiNo;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getCgst() {
        return cgst;
    }

    public void setCgst(BigDecimal cgst) {
        this.cgst = cgst;
    }

    public BigDecimal getSgst() {
        return sgst;
    }

    public void setSgst(BigDecimal sgst) {
        this.sgst = sgst;
    }

    @Override
    public String toString() {
        return "SalesItem{" +
                "salesItemId=" + salesItemId +
                ", salesId=" + salesId +
                ", imeiNo='" + imeiNo + '\'' +
                ", unitPrice=" + unitPrice +
                ", cgst=" + cgst +
                ", sgst=" + sgst +
                '}';
    }
}
