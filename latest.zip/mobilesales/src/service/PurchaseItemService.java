package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import model.PurchaseItem;

public class PurchaseItemService {

    private Connection con1;

	public void savePurchaseItems(List<PurchaseItem> itemList) throws SQLException {
        String insertSql = "INSERT INTO purchaseitem " +
                "(purchase_id, imei_no, unit_price, discount, cgst, sgst, rate, amount) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try 
        {    
             con1 = DBConnection.getConnection();
             con1.setAutoCommit(false);
             PreparedStatement stmt = con1.prepareStatement(insertSql);

            for (PurchaseItem item : itemList) {
                stmt.setInt(1, item.getPurchaseId());
                stmt.setString(2, item.getImeiNo());
                stmt.setDouble(3, item.getUnitPrice());
                stmt.setDouble(4, item.getDiscount());
                stmt.setDouble(5, item.getCgst());
                stmt.setDouble(6, item.getSgst());
                stmt.setDouble(7, item.getRate());
                stmt.setDouble(8, item.getAmount());

                stmt.addBatch();
            }

            stmt.executeBatch(); // execute all insertions at once
            System.out.println("✅ Purchase items saved successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("❌ Error saving purchase items: " + e.getMessage());
            con1.rollback();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

	public void commit() throws SQLException {
	con1.commit();
		
	}

	
}
