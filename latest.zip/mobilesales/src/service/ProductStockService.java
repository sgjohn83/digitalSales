package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import model.Product;
import model.ProductStock;

public class ProductStockService {

	private Connection c;

	public ProductStockService() {

	}

	public List<ProductStock> saveProductStock(List<Product> productList, int purchaseId) throws SQLException {
		String sql = "INSERT INTO productstock "
				+ "(imei_no, product_id, purchase_id, selling_price, status, quantity, date_added) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?)";

		List<ProductStock> stockList = new ArrayList<>();

		try {
			c = DBConnection.getConnection();
			c.setAutoCommit(false);
			PreparedStatement stmt = c.prepareStatement(sql);

			for (Product p : productList) {
				ProductStock ps = new ProductStock();

				ps.setImeiNo(p.getImei()); // assuming productCode = IMEI
				ps.setProductId(p.getProductId()); // this must be set earlier
													// or retrieved
				ps.setPurchaseId(purchaseId);
				ps.setSellingPrice(p.getPrice()); // assuming same as purchase
													// price for now
				ps.setStatus("In Stock");
				ps.setQuantity(1); // typically 1 per IMEI
				ps.setDateAdded(new Timestamp(System.currentTimeMillis()));

				// Set parameters
				stmt.setString(1, ps.getImeiNo());
				stmt.setInt(2, ps.getProductId());
				stmt.setInt(3, ps.getPurchaseId());
				stmt.setDouble(4, ps.getSellingPrice());
				stmt.setString(5, ps.getStatus());
				stmt.setInt(6, ps.getQuantity());
				stmt.setTimestamp(7, ps.getDateAdded());

				stmt.executeUpdate();
				stockList.add(ps);
			}

			System.out.println("âœ… Product stock inserted successfully.");
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("â�Œ Error inserting into productstock: " + e.getMessage());
			c.rollback();
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}

		return stockList;
	}

	public void commit() throws SQLException {
		c.commit();

	}

	public boolean checkImei(String imei) {
		boolean exists = false;

		try {
			Connection con = DBConnection.getConnection();
			String query = "SELECT imei_no FROM productstock WHERE imei_no = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, imei);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				exists = true;
			}

			rs.close();
			pst.close();
			con.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error checking IMEI: " + e.getMessage());
		}

		return exists;
	}

	/**
	 * Checks if the product with the given IMEI number is sold.
	 *
	 * @param imeiNo
	 *            IMEI number of the product
	 * @return true if sold, false otherwise
	 */
	public boolean isProductSold(String imeiNo) {
		String sql = "SELECT status FROM productstock WHERE imei_no = ?";
		try {
			Connection conn = DBConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, imeiNo);
			try (ResultSet rs = pstmt.executeQuery()) {
				if (rs.next()) {
					String status = rs.getString("status");
					return "Sold".equalsIgnoreCase(status);
				} else {
					// IMEI not found
					return false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			// You can also log this error or rethrow as custom exception
			return false;
		}
	}

}
