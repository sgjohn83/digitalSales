package service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import model.PurchaseReportRecord;

public class PurchaseReportService {
    private PurchaseReportDAO dao;

    public PurchaseReportService(PurchaseReportDAO dao) {
        this.dao = dao;
    }

    public List<PurchaseReportRecord> getReport(Date from, Date to) throws SQLException {
        return dao.fetch(from, to);
    }
}
