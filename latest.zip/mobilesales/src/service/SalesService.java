package service;

import java.sql.*;
import java.util.*;

import mobilesales.DBConnection;
import model.Sales;

import java.math.BigDecimal;

public class SalesService {

	private Connection conn;

	public SalesService() {
		conn = DBConnection.getConnection();

	}


	// INSERT - Create new Sale
	public Sales addSale(Sales sale) {
	    String sql = "INSERT INTO sales (invoice_no, invoice_date, customer_id, user_id, payment_type, is_financed, down_payment, total_amount) "
	               + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

	    try 
	    {
	        PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

	        stmt.setString(1, sale.getInvoiceNo());
	        stmt.setTimestamp(2, sale.getInvoiceDate());
	        stmt.setInt(3, sale.getCustomerId());
	        stmt.setInt(4, sale.getUserId());
	        stmt.setString(5, sale.getPaymentType());
	        stmt.setBoolean(6, sale.isFinanced());
	        stmt.setBigDecimal(7, sale.getDownPayment());
	        stmt.setBigDecimal(8, sale.getTotalAmount());

	        int affectedRows = stmt.executeUpdate();

	        if (affectedRows > 0) {
	            try (ResultSet rs = stmt.getGeneratedKeys()) {
	                if (rs.next()) {
	                    int generatedId = rs.getInt(1);
	                    sale.setSalesId(generatedId);  // set generated primary key
	                }
	            }
	            return sale;
	        } else {
	            return null;
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	        return null;
	    }
	}


	// READ - Get all sales
	public List<Sales> getAllSales() {
		List<Sales> list = new ArrayList<>();
		String sql = "SELECT * FROM sales";

		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Sales s = new Sales();
				s.setSalesId(rs.getInt("sales_id"));
				s.setInvoiceNo(rs.getString("invoice_no"));
				s.setInvoiceDate(rs.getTimestamp("invoice_date"));
				s.setCustomerId(rs.getInt("customer_id"));
				s.setUserId(rs.getInt("user_id"));
				s.setPaymentType(rs.getString("payment_type"));
				s.setFinanced(rs.getBoolean("is_financed"));
				s.setDownPayment(rs.getBigDecimal("down_payment"));
				s.setTotalAmount(rs.getBigDecimal("total_amount"));
				list.add(s);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	// READ - Get sale by ID
	public Sales getSaleById(int id) {
		String sql = "SELECT * FROM sales WHERE sales_id = ?";
		Sales s = null;

		try {
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				s = new Sales();
				s.setSalesId(rs.getInt("sales_id"));
				s.setInvoiceNo(rs.getString("invoice_no"));
				s.setInvoiceDate(rs.getTimestamp("invoice_date"));
				s.setCustomerId(rs.getInt("customer_id"));
				s.setUserId(rs.getInt("user_id"));
				s.setPaymentType(rs.getString("payment_type"));
				s.setFinanced(rs.getBoolean("is_financed"));
				s.setDownPayment(rs.getBigDecimal("down_payment"));
				s.setTotalAmount(rs.getBigDecimal("total_amount"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return s;
	}

	// UPDATE - Update sale
	public boolean updateSale(Sales sale) {
		String sql = "UPDATE sales SET invoice_no=?, invoice_date=?, customer_id=?, user_id=?, payment_type=?, "
				+ "is_financed=?, down_payment=?, total_amount=? WHERE sales_id=?";

		try {
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, sale.getInvoiceNo());
			stmt.setTimestamp(2, sale.getInvoiceDate());
			stmt.setInt(3, sale.getCustomerId());
			stmt.setInt(4, sale.getUserId());
			stmt.setString(5, sale.getPaymentType());
			stmt.setBoolean(6, sale.isFinanced());
			stmt.setBigDecimal(7, sale.getDownPayment());
			stmt.setBigDecimal(8, sale.getTotalAmount());
			stmt.setInt(9, sale.getSalesId());

			return stmt.executeUpdate() > 0;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	// DELETE - Delete sale by ID
	public boolean deleteSale(int id) {
		String sql = "DELETE FROM sales WHERE sales_id = ?";

		try {
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setInt(1, id);
			return stmt.executeUpdate() > 0;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Integer getSalesIdByInvoiceNo(String invoiceNo) throws SQLException {
	    Integer salesId = null;
	    String sql = "SELECT sales_id FROM sales WHERE invoice_no = ?";

	    PreparedStatement stmt = null;
	    ResultSet rs = null;

	    try {
	        stmt = conn.prepareStatement(sql);
	        stmt.setString(1, invoiceNo);
	        rs = stmt.executeQuery();

	        if (rs.next()) {
	            salesId = rs.getInt("sales_id");
	        }
	    } finally {
	        if (rs != null) try { rs.close(); } catch (SQLException ignore) {}
	        if (stmt != null) try { stmt.close(); } catch (SQLException ignore) {}
	    }

	    return salesId;
	}

}
