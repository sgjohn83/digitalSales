package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import mobilesales.DBConnection;
import model.Brand;

public class BrandService {

    // Method to add a brand to the database
    public boolean addBrand(Brand brand) {
        String insertSQL = "INSERT INTO brand (brand_name) VALUES (?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            preparedStatement.setString(1, brand.getBrandName());
            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;  // Return true if a brand was successfully added

        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // Return false if there was an error
        }
    }

    // Method to update a brand in the database
    public boolean updateBrand(Brand brand) {
        String updateSQL = "UPDATE brand SET brand_name = ? WHERE brand_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            preparedStatement.setString(1, brand.getBrandName());
            preparedStatement.setInt(2, brand.getBrandId());
            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;  // Return true if the brand was successfully updated

        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // Return false if there was an error
        }
    }

    // Method to delete a brand from the database
    public boolean deleteBrand(int brandId) {
        String deleteSQL = "DELETE FROM brand WHERE brand_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {

            preparedStatement.setInt(1, brandId);
            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;  // Return true if the brand was successfully deleted

        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // Return false if there was an error
        }
    }

    // Method to get all brands from the database
    public List<Brand> getAllBrands() {
        List<Brand> brands = new ArrayList<>();
        String selectSQL = "SELECT * FROM brand";

        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSQL)) {

            while (resultSet.next()) {
                Brand brand = new Brand();
                brand.setBrandId(resultSet.getInt("brand_id"));
                brand.setBrandName(resultSet.getString("brand_name"));
                brands.add(brand);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return brands;
    }

    // Method to get a brand by its ID
    public Brand getBrandById(int brandId) {
        Brand brand = null;
        String selectSQL = "SELECT * FROM brand WHERE brand_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {

            preparedStatement.setInt(1, brandId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                brand = new Brand();
                brand.setBrandId(resultSet.getInt("brand_id"));
                brand.setBrandName(resultSet.getString("brand_name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return brand;
    }

    // Method to check if a brand exists by name
    public boolean brandExists(String brandName) {
        String selectSQL = "SELECT COUNT(*) FROM brand WHERE brand_name = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {

            preparedStatement.setString(1, brandName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;  // Return true if the brand exists
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if there was an error or the brand doesn't exist
    }

    // Method to get a brand by name
    public Brand getBrandByName(String brandName) {
        Brand brand = null;
        String selectSQL = "SELECT * FROM brand WHERE brand_name = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {

            preparedStatement.setString(1, brandName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                brand = new Brand();
                brand.setBrandId(resultSet.getInt("brand_id"));
                brand.setBrandName(resultSet.getString("brand_name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return brand;
    }

    // Method to get the total count of brands in the database
    public int getBrandCount() {
        int count = 0;
        String countSQL = "SELECT COUNT(*) FROM brand";

        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(countSQL)) {

            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }
}
