package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mobilesales.DBConnection;
import model.SalesBillModel;

public class CustomerBillModel {

	private Connection conn;

	public CustomerBillModel() {
		
		this.conn = DBConnection.getConnection();
	}

	public List<SalesBillModel> getBillsByCustomerMobile(String mobileNo) {
		List<SalesBillModel> bills = new ArrayList<SalesBillModel>();
		String sql = "SELECT s.invoice_no, s.invoice_date, p.model, ps.imei_no, p.ram, p.storage, s.total_amount "
				+ "FROM sales s " + "JOIN customer c ON s.customer_id = c.customer_id "
				+ "JOIN salesitem si ON s.sales_id = si.sales_id " + "JOIN productstock ps ON si.imei_no = ps.imei_no "
				+ "JOIN product p ON ps.product_id = p.product_id " + "WHERE c.mobile_no = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps =  conn.prepareStatement(sql);
			ps.setString(1, mobileNo);
			rs = ps.executeQuery();

			while (rs.next()) {
				SalesBillModel bill = new SalesBillModel();
				bill.setInvoiceNo(rs.getString("invoice_no"));
				bill.setInvoiceDate(rs.getTimestamp("invoice_date"));
				bill.setModel(rs.getString("model"));
				bill.setImei(rs.getString("imei_no"));
				bill.setRam(rs.getString("ram"));
				bill.setStorage(rs.getString("storage"));
				bill.setTotalAmount(rs.getDouble("total_amount"));
				bills.add(bill);
			}
		} catch (SQLException e) {
			e.printStackTrace(); // replace with logger if needed
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
			}
		}

		return bills;
	}

}
