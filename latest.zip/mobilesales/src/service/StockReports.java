package service;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import mobilesales.DBConnection;
import model.StockItem;

public class StockReports {

    public List<String> getAllBrands() {
        List<String> brands = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT brand_name FROM brand ORDER BY brand_name")) {

            while (rs.next()) {
                brands.add(rs.getString("brand_name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return brands;
    }

    public List<StockItem> searchStock(String brand, String status, String modelName, String product_type) {
        List<StockItem> list = new ArrayList<>();

        String sql = "SELECT ps.imei_no, p.model, p.product_code,b.brand_name, ps.status, ps.selling_price, " +
                     "p.ram, p.storage, ps.date_added " +
                     "FROM productstock ps " +
                     "JOIN product p ON ps.product_id = p.product_id " +
                     "JOIN brand b ON p.brand_id = b.brand_id " +
                     "WHERE 1=1";

        if (brand != null && !"All".equalsIgnoreCase(brand.trim())) {
            sql += " AND b.brand_name = '" + brand.trim().replace("'", "''") + "'";
        }

        if (status != null && !"All".equalsIgnoreCase(status.trim())) {
            sql += " AND ps.status = '" + status.trim().replace("'", "''") + "'";
        }

        if (modelName != null && !modelName.trim().isEmpty()) {
            String searchValue = modelName.trim().replace("'", "''");
            sql += " AND (p.model LIKE '%" + searchValue + "%' OR p.product_code LIKE '%" + searchValue + "%')";
        }

        if (product_type != null && !"All".equalsIgnoreCase(product_type.trim())) {
            sql += " AND p.product_type = '" + product_type.trim().replace("'", "''") + "'";
        }

        System.out.println("sql = " + sql);

        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String imei = rs.getString("imei_no");
              
                String model = rs.getString("model");
                String pcode = rs.getString("product_code");
                String brandName = rs.getString("brand_name");
                String statusStr = rs.getString("status");
                double price = rs.getDouble("selling_price");
                String ram = rs.getString("ram");
                String storage = rs.getString("storage");

                Timestamp ts = rs.getTimestamp("date_added");
                LocalDateTime purchaseDate = (ts != null) ? ts.toLocalDateTime() : null;

                list.add(new StockItem(imei, model,pcode, brandName, statusStr, price, ram, storage, purchaseDate));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

}
