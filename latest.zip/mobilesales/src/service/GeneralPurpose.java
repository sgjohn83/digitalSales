package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mobilesales.DBConnection;

public class GeneralPurpose {
	  private Connection conn;

	public GeneralPurpose() {
		conn = DBConnection.getConnection();
	}

	public List<String> getSuggestionsForModel(String brandInput) {
	    List<String> suggestions = new ArrayList<String>();
	    try {
	        String sql = "SELECT DISTINCT p.model FROM product p " +
	                     "JOIN brand b ON p.brand_id = b.brand_id " +
	                     "WHERE b.brand_name = ? " + // ✅ Exact match
	                     "ORDER BY p.model ASC";

	        PreparedStatement stmt = conn.prepareStatement(sql);
	        stmt.setString(1, brandInput); // ✅ No wildcard
	        ResultSet rs = stmt.executeQuery();

	        while (rs.next()) {
	            suggestions.add(rs.getString("model")); // ✅ Correct column name
	        }

	        rs.close();
	        stmt.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return suggestions;
	}

	public List<String> getSuggestionsForProductCode(String brand, String model) {
	    List<String> suggestions = new ArrayList<String>();
	    try {
	        String sql = "SELECT p.product_code FROM product p " +
	                     "JOIN brand b ON p.brand_id = b.brand_id " +
	                     "WHERE b.brand_name = ? AND p.model = ?";

	        PreparedStatement stmt = conn.prepareStatement(sql);
	        stmt.setString(1, brand); // ✅ Exact match
	        stmt.setString(2, model); // ✅ Exact match
	        ResultSet rs = stmt.executeQuery();

	        while (rs.next()) {
	            suggestions.add(rs.getString("product_code")); // ✅ Correct column name
	        }

	        rs.close();
	        stmt.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return suggestions;
	}



}
