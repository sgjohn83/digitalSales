package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import model.Product;
import model.Product2;

public class ProductService {

    private final Connection conn;
    private Connection c;

    public ProductService() {
        this.conn = DBConnection.getConnection();
    }

    // Add new product
    public boolean addProduct(Product product) throws SQLException {
        String sql = "INSERT INTO product (product_code, brand_id, model, ram, storage, price, description, product_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, product.getProductCode());
            stmt.setInt(2, product.getBrandId());
            stmt.setString(3, product.getModel());
            stmt.setString(4, product.getRam());
            stmt.setString(5, product.getStorage());
            stmt.setDouble(6, product.getPrice());
            stmt.setString(7, product.getDescription());
            stmt.setString(8, product.getProductType()); // ✅ Added
            return stmt.executeUpdate() > 0;
        }
    }

    // Update product
    public boolean updateProduct(Product product) throws SQLException {
        String sql = "UPDATE product SET product_code = ?, brand_id = ?, model = ?, ram = ?, storage = ?, price = ?, description = ?, product_type = ? WHERE product_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, product.getProductCode());
            stmt.setInt(2, product.getBrandId());
            stmt.setString(3, product.getModel());
            stmt.setString(4, product.getRam());
            stmt.setString(5, product.getStorage());
            stmt.setDouble(6, product.getPrice());
            stmt.setString(7, product.getDescription());
            stmt.setString(8, product.getProductType()); // ✅ Added
            stmt.setInt(9, product.getProductId());
            return stmt.executeUpdate() > 0;
        }
    }

    // Delete product
    public boolean deleteProduct(int productId) throws SQLException {
        String sql = "DELETE FROM product WHERE product_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            return stmt.executeUpdate() > 0;
        }
    }

    // Insert or fetch product
    public List<Product> saveOrFetchProducts(List<Product> productList) throws SQLException {
        List<Product> resultList = new ArrayList<>();

        String checkSql = "SELECT * FROM product WHERE product_code = ? AND model = ? AND ram = ? AND storage = ? AND price = ?";
        String insertSql = "INSERT INTO product (product_code, brand_id, model, ram, storage, price, description, product_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);

            PreparedStatement checkStmt = c.prepareStatement(checkSql);
            PreparedStatement insertStmt = c.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);

            for (Product p : productList) {
                // Check if exists
                checkStmt.setString(1, p.getProductCode());
                checkStmt.setString(2, p.getModel());
                checkStmt.setString(3, p.getRam());
                checkStmt.setString(4, p.getStorage());
                checkStmt.setDouble(5, p.getPrice());

                ResultSet rs = checkStmt.executeQuery();

                if (rs.next()) {
                    // Exists - fetch and reuse
                    Product existing = new Product(
                        rs.getInt("product_id"),
                        rs.getString("product_code"),
                        rs.getInt("brand_id"),
                        rs.getString("model"),
                        rs.getString("ram"),
                        rs.getString("storage"),
                        rs.getDouble("price"),
                        rs.getString("description"),
                        rs.getString("product_type") // ✅ Added
                    );
                    existing.setImei(p.getImei());
                    resultList.add(existing);
                } else {
                    // Insert new product
                    insertStmt.setString(1, p.getProductCode());
                    insertStmt.setInt(2, p.getBrandId());
                    insertStmt.setString(3, p.getModel());
                    insertStmt.setString(4, p.getRam());
                    insertStmt.setString(5, p.getStorage());
                    insertStmt.setDouble(6, p.getPrice());
                    insertStmt.setString(7, p.getDescription());
                    insertStmt.setString(8, p.getProductType()); // ✅ Added
                    insertStmt.executeUpdate();

                    ResultSet keys = insertStmt.getGeneratedKeys();
                    if (keys.next()) {
                        p.setProductId(keys.getInt(1));
                        resultList.add(p);
                    }
                    keys.close();
                }

                rs.close();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            c.rollback();
            System.exit(0);
        }

        return resultList;
    }

    public void commit() throws SQLException {
        if (c != null) {
            c.commit();
        }
    }

    public boolean deleteProductByImei(String imei) throws SQLException {
        boolean oldAutoCommit = conn.getAutoCommit();
        conn.setAutoCommit(false);
        try {
            // 1. Check if already sold
            String checkSoldSql = "SELECT 1 FROM salesitem WHERE imei_no = ?";
            try (PreparedStatement ps = conn.prepareStatement(checkSoldSql)) {
                ps.setString(1, imei);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        conn.rollback();
                        return false; // sold, abort
                    }
                }
            }

            // 2. Fetch product_id, purchase_item_id, purchase_id
            int productId, purchaseItemId, purchaseId;
            String getInfoSql =
                "SELECT ps.product_id, pi.purchase_item_id, pi.purchase_id " +
                "FROM productstock ps " +
                "JOIN purchaseitem pi ON ps.imei_no = pi.imei_no " +
                "WHERE ps.imei_no = ?";
            try (PreparedStatement ps = conn.prepareStatement(getInfoSql)) {
                ps.setString(1, imei);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        conn.rollback();
                        return false; // not found
                    }
                    productId      = rs.getInt("product_id");
                    purchaseItemId = rs.getInt("purchase_item_id");
                    purchaseId     = rs.getInt("purchase_id");
                }
            }

            // 3. Delete child purchaseitem first
            String deletePI = "DELETE FROM purchaseitem WHERE purchase_item_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(deletePI)) {
                ps.setInt(1, purchaseItemId);
                ps.executeUpdate();
            }

            // 4. Delete productstock
            String deleteStockSql = "DELETE FROM productstock WHERE imei_no = ?";
            try (PreparedStatement ps = conn.prepareStatement(deleteStockSql)) {
                ps.setString(1, imei);
                ps.executeUpdate();
            }

            // 5. Check remaining stock for this product
            String countStockSql = "SELECT COUNT(*) FROM productstock WHERE product_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(countStockSql)) {
                ps.setInt(1, productId);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) > 0) {
                        conn.commit();
                        return true; // other stock remains
                    }
                }
            }

            // 6. No stock left: check and delete purchase if empty
            String countByPurchase = "SELECT COUNT(*) FROM purchaseitem WHERE purchase_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(countByPurchase)) {
                ps.setInt(1, purchaseId);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) == 0) {
                        String deletePurchase = "DELETE FROM purchase WHERE purchase_id = ?";
                        try (PreparedStatement ps2 = conn.prepareStatement(deletePurchase)) {
                            ps2.setInt(1, purchaseId);
                            ps2.executeUpdate();
                        }
                    }
                }
            }

            // 7. Finally delete the product
            String deleteProduct = "DELETE FROM product WHERE product_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(deleteProduct)) {
                ps.setInt(1, productId);
                ps.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException ex) {
            conn.rollback();
            throw ex;
        } finally {
            conn.setAutoCommit(oldAutoCommit);
        }
    }

	public boolean isProductSold(String imei) throws SQLException {
		 String sql = "SELECT COUNT(*) FROM salesitem WHERE imei_no = ?";
	        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setString(1, imei);
	            ResultSet rs = stmt.executeQuery();
	            if (rs.next()) {
	                return rs.getInt(1) > 0;
	            }
	        }
	        return false;
	}
	public List<Product2> getAllProducts() {
	    List<Product2> list = new ArrayList<Product2>();
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;

	    try {
	        System.out.println("Connecting to database...");
	        con = DBConnection.getConnection();

	        String sql = "SELECT " +
	                "p.product_id, " +
	                "p.product_code, " +
	                "b.brand_name, " +
	                "p.model, " +
	                "p.ram, " +
	                "p.storage, " +
	                "p.price, " +
	                "p.product_type, " +
	                "p.description, " +
	                "ps.imei_no " +
	                "FROM product p " +
	                "JOIN brand b ON p.brand_id = b.brand_id " +
	                "JOIN productstock ps ON p.product_id = ps.product_id";

	        System.out.println("Preparing SQL statement...");
	        ps = con.prepareStatement(sql);

	        System.out.println("Executing query...");
	        rs = ps.executeQuery();

	        System.out.println("Processing result set...");
	        while (rs.next()) {
	            Product2 p = new Product2(
	                rs.getInt("product_id"),
	                rs.getString("product_code"),
	                rs.getString("brand_name"),
	                rs.getString("model"),
	                rs.getString("ram"),
	                rs.getString("storage"),
	                rs.getDouble("price"),
	                rs.getString("product_type"),
	                rs.getString("description"),
	                rs.getString("imei_no")
	            );
	            System.out.println("Fetched: " + p); // Optional: override toString() in Product2 for readable output
	            list.add(p);
	        }
	        System.out.println("Product list size: " + list.size());

	    } catch (SQLException e) {
	        System.err.println("SQL Exception: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        try { if (rs != null) rs.close(); System.out.println("ResultSet closed."); } catch (Exception e) {}
	        try { if (ps != null) ps.close(); System.out.println("PreparedStatement closed."); } catch (Exception e) {}
	        try { if (con != null) con.close(); System.out.println("Connection closed."); } catch (Exception e) {}
	    }

	    return list;
	}

}
