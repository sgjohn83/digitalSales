package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mobilesales.DBConnection;
import model.PurchaseReportRecord;

public class PurchaseReportDAO {
    private Connection getConnection() throws SQLException {
        return DBConnection.getConnection();
    }

    public List<PurchaseReportRecord> fetch(Date from, Date to) throws SQLException {
        String sql = "SELECT "
                + "p.invoice_no, "
                + "p.invoice_date, "
                + "s.supplier_name, "
                + "u.username AS purchased_by, "
                + "pr.product_code, "
                + "b.brand_name, "
                + "pr.model, "
                + "pi.unit_price, "
                + "pi.discount, "
                + "pi.cgst, "
                + "pi.sgst, "
                + "pi.amount "
                + "FROM purchase p "
                + "INNER JOIN supplier s ON p.supplier_id = s.supplier_id "
                + "INNER JOIN user u ON p.user_id = u.user_id "
                + "INNER JOIN purchaseitem pi ON p.purchase_id = pi.purchase_id "
                + "INNER JOIN productstock ps ON pi.imei_no = ps.imei_no "
                + "INNER JOIN product pr ON ps.product_id = pr.product_id "
                + "INNER JOIN brand b ON pr.brand_id = b.brand_id "
                + "WHERE p.invoice_date BETWEEN ? AND ? "
                + "ORDER BY p.invoice_date DESC, p.invoice_no";

        List<PurchaseReportRecord> records = new ArrayList<>();

        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setDate(1, new java.sql.Date(from.getTime()));
            pst.setDate(2, new java.sql.Date(to.getTime()));

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    PurchaseReportRecord record = new PurchaseReportRecord();
                    
                    // Mandatory fields
                    record.setInvoiceNo(rs.getString("invoice_no"));
                    record.setInvoiceDate(rs.getDate("invoice_date"));
                    record.setSupplierName(rs.getString("supplier_name"));
                    record.setPurchasedBy(rs.getString("purchased_by"));
                    
                    // Product information
                    record.setProductCode(rs.getString("product_code"));
                    record.setBrandName(rs.getString("brand_name"));
                    record.setModel(rs.getString("model"));
                    
                    // Financial details
                    record.setUnitPrice(rs.getDouble("unit_price"));
                    record.setDiscount(rs.getDouble("discount"));
                    record.setCgst(rs.getDouble("cgst"));
                    record.setSgst(rs.getDouble("sgst"));
                    record.setAmount(rs.getDouble("amount"));
                    
                    records.add(record);
                }
            }
        } catch (SQLException e) {
            throw new SQLException("Error generating purchase report: " + e.getMessage(), e);
        }
        return records;
    }
}