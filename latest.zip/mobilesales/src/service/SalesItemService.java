package service;

import java.math.BigDecimal;
import java.sql.*;

import mobilesales.DBConnection;
import model.SalesItem;

public class SalesItemService {


	private Connection conn;
   
	public SalesItemService() {
		conn = DBConnection.getConnection();
	}

	public boolean insertSalesItem(SalesItem item) {
        String sql = "INSERT INTO salesitem (sales_id, imei_no, unit_price, cgst, sgst) VALUES (?, ?, ?, ?, ?)";

        try 
        {
             PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, item.getSalesId());
            stmt.setString(2, item.getImeiNo());
            stmt.setBigDecimal(3, item.getUnitPrice());
            stmt.setBigDecimal(4, item.getCgst() != null ? item.getCgst() : BigDecimal.ZERO);
            stmt.setBigDecimal(5, item.getSgst() != null ? item.getSgst() : BigDecimal.ZERO);

            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            System.err.println("Error inserting sales item: " + e.getMessage());
            return false;
        }
    }
}
