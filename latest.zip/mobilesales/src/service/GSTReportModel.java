/* GSTReportModel.java */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mobilesales.DBConnection;
import model.ReportEntry;

public class GSTReportModel {
    private static final double CGST_RATE = 0.09;
    private static final double SGST_RATE = 0.09;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public List<String> getBrands() throws SQLException {
        List<String> brands = new ArrayList<String>();
        final String sql = "SELECT brand_name FROM brand ORDER BY brand_name";
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                brands.add(rs.getString(1));
            }
        }
        return brands;
    }

    public List<ReportEntry> getReport(Date startDate, Date endDate,
                                       String brandFilter,
                                       String typeFilter) throws SQLException {
        List<ReportEntry> entries = new ArrayList<ReportEntry>();
        String start = dateFormat.format(startDate);
        String end   = dateFormat.format(endDate);

        boolean includePurchase = "All".equals(typeFilter) || "Purchase".equals(typeFilter);
        boolean includeSales    = "All".equals(typeFilter) || "Sales".equals(typeFilter);

        StringBuilder sql = new StringBuilder();
        if (includePurchase) {
            sql.append("SELECT 'Purchase' AS type, p.invoice_no, p.invoice_date, ")
               .append("ps.imei_no AS imei, pr.model, b.brand_name, ")
               .append("ROUND(pi.unit_price / (1 + 0.18), 2) AS taxable, 0 AS cgst, 0 AS sgst ")
               .append("FROM purchase p ")
               .append("JOIN purchaseitem pi ON p.purchase_id = pi.purchase_id ")
               .append("JOIN productstock ps ON pi.imei_no = ps.imei_no ")
               .append("JOIN product pr ON ps.product_id = pr.product_id ")
               .append("JOIN brand b ON pr.brand_id = b.brand_id ")
               .append("WHERE p.invoice_date BETWEEN ? AND ? AND pr.product_type='GST' ");
            if (brandFilter != null) sql.append("AND b.brand_name = ? ");
        }
        if (includePurchase && includeSales) {
            sql.append(" UNION ALL ");
        }
        if (includeSales) {
            sql.append("SELECT 'Sales' AS type, s.invoice_no, s.invoice_date, ")
               .append("ps.imei_no AS imei, pr.model, b.brand_name, ")
               .append("si.unit_price AS taxable, si.cgst, si.sgst ")
               .append("FROM sales s ")
               .append("JOIN salesitem si ON s.sales_id = si.sales_id ")
               .append("JOIN productstock ps ON si.imei_no = ps.imei_no ")
               .append("JOIN product pr ON ps.product_id = pr.product_id ")
               .append("JOIN brand b ON pr.brand_id = b.brand_id ")
               .append("WHERE s.invoice_date BETWEEN ? AND ? AND pr.product_type='GST' ");
            if (brandFilter != null) sql.append("AND b.brand_name = ? ");
        }
        sql.append(" ORDER BY invoice_date");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            int idx = 1;
            if (includePurchase) {
                pst.setString(idx++, start);
                pst.setString(idx++, end);
                if (brandFilter != null) pst.setString(idx++, brandFilter);
            }
            if (includeSales) {
                pst.setString(idx++, start);
                pst.setString(idx++, end);
                if (brandFilter != null) pst.setString(idx++, brandFilter);
            }

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    String type    = rs.getString("type");
                    String invNo   = rs.getString("invoice_no");
                    Date date      = rs.getDate("invoice_date");
                    String imei    = rs.getString("imei");
                    String model   = rs.getString("model");
                    String brand   = rs.getString("brand_name");
                    double taxable = rs.getDouble("taxable");
                    double cgst    = "Purchase".equals(type) ? taxable * CGST_RATE : rs.getDouble("cgst");
                    double sgst    = "Purchase".equals(type) ? taxable * SGST_RATE : rs.getDouble("sgst");
                    entries.add(new ReportEntry(type, invNo, date, imei, model, brand, taxable, cgst, sgst));
                }
            }
        }
        return entries;
    }
}
