package service;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import model.Product2;
import model.Purchase;

public class PurchaseService {
    private Connection c;
    public Purchase createPurchase(Purchase purchase) throws SQLException {
        String sql = "INSERT INTO purchase (invoice_no, invoice_date, supplier_id, user_id, total_amount) VALUES (?, ?, ?, ?, ?)";

        try 
        {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);
             PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            stmt.setString(1, purchase.getInvoiceNo());
            stmt.setDate(2, Date.valueOf(purchase.getInvoiceDate()));
            stmt.setInt(3, purchase.getSupplierId());
            stmt.setInt(4, purchase.getUserId());
            stmt.setBigDecimal(5, purchase.getTotalAmount());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                purchase.setPurchaseId(rs.getInt(1)); // Set generated ID
            }
         
        } catch (SQLException e) {
        	c.rollback();
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
		return purchase;
    }

    public Purchase getPurchaseById(int purchaseId) {
        String sql = "SELECT * FROM purchase WHERE purchase_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, purchaseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToPurchase(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Purchase> getAllPurchases() {
        List<Purchase> list = new ArrayList<>();
        String sql = "SELECT * FROM purchase";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                list.add(mapResultSetToPurchase(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean updatePurchase(Purchase purchase) {
        String sql = "UPDATE purchase SET invoice_no = ?, invoice_date = ?, supplier_id = ?, user_id = ?, total_amount = ? WHERE purchase_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, purchase.getInvoiceNo());
            stmt.setDate(2, Date.valueOf(purchase.getInvoiceDate()));
            stmt.setInt(3, purchase.getSupplierId());
            stmt.setInt(4, purchase.getUserId());
            stmt.setBigDecimal(5, purchase.getTotalAmount());
            stmt.setInt(6, purchase.getPurchaseId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean deletePurchase(int purchaseId) {
        String sql = "DELETE FROM purchase WHERE purchase_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, purchaseId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Helper method to map ResultSet to Purchase object
    private Purchase mapResultSetToPurchase(ResultSet rs) throws SQLException {
        return new Purchase(
                rs.getInt("purchase_id"),
                rs.getString("invoice_no"),
                rs.getDate("invoice_date").toLocalDate(),
                rs.getInt("supplier_id"),
                rs.getInt("user_id"),
                rs.getBigDecimal("total_amount")
        );
    }

	public void commit() throws SQLException {
		c.commit();
		
		
	}

	public boolean checkInvoiceNo(String invoiceNo) {
	    boolean exists = false;

	    try {
	        // Establish connection
	        Connection con = DBConnection.getConnection();

	        // Prepare the SQL query to check if the invoice number exists
	        String query = "SELECT invoice_no FROM purchase WHERE invoice_no = ?";
	        PreparedStatement pst = con.prepareStatement(query);
	        pst.setString(1, invoiceNo);

	        // Execute query
	        ResultSet rs = pst.executeQuery();
	        
	        // If the result set has any row, it means the invoice number exists
	        if (rs.next()) {
	            exists = true;
	        }

	        // Close resources
	        rs.close();
	        pst.close();
	        con.close();
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(null, "Error checking invoice number: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    return exists;
	}
	
	 
}
