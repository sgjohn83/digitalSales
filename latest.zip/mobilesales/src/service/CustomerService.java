package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mobilesales.DBConnection;
import model.Customer;

public class CustomerService {

    private Connection conn;

    public CustomerService() {
        conn = DBConnection.getConnection();
    }

    public Customer addOrGetCustomer(String name, String mobile) throws SQLException {
        // 1. Check if customer exists
        String selectQuery = "SELECT * FROM customer WHERE customer_name = ? AND mobile_no = ?";
        try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
            ps.setString(1, name);
            ps.setString(2, mobile);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // Return existing customer
                return new Customer(
                        rs.getInt("customer_id"),
                        rs.getString("customer_name"),
                        rs.getString("mobile_no")
                );
            }
        }

        // 2. Insert new customer
        String insertQuery = "INSERT INTO customer (customer_name, mobile_no) VALUES (?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, mobile);
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                int newId = keys.getInt(1);
                return new Customer(newId, name, mobile);
            } else {
                throw new SQLException("Customer insertion failed, no ID returned.");
            }
        }
    }
}
