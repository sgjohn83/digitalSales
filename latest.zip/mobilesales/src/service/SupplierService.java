package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import mobilesales.DBConnection;
import model.Supplier;

public class SupplierService {
	private Connection c;

    private Connection getConnection() throws SQLException {
         
    	return DBConnection.getConnection();
      
    }

    // âž• Add new supplier
    public void addSupplier(Supplier supplier) throws SQLException {
        String sql = "INSERT INTO supplier (supplier_name, mobile_no, address) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, supplier.getSupplierName());
            stmt.setString(2, supplier.getMobileNo());
            stmt.setString(3, supplier.getAddress());
            stmt.executeUpdate();
        }
    }

    // ðŸ“‹ Get all suppliers
    public  List<Supplier> getAllSuppliers() throws SQLException {
        List<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT * FROM supplier ORDER BY supplier_id";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                suppliers.add(mapResultSetToSupplier(rs));
            }
        }
        return suppliers;
    }

    // ðŸ”� Get supplier by ID
    public Supplier getSupplierById(int supplierId) throws SQLException {
        String sql = "SELECT * FROM supplier WHERE supplier_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, supplierId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToSupplier(rs);
                }
            }
        }
        return null;
    }

    public Supplier findSupplierByName(String name) throws SQLException {
        String sql = "SELECT * FROM supplier WHERE supplier_name = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Supplier found, return with real ID
                    return mapResultSetToSupplier(rs);
                } else {
                    // Supplier not found, return with ID -1
                    return new Supplier(-1, name, null, null);
                }
            }
        }
    }


    // ðŸ”� Get suppliers by name (search)
   
    // âœ�ï¸� Update supplier
    public void updateSupplier(Supplier supplier) throws SQLException {
        String sql = "UPDATE supplier SET supplier_name = ?, mobile_no = ?, address = ? WHERE supplier_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, supplier.getSupplierName());
            stmt.setString(2, supplier.getMobileNo());
            stmt.setString(3, supplier.getAddress());
            stmt.setInt(4, supplier.getSupplierId());
            stmt.executeUpdate();
        }
    }

    // â�Œ Delete supplier by ID
    public void deleteSupplier(int supplierId) throws SQLException {
        String sql = "DELETE FROM supplier WHERE supplier_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, supplierId);
            stmt.executeUpdate();
        }
    }

    // ðŸ”¢ Get total number of suppliers
    public int countSuppliers() throws SQLException {
        String sql = "SELECT COUNT(*) FROM supplier";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // ðŸ”� Utility method to convert ResultSet to Supplier object
    private Supplier mapResultSetToSupplier(ResultSet rs) throws SQLException {
        return new Supplier(
            rs.getInt("supplier_id"),
            rs.getString("supplier_name"),
            rs.getString("mobile_no"),
            rs.getString("address")
        );
    }

    public List<Supplier> searchSuppliersByName(String key) {
        List<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT * FROM supplier WHERE supplier_name LIKE ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + key + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    suppliers.add(mapResultSetToSupplier(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Optionally log or rethrow
        }

        return suppliers;
    }
    
    public Supplier addOrGetSupplier(Supplier inputSupplier) throws SQLException {
        Supplier existingSupplier = getSupplierByName(inputSupplier.getSupplierName());

        if (existingSupplier != null) {
            // already exists
            return existingSupplier;
        }

        // if not exists, insert new supplier
        String sql = "INSERT INTO supplier (supplier_name, mobile_no, address) VALUES (?, ?, ?)";
        
        try {
          
            c.setAutoCommit(false);
        	PreparedStatement ps = c.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

            ps.setString(1, inputSupplier.getSupplierName());
            ps.setString(2, inputSupplier.getMobileNo());
            ps.setString(3, inputSupplier.getAddress());

            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int id = rs.getInt(1);
                        inputSupplier.setSupplierId(id);
                        return inputSupplier;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            c.rollback();
            System.exit(0);
        }

        return null;
    }

    public Supplier getSupplierByName(String name) {
        String sql = "SELECT supplier_id, supplier_name, mobile_no, address FROM supplier WHERE supplier_name = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Supplier s = new Supplier();
                    s.setSupplierId(rs.getInt("supplier_id"));
                    s.setSupplierName(rs.getString("supplier_name"));
                    s.setMobileNo(rs.getString("mobile_no"));
                    s.setAddress(rs.getString("address"));
                    return s;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

	public SupplierService() {
		c= DBConnection.getConnection();
	}


	public void commit() throws SQLException {
	
		if(!c.getAutoCommit())
		c.commit();
		
	}

}
